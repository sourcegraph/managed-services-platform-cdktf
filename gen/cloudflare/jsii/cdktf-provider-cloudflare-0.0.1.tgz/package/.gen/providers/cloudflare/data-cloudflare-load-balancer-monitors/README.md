# `data_cloudflare_load_balancer_monitors`

Refer to the Terraform Registry for docs: [`data_cloudflare_load_balancer_monitors`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/load_balancer_monitors).
