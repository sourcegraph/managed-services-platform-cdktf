# `data_cloudflare_stream`

Refer to the Terraform Registry for docs: [`data_cloudflare_stream`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/stream).
