# `data_cloudflare_queues`

Refer to the Terraform Registry for docs: [`data_cloudflare_queues`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/queues).
