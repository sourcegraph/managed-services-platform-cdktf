# `data_cloudflare_custom_hostname`

Refer to the Terraform Registry for docs: [`data_cloudflare_custom_hostname`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/custom_hostname).
