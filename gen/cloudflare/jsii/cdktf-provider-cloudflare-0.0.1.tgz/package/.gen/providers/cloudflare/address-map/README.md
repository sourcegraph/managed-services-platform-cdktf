# `cloudflare_address_map`

Refer to the Terraform Registry for docs: [`cloudflare_address_map`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/address_map).
