# `cloudflare_regional_tiered_cache`

Refer to the Terraform Registry for docs: [`cloudflare_regional_tiered_cache`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/regional_tiered_cache).
