# `data_cloudflare_ai_search_instance`

Refer to the Terraform Registry for docs: [`data_cloudflare_ai_search_instance`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/ai_search_instance).
