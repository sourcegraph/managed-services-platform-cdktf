# `data_cloudflare_zone_dnssec`

Refer to the Terraform Registry for docs: [`data_cloudflare_zone_dnssec`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/zone_dnssec).
