# `data_cloudflare_schema_validation_settings`

Refer to the Terraform Registry for docs: [`data_cloudflare_schema_validation_settings`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/schema_validation_settings).
