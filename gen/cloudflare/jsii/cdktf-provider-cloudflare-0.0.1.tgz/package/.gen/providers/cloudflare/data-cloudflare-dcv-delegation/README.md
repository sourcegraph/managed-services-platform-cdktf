# `data_cloudflare_dcv_delegation`

Refer to the Terraform Registry for docs: [`data_cloudflare_dcv_delegation`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/dcv_delegation).
