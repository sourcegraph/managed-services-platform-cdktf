# `cloudflare_turnstile_widget`

Refer to the Terraform Registry for docs: [`cloudflare_turnstile_widget`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/turnstile_widget).
