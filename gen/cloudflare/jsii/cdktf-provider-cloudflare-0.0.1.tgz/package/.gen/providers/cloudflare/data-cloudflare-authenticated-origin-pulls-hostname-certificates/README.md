# `data_cloudflare_authenticated_origin_pulls_hostname_certificates`

Refer to the Terraform Registry for docs: [`data_cloudflare_authenticated_origin_pulls_hostname_certificates`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/authenticated_origin_pulls_hostname_certificates).
