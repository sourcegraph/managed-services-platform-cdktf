# `cloudflare_account_subscription`

Refer to the Terraform Registry for docs: [`cloudflare_account_subscription`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/account_subscription).
