# `cloudflare_page_rule`

Refer to the Terraform Registry for docs: [`cloudflare_page_rule`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/page_rule).
