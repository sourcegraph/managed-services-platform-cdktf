# `data_cloudflare_image_variant`

Refer to the Terraform Registry for docs: [`data_cloudflare_image_variant`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/image_variant).
