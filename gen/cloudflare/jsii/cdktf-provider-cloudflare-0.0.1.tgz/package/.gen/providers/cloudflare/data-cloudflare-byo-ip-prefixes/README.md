# `data_cloudflare_byo_ip_prefixes`

Refer to the Terraform Registry for docs: [`data_cloudflare_byo_ip_prefixes`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/byo_ip_prefixes).
