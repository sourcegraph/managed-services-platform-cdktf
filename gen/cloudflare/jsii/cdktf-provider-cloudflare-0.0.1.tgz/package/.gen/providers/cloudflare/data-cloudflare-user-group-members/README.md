# `data_cloudflare_user_group_members`

Refer to the Terraform Registry for docs: [`data_cloudflare_user_group_members`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/user_group_members).
