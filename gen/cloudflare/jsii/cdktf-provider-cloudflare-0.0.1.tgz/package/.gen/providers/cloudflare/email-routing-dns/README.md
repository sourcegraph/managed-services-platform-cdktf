# `cloudflare_email_routing_dns`

Refer to the Terraform Registry for docs: [`cloudflare_email_routing_dns`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/email_routing_dns).
