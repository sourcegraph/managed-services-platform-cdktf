# `data_cloudflare_token_validation_configs`

Refer to the Terraform Registry for docs: [`data_cloudflare_token_validation_configs`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/token_validation_configs).
