# `cloudflare_origin_ca_certificate`

Refer to the Terraform Registry for docs: [`cloudflare_origin_ca_certificate`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/origin_ca_certificate).
