# `data_cloudflare_zone_hold`

Refer to the Terraform Registry for docs: [`data_cloudflare_zone_hold`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/zone_hold).
