# `data_cloudflare_list`

Refer to the Terraform Registry for docs: [`data_cloudflare_list`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/list).
