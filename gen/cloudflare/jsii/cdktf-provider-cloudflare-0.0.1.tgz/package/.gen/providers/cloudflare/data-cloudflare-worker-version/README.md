# `data_cloudflare_worker_version`

Refer to the Terraform Registry for docs: [`data_cloudflare_worker_version`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/worker_version).
