# `cloudflare_dns_zone_transfers_outgoing`

Refer to the Terraform Registry for docs: [`cloudflare_dns_zone_transfers_outgoing`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/resources/dns_zone_transfers_outgoing).
