# `cloudflare_logpull_retention`

Refer to the Terraform Registry for docs: [`cloudflare_logpull_retention`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/logpull_retention).
