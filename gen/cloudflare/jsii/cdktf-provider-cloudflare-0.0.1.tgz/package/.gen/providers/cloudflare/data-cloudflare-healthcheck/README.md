# `data_cloudflare_healthcheck`

Refer to the Terraform Registry for docs: [`data_cloudflare_healthcheck`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/healthcheck).
