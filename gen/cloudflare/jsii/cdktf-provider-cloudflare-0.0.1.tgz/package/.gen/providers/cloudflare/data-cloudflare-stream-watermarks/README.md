# `data_cloudflare_stream_watermarks`

Refer to the Terraform Registry for docs: [`data_cloudflare_stream_watermarks`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/stream_watermarks).
