# `data_cloudflare_regional_hostname`

Refer to the Terraform Registry for docs: [`data_cloudflare_regional_hostname`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/regional_hostname).
