# `data_cloudflare_magic_transit_site_acls`

Refer to the Terraform Registry for docs: [`data_cloudflare_magic_transit_site_acls`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/magic_transit_site_acls).
