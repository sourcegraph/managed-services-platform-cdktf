# `data_cloudflare_workers_kv_namespaces`

Refer to the Terraform Registry for docs: [`data_cloudflare_workers_kv_namespaces`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/workers_kv_namespaces).
