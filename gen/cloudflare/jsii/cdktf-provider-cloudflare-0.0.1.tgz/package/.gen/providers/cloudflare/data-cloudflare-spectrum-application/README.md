# `data_cloudflare_spectrum_application`

Refer to the Terraform Registry for docs: [`data_cloudflare_spectrum_application`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/spectrum_application).
