# `data_cloudflare_custom_origin_trust_store`

Refer to the Terraform Registry for docs: [`data_cloudflare_custom_origin_trust_store`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/custom_origin_trust_store).
