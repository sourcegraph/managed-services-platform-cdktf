# `data_cloudflare_zero_trust_access_ai_controls_mcp_portals`

Refer to the Terraform Registry for docs: [`data_cloudflare_zero_trust_access_ai_controls_mcp_portals`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/zero_trust_access_ai_controls_mcp_portals).
