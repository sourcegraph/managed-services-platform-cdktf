# `data_cloudflare_workers_scripts`

Refer to the Terraform Registry for docs: [`data_cloudflare_workers_scripts`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/workers_scripts).
