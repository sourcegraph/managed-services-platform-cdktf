# `cloudflare_custom_ssl`

Refer to the Terraform Registry for docs: [`cloudflare_custom_ssl`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/custom_ssl).
