# `data_cloudflare_managed_transforms`

Refer to the Terraform Registry for docs: [`data_cloudflare_managed_transforms`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/managed_transforms).
