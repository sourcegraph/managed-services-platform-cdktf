# `data_cloudflare_workflow`

Refer to the Terraform Registry for docs: [`data_cloudflare_workflow`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/workflow).
