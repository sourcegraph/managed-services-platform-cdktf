# `data_cloudflare_page_rule`

Refer to the Terraform Registry for docs: [`data_cloudflare_page_rule`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.0/docs/data-sources/page_rule).
