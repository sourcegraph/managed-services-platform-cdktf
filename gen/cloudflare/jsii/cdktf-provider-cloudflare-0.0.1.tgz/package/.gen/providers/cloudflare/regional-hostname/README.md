# `cloudflare_regional_hostname`

Refer to the Terraform Registry for docs: [`cloudflare_regional_hostname`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/regional_hostname).
