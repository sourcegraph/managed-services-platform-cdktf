# `data_cloudflare_filter`

Refer to the Terraform Registry for docs: [`data_cloudflare_filter`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/filter).
