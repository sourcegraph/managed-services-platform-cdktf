# `data_cloudflare_sso_connector`

Refer to the Terraform Registry for docs: [`data_cloudflare_sso_connector`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/sso_connector).
