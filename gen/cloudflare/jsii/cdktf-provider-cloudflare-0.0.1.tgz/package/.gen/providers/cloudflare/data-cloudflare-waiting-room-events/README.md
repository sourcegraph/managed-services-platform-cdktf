# `data_cloudflare_waiting_room_events`

Refer to the Terraform Registry for docs: [`data_cloudflare_waiting_room_events`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/waiting_room_events).
