# `data_cloudflare_zero_trust_gateway_proxy_endpoints`

Refer to the Terraform Registry for docs: [`data_cloudflare_zero_trust_gateway_proxy_endpoints`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/zero_trust_gateway_proxy_endpoints).
