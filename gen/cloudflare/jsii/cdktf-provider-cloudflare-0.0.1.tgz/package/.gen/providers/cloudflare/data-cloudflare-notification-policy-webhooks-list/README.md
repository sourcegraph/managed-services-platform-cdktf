# `data_cloudflare_notification_policy_webhooks_list`

Refer to the Terraform Registry for docs: [`data_cloudflare_notification_policy_webhooks_list`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/notification_policy_webhooks_list).
