# `data_cloudflare_rulesets`

Refer to the Terraform Registry for docs: [`data_cloudflare_rulesets`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/rulesets).
