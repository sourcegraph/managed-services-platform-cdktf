# `cloudflare_registrar_domain`

Refer to the Terraform Registry for docs: [`cloudflare_registrar_domain`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/resources/registrar_domain).
