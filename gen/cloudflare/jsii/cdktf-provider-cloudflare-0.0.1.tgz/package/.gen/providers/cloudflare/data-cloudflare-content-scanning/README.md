# `data_cloudflare_content_scanning`

Refer to the Terraform Registry for docs: [`data_cloudflare_content_scanning`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/content_scanning).
