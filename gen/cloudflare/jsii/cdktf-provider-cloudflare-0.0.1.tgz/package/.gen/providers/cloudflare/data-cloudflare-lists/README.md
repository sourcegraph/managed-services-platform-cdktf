# `data_cloudflare_lists`

Refer to the Terraform Registry for docs: [`data_cloudflare_lists`](https://registry.terraform.io/providers/cloudflare/cloudflare/5.17.0/docs/data-sources/lists).
