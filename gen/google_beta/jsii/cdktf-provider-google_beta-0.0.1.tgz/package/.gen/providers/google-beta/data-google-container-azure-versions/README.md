# `data_google_container_azure_versions`

Refer to the Terraform Registry for docs: [`data_google_container_azure_versions`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_container_azure_versions).
