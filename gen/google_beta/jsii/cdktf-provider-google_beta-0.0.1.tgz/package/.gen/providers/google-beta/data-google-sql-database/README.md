# `data_google_sql_database`

Refer to the Terraform Registry for docs: [`data_google_sql_database`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_sql_database).
