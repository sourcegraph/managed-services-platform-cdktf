# `data_google_iam_role`

Refer to the Terraform Registry for docs: [`data_google_iam_role`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_iam_role).
