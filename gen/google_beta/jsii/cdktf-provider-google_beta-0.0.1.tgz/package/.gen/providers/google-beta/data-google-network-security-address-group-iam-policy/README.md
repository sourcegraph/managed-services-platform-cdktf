# `data_google_network_security_address_group_iam_policy`

Refer to the Terraform Registry for docs: [`data_google_network_security_address_group_iam_policy`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_network_security_address_group_iam_policy).
