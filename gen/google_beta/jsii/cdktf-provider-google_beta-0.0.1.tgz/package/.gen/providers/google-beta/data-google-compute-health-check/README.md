# `data_google_compute_health_check`

Refer to the Terraform Registry for docs: [`data_google_compute_health_check`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_compute_health_check).
