# `data_google_container_registry_repository`

Refer to the Terraform Registry for docs: [`data_google_container_registry_repository`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_container_registry_repository).
