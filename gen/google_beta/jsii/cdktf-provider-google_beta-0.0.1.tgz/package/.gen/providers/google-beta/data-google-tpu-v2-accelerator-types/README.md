# `data_google_tpu_v2_accelerator_types`

Refer to the Terraform Registry for docs: [`data_google_tpu_v2_accelerator_types`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_tpu_v2_accelerator_types).
