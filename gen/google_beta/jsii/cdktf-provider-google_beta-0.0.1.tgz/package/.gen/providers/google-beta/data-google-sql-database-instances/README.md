# `data_google_sql_database_instances`

Refer to the Terraform Registry for docs: [`data_google_sql_database_instances`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_sql_database_instances).
