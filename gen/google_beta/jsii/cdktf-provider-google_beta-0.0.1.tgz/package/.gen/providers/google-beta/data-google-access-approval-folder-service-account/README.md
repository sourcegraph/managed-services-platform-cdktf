# `data_google_access_approval_folder_service_account`

Refer to the Terraform Registry for docs: [`data_google_access_approval_folder_service_account`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_access_approval_folder_service_account).
