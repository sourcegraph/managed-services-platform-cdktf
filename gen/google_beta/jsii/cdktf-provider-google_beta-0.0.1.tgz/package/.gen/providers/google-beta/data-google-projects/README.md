# `data_google_projects`

Refer to the Terraform Registry for docs: [`data_google_projects`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_projects).
