# `google_apigee_addons_config`

Refer to the Terraform Registry for docs: [`google_apigee_addons_config`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/resources/google_apigee_addons_config).
