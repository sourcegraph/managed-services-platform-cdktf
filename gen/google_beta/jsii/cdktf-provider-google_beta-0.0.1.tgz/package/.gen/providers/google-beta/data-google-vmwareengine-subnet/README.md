# `data_google_vmwareengine_subnet`

Refer to the Terraform Registry for docs: [`data_google_vmwareengine_subnet`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_vmwareengine_subnet).
