# `data_google_dataproc_job_iam_policy`

Refer to the Terraform Registry for docs: [`data_google_dataproc_job_iam_policy`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_dataproc_job_iam_policy).
