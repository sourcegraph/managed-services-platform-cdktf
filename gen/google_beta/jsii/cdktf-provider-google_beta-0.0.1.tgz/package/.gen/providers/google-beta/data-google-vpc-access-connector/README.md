# `data_google_vpc_access_connector`

Refer to the Terraform Registry for docs: [`data_google_vpc_access_connector`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_vpc_access_connector).
