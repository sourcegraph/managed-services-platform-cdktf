# `data_google_composer_user_workloads_config_map`

Refer to the Terraform Registry for docs: [`data_google_composer_user_workloads_config_map`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_composer_user_workloads_config_map).
