# `google_access_context_manager_ingress_policy`

Refer to the Terraform Registry for docs: [`google_access_context_manager_ingress_policy`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/resources/google_access_context_manager_ingress_policy).
