# `data_google_compute_storage_pool_types`

Refer to the Terraform Registry for docs: [`data_google_compute_storage_pool_types`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_compute_storage_pool_types).
