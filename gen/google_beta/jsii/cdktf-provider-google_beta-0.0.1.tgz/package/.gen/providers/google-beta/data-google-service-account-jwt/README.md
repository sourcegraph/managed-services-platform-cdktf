# `data_google_service_account_jwt`

Refer to the Terraform Registry for docs: [`data_google_service_account_jwt`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_service_account_jwt).
