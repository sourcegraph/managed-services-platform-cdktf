# `data_google_artifact_registry_tag`

Refer to the Terraform Registry for docs: [`data_google_artifact_registry_tag`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_artifact_registry_tag).
