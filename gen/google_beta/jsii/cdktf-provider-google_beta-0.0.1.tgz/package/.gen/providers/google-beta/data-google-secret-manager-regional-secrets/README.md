# `data_google_secret_manager_regional_secrets`

Refer to the Terraform Registry for docs: [`data_google_secret_manager_regional_secrets`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_secret_manager_regional_secrets).
