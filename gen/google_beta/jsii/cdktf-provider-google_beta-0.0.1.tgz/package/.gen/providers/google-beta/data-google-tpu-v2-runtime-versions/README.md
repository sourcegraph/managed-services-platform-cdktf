# `data_google_tpu_v2_runtime_versions`

Refer to the Terraform Registry for docs: [`data_google_tpu_v2_runtime_versions`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_tpu_v2_runtime_versions).
