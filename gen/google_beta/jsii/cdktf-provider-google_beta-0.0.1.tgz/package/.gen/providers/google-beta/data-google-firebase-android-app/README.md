# `data_google_firebase_android_app`

Refer to the Terraform Registry for docs: [`data_google_firebase_android_app`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_firebase_android_app).
