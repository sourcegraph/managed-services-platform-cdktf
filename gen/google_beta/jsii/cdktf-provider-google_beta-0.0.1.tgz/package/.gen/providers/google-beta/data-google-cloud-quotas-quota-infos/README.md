# `data_google_cloud_quotas_quota_infos`

Refer to the Terraform Registry for docs: [`data_google_cloud_quotas_quota_infos`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_cloud_quotas_quota_infos).
