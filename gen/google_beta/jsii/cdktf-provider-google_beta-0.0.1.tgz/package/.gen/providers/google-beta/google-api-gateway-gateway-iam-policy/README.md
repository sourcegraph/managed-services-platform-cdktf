# `google_api_gateway_gateway_iam_policy`

Refer to the Terraform Registry for docs: [`google_api_gateway_gateway_iam_policy`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/resources/google_api_gateway_gateway_iam_policy).
