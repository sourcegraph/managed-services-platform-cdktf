# `data_google_storage_bucket_object`

Refer to the Terraform Registry for docs: [`data_google_storage_bucket_object`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_storage_bucket_object).
