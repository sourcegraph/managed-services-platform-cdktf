# `data_google_vertex_ai_feature_online_store_featureview_iam_policy`

Refer to the Terraform Registry for docs: [`data_google_vertex_ai_feature_online_store_featureview_iam_policy`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_vertex_ai_feature_online_store_featureview_iam_policy).
