# `data_google_beyondcorp_app_gateway`

Refer to the Terraform Registry for docs: [`data_google_beyondcorp_app_gateway`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_beyondcorp_app_gateway).
