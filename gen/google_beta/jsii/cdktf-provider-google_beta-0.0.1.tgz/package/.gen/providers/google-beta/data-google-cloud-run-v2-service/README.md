# `data_google_cloud_run_v2_service`

Refer to the Terraform Registry for docs: [`data_google_cloud_run_v2_service`](https://registry.terraform.io/providers/hashicorp/google-beta/7.31.0/docs/data-sources/google_cloud_run_v2_service).
