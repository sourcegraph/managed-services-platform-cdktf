# `sentry_organization_code_mapping`

Refer to the Terraform Registry for docs: [`sentry_organization_code_mapping`](https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping).
