# `data_sentry_dashboard`

Refer to the Terraform Registry for docs: [`data_sentry_dashboard`](https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/dashboard).
