# `data_sentry_issue_alert`

Refer to the Terraform Registry for docs: [`data_sentry_issue_alert`](https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/issue_alert).
