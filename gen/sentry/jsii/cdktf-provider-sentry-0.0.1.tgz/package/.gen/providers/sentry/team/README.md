# `sentry_team`

Refer to the Terraform Registry for docs: [`sentry_team`](https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team).
