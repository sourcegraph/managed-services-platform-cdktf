import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryCronMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * The internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/cron_monitor#id DataSentryCronMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The organization slug or internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/cron_monitor#organization DataSentryCronMonitor#organization}
    */
    readonly organization: string;
}
export interface DataSentryCronMonitorOwner {
}
export declare function dataSentryCronMonitorOwnerToTerraform(struct?: DataSentryCronMonitorOwner): any;
export declare function dataSentryCronMonitorOwnerToHclTerraform(struct?: DataSentryCronMonitorOwner): any;
export declare class DataSentryCronMonitorOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryCronMonitorOwner | undefined;
    set internalValue(value: DataSentryCronMonitorOwner | undefined);
    get teamId(): string;
    get userId(): string;
}
export interface DataSentryCronMonitorSchedule {
}
export declare function dataSentryCronMonitorScheduleToTerraform(struct?: DataSentryCronMonitorSchedule): any;
export declare function dataSentryCronMonitorScheduleToHclTerraform(struct?: DataSentryCronMonitorSchedule): any;
export declare class DataSentryCronMonitorScheduleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryCronMonitorSchedule | undefined;
    set internalValue(value: DataSentryCronMonitorSchedule | undefined);
    get crontab(): string;
    get intervalUnit(): string;
    get intervalValue(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/cron_monitor sentry_cron_monitor}
*/
export declare class DataSentryCronMonitor extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_cron_monitor";
    /**
    * Generates CDKTF code for importing a DataSentryCronMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryCronMonitor to import
    * @param importFromId The id of the existing DataSentryCronMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/cron_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryCronMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/cron_monitor sentry_cron_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryCronMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryCronMonitorConfig);
    get checkinMarginMinutes(): number;
    get description(): string;
    get enabled(): cdktf.IResolvable;
    get failureIssueThreshold(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get maxRuntimeMinutes(): number;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner;
    get owner(): DataSentryCronMonitorOwnerOutputReference;
    get projectId(): string;
    get recoveryThreshold(): number;
    private _schedule;
    get schedule(): DataSentryCronMonitorScheduleOutputReference;
    get timezone(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
