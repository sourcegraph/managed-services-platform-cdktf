import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Return the first key of the returned keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key#first DataSentryKey#first}
    */
    readonly first?: boolean | cdktf.IResolvable;
    /**
    * The ID of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key#id DataSentryKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the client key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key#name DataSentryKey#name}
    */
    readonly name?: string;
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key#organization DataSentryKey#organization}
    */
    readonly organization: string;
    /**
    * The project the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key#project DataSentryKey#project}
    */
    readonly project: string;
}
export interface DataSentryKeyJavascriptLoaderScript {
}
export declare function dataSentryKeyJavascriptLoaderScriptToTerraform(struct?: DataSentryKeyJavascriptLoaderScript): any;
export declare function dataSentryKeyJavascriptLoaderScriptToHclTerraform(struct?: DataSentryKeyJavascriptLoaderScript): any;
export declare class DataSentryKeyJavascriptLoaderScriptOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryKeyJavascriptLoaderScript | undefined;
    set internalValue(value: DataSentryKeyJavascriptLoaderScript | undefined);
    get browserSdkVersion(): string;
    get debugEnabled(): cdktf.IResolvable;
    get performanceMonitoringEnabled(): cdktf.IResolvable;
    get sessionReplayEnabled(): cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key sentry_key}
*/
export declare class DataSentryKey extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_key";
    /**
    * Generates CDKTF code for importing a DataSentryKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryKey to import
    * @param importFromId The id of the existing DataSentryKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/key sentry_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryKeyConfig);
    private _dsn;
    get dsn(): cdktf.StringMap;
    get dsnCsp(): string;
    get dsnPublic(): string;
    get dsnSecret(): string;
    private _first?;
    get first(): boolean | cdktf.IResolvable;
    set first(value: boolean | cdktf.IResolvable);
    resetFirst(): void;
    get firstInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _javascriptLoaderScript;
    get javascriptLoaderScript(): DataSentryKeyJavascriptLoaderScriptOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get projectId(): string;
    get public(): string;
    get rateLimitCount(): number;
    get rateLimitWindow(): number;
    get secret(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
