import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryAlertConfig extends cdktf.TerraformMetaArguments {
    /**
    * The internal ID of the alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/alert#id DataSentryAlert#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The organization slug or internal ID of the alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/alert#organization DataSentryAlert#organization}
    */
    readonly organization: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/alert sentry_alert}
*/
export declare class DataSentryAlert extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_alert";
    /**
    * Generates CDKTF code for importing a DataSentryAlert resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryAlert to import
    * @param importFromId The id of the existing DataSentryAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/alert sentry_alert} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryAlertConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryAlertConfig);
    get actionFiltersJson(): string;
    get enabled(): cdktf.IResolvable;
    get environment(): string;
    get frequencyMinutes(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get monitorIds(): string[];
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get triggersJson(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
