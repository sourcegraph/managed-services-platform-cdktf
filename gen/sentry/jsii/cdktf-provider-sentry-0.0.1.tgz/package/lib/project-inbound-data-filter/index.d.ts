import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectInboundDataFilterConfig extends cdktf.TerraformMetaArguments {
    /**
    * Toggle the browser-extensions, localhost, filtered-transaction, or web-crawlers filter on or off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter#active ProjectInboundDataFilter#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * The type of filter toggle to update. See the [Sentry documentation](https://docs.sentry.io/api/projects/update-an-inbound-data-filter/) for a list of available filters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter#filter_id ProjectInboundDataFilter#filter_id}
    */
    readonly filterId: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter#organization ProjectInboundDataFilter#organization}
    */
    readonly organization: string;
    /**
    * The project of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter#project ProjectInboundDataFilter#project}
    */
    readonly project: string;
    /**
    * Specifies which legacy browser filters should be active. Anything excluded from the list will be disabled. See the [Sentry documentation](https://docs.sentry.io/api/projects/update-an-inbound-data-filter/) for a list of available subfilters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter#subfilters ProjectInboundDataFilter#subfilters}
    */
    readonly subfilters?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter sentry_project_inbound_data_filter}
*/
export declare class ProjectInboundDataFilter extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_project_inbound_data_filter";
    /**
    * Generates CDKTF code for importing a ProjectInboundDataFilter resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectInboundDataFilter to import
    * @param importFromId The id of the existing ProjectInboundDataFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectInboundDataFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_inbound_data_filter sentry_project_inbound_data_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectInboundDataFilterConfig
    */
    constructor(scope: Construct, id: string, config: ProjectInboundDataFilterConfig);
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _filterId?;
    get filterId(): string;
    set filterId(value: string);
    get filterIdInput(): string | undefined;
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _subfilters?;
    get subfilters(): string[];
    set subfilters(value: string[]);
    resetSubfilters(): void;
    get subfiltersInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
