import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectSymbolSourceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The AWS Access Key.Required for S3 sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#access_key ProjectSymbolSource#access_key}
    */
    readonly accessKey?: string;
    /**
    * The App Store Connect Issuer ID. Required for AppStoreConnect sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#app_connect_issuer ProjectSymbolSource#app_connect_issuer}
    */
    readonly appConnectIssuer?: string;
    /**
    * The App Store Connect API Private Key. Required for AppStoreConnect sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#app_connect_private_key ProjectSymbolSource#app_connect_private_key}
    */
    readonly appConnectPrivateKey?: string;
    /**
    * The App Store Connect App ID. Required for AppStoreConnect sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#app_id ProjectSymbolSource#app_id}
    */
    readonly appId?: string;
    /**
    * The GCS or S3 bucket where the source resides. Required for GCS and S3 sourcse, invalid for HTTP and AppStoreConnect sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#bucket ProjectSymbolSource#bucket}
    */
    readonly bucket?: string;
    /**
    * The GCS email address for authentication. Required for GCS sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#client_email ProjectSymbolSource#client_email}
    */
    readonly clientEmail?: string;
    /**
    * Layout settings for the source. This is required for HTTP, GCS, and S3 sources and invalid for AppStoreConnect sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#layout ProjectSymbolSource#layout}
    */
    readonly layout?: ProjectSymbolSourceLayout;
    /**
    * The human-readable name of the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#name ProjectSymbolSource#name}
    */
    readonly name: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#organization ProjectSymbolSource#organization}
    */
    readonly organization: string;
    /**
    * The password for accessing the source. Optional for HTTP sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#password ProjectSymbolSource#password}
    */
    readonly password?: string;
    /**
    * The GCS or S3 prefix. Optional for GCS and S3 sourcse, invalid for HTTP and AppStoreConnect sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#prefix ProjectSymbolSource#prefix}
    */
    readonly prefix?: string;
    /**
    * The GCS private key. Required for GCS sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#private_key ProjectSymbolSource#private_key}
    */
    readonly privateKey?: string;
    /**
    * The project of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#project ProjectSymbolSource#project}
    */
    readonly project: string;
    /**
    * The source's S3 region. Required for S3 sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#region ProjectSymbolSource#region}
    */
    readonly region?: string;
    /**
    * The AWS Secret Access Key.Required for S3 sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#secret_key ProjectSymbolSource#secret_key}
    */
    readonly secretKey?: string;
    /**
    * The type of symbol source. One of `appStoreConnect` (App Store Connect), `http` (SymbolServer (HTTP)), `gcs` (Google Cloud Storage), `s3` (Amazon S3).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#type ProjectSymbolSource#type}
    */
    readonly type: string;
    /**
    * The source's URL. Optional for HTTP sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#url ProjectSymbolSource#url}
    */
    readonly url?: string;
    /**
    * The user name for accessing the source. Optional for HTTP sources, invalid for all others.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#username ProjectSymbolSource#username}
    */
    readonly username?: string;
}
export interface ProjectSymbolSourceLayout {
    /**
    * The casing of the symbol source layout. The layout of the folder structure. The options are: `default` - Default (mixed case), `uppercase` - Uppercase, `lowercase` - Lowercase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#casing ProjectSymbolSource#casing}
    */
    readonly casing: string;
    /**
    * The layout of the folder structure. The options are: `native` - Platform-Specific (SymStore / GDB / LLVM), `symstore` - Microsoft SymStore, `symstore_index2` - Microsoft SymStore (with index2.txt), `ssqp` - Microsoft SSQP, `unified` - Unified Symbol Server Layout, `debuginfod` - debuginfod.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#type ProjectSymbolSource#type}
    */
    readonly type: string;
}
export declare function projectSymbolSourceLayoutToTerraform(struct?: ProjectSymbolSourceLayout | cdktf.IResolvable): any;
export declare function projectSymbolSourceLayoutToHclTerraform(struct?: ProjectSymbolSourceLayout | cdktf.IResolvable): any;
export declare class ProjectSymbolSourceLayoutOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectSymbolSourceLayout | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectSymbolSourceLayout | cdktf.IResolvable | undefined);
    private _casing?;
    get casing(): string;
    set casing(value: string);
    get casingInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source sentry_project_symbol_source}
*/
export declare class ProjectSymbolSource extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_project_symbol_source";
    /**
    * Generates CDKTF code for importing a ProjectSymbolSource resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectSymbolSource to import
    * @param importFromId The id of the existing ProjectSymbolSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectSymbolSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_symbol_source sentry_project_symbol_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectSymbolSourceConfig
    */
    constructor(scope: Construct, id: string, config: ProjectSymbolSourceConfig);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _appConnectIssuer?;
    get appConnectIssuer(): string;
    set appConnectIssuer(value: string);
    resetAppConnectIssuer(): void;
    get appConnectIssuerInput(): string | undefined;
    private _appConnectPrivateKey?;
    get appConnectPrivateKey(): string;
    set appConnectPrivateKey(value: string);
    resetAppConnectPrivateKey(): void;
    get appConnectPrivateKeyInput(): string | undefined;
    private _appId?;
    get appId(): string;
    set appId(value: string);
    resetAppId(): void;
    get appIdInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _clientEmail?;
    get clientEmail(): string;
    set clientEmail(value: string);
    resetClientEmail(): void;
    get clientEmailInput(): string | undefined;
    get id(): string;
    private _layout;
    get layout(): ProjectSymbolSourceLayoutOutputReference;
    putLayout(value: ProjectSymbolSourceLayout): void;
    resetLayout(): void;
    get layoutInput(): cdktf.IResolvable | ProjectSymbolSourceLayout | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
