import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryAllKeysConfig extends cdktf.TerraformMetaArguments {
    /**
    * Filter client keys by `active` or `inactive`. Defaults to returning all keys if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_keys#filter_status DataSentryAllKeys#filter_status}
    */
    readonly filterStatus?: string;
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_keys#organization DataSentryAllKeys#organization}
    */
    readonly organization: string;
    /**
    * The project the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_keys#project DataSentryAllKeys#project}
    */
    readonly project: string;
}
export interface DataSentryAllKeysKeysJavascriptLoaderScript {
}
export declare function dataSentryAllKeysKeysJavascriptLoaderScriptToTerraform(struct?: DataSentryAllKeysKeysJavascriptLoaderScript): any;
export declare function dataSentryAllKeysKeysJavascriptLoaderScriptToHclTerraform(struct?: DataSentryAllKeysKeysJavascriptLoaderScript): any;
export declare class DataSentryAllKeysKeysJavascriptLoaderScriptOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryAllKeysKeysJavascriptLoaderScript | undefined;
    set internalValue(value: DataSentryAllKeysKeysJavascriptLoaderScript | undefined);
    get browserSdkVersion(): string;
    get debugEnabled(): cdktf.IResolvable;
    get performanceMonitoringEnabled(): cdktf.IResolvable;
    get sessionReplayEnabled(): cdktf.IResolvable;
}
export interface DataSentryAllKeysKeys {
}
export declare function dataSentryAllKeysKeysToTerraform(struct?: DataSentryAllKeysKeys): any;
export declare function dataSentryAllKeysKeysToHclTerraform(struct?: DataSentryAllKeysKeys): any;
export declare class DataSentryAllKeysKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryAllKeysKeys | undefined;
    set internalValue(value: DataSentryAllKeysKeys | undefined);
    private _dsn;
    get dsn(): cdktf.StringMap;
    get dsnCsp(): string;
    get dsnPublic(): string;
    get dsnSecret(): string;
    get id(): string;
    private _javascriptLoaderScript;
    get javascriptLoaderScript(): DataSentryAllKeysKeysJavascriptLoaderScriptOutputReference;
    get name(): string;
    get organization(): string;
    get project(): string;
    get projectId(): string;
    get public(): string;
    get rateLimitCount(): number;
    get rateLimitWindow(): number;
    get secret(): string;
}
export declare class DataSentryAllKeysKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryAllKeysKeysOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_keys sentry_all_keys}
*/
export declare class DataSentryAllKeys extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_all_keys";
    /**
    * Generates CDKTF code for importing a DataSentryAllKeys resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryAllKeys to import
    * @param importFromId The id of the existing DataSentryAllKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryAllKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_keys sentry_all_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryAllKeysConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryAllKeysConfig);
    private _filterStatus?;
    get filterStatus(): string;
    set filterStatus(value: string);
    resetFilterStatus(): void;
    get filterStatusInput(): string | undefined;
    private _keys;
    get keys(): DataSentryAllKeysKeysList;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
