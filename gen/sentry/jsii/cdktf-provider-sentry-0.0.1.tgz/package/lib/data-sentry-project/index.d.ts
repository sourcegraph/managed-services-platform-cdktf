import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryProjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * The organization slug.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project#organization DataSentryProject#organization}
    */
    readonly organization: string;
    /**
    * The unique URL slug for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project#slug DataSentryProject#slug}
    */
    readonly slug: string;
}
export interface DataSentryProjectTeams {
}
export declare function dataSentryProjectTeamsToTerraform(struct?: DataSentryProjectTeams): any;
export declare function dataSentryProjectTeamsToHclTerraform(struct?: DataSentryProjectTeams): any;
export declare class DataSentryProjectTeamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryProjectTeams | undefined;
    set internalValue(value: DataSentryProjectTeams | undefined);
    get internalId(): string;
    get name(): string;
    get slug(): string;
}
export declare class DataSentryProjectTeamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryProjectTeamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project sentry_project}
*/
export declare class DataSentryProject extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_project";
    /**
    * Generates CDKTF code for importing a DataSentryProject resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryProject to import
    * @param importFromId The id of the existing DataSentryProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project sentry_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryProjectConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryProjectConfig);
    get color(): string;
    get dateCreated(): string;
    get features(): string[];
    get id(): string;
    get internalId(): string;
    get isPublic(): cdktf.IResolvable;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get platform(): string;
    private _slug?;
    get slug(): string;
    set slug(value: string);
    get slugInput(): string | undefined;
    get subjectTemplate(): string;
    private _teams;
    get teams(): DataSentryProjectTeamsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
