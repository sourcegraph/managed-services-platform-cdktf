import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AllProjectsSpikeProtectionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Toggle the browser-extensions, localhost, filtered-transaction, or web-crawlers filter on or off for all projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/all_projects_spike_protection#enabled AllProjectsSpikeProtection#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/all_projects_spike_protection#organization AllProjectsSpikeProtection#organization}
    */
    readonly organization: string;
    /**
    * The slugs of the projects to enable or disable spike protection for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/all_projects_spike_protection#projects AllProjectsSpikeProtection#projects}
    */
    readonly projects: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/all_projects_spike_protection sentry_all_projects_spike_protection}
*/
export declare class AllProjectsSpikeProtection extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_all_projects_spike_protection";
    /**
    * Generates CDKTF code for importing a AllProjectsSpikeProtection resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AllProjectsSpikeProtection to import
    * @param importFromId The id of the existing AllProjectsSpikeProtection that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/all_projects_spike_protection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AllProjectsSpikeProtection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/all_projects_spike_protection sentry_all_projects_spike_protection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AllProjectsSpikeProtectionConfig
    */
    constructor(scope: Construct, id: string, config: AllProjectsSpikeProtectionConfig);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _projects?;
    get projects(): string[];
    set projects(value: string[]);
    get projectsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
