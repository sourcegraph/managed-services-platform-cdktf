import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DashboardConfig extends cdktf.TerraformMetaArguments {
    /**
    * The slug of the organization the dashboard belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#organization Dashboard#organization}
    */
    readonly organization: string;
    /**
    * Dashboard title.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title: string;
    /**
    * widget block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#widget Dashboard#widget}
    */
    readonly widget?: DashboardWidget[] | cdktf.IResolvable;
}
export interface DashboardWidgetLayout {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#h Dashboard#h}
    */
    readonly h: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#min_h Dashboard#min_h}
    */
    readonly minH: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#w Dashboard#w}
    */
    readonly w: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#x Dashboard#x}
    */
    readonly x: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#y Dashboard#y}
    */
    readonly y: number;
}
export declare function dashboardWidgetLayoutToTerraform(struct?: DashboardWidgetLayoutOutputReference | DashboardWidgetLayout): any;
export declare function dashboardWidgetLayoutToHclTerraform(struct?: DashboardWidgetLayoutOutputReference | DashboardWidgetLayout): any;
export declare class DashboardWidgetLayoutOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetLayout | undefined;
    set internalValue(value: DashboardWidgetLayout | undefined);
    private _h?;
    get h(): number;
    set h(value: number);
    get hInput(): number | undefined;
    private _minH?;
    get minH(): number;
    set minH(value: number);
    get minHInput(): number | undefined;
    private _w?;
    get w(): number;
    set w(value: number);
    get wInput(): number | undefined;
    private _x?;
    get x(): number;
    set x(value: number);
    get xInput(): number | undefined;
    private _y?;
    get y(): number;
    set y(value: number);
    get yInput(): number | undefined;
}
export interface DashboardWidgetQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#aggregates Dashboard#aggregates}
    */
    readonly aggregates?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#columns Dashboard#columns}
    */
    readonly columns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#conditions Dashboard#conditions}
    */
    readonly conditions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#field_aliases Dashboard#field_aliases}
    */
    readonly fieldAliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#fields Dashboard#fields}
    */
    readonly fields?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#order_by Dashboard#order_by}
    */
    readonly orderBy?: string;
}
export declare function dashboardWidgetQueryToTerraform(struct?: DashboardWidgetQuery | cdktf.IResolvable): any;
export declare function dashboardWidgetQueryToHclTerraform(struct?: DashboardWidgetQuery | cdktf.IResolvable): any;
export declare class DashboardWidgetQueryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetQuery | cdktf.IResolvable | undefined;
    set internalValue(value: DashboardWidgetQuery | cdktf.IResolvable | undefined);
    private _aggregates?;
    get aggregates(): string[];
    set aggregates(value: string[]);
    resetAggregates(): void;
    get aggregatesInput(): string[] | undefined;
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    resetColumns(): void;
    get columnsInput(): string[] | undefined;
    private _conditions?;
    get conditions(): string;
    set conditions(value: string);
    resetConditions(): void;
    get conditionsInput(): string | undefined;
    private _fieldAliases?;
    get fieldAliases(): string[];
    set fieldAliases(value: string[]);
    resetFieldAliases(): void;
    get fieldAliasesInput(): string[] | undefined;
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    resetFields(): void;
    get fieldsInput(): string[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
}
export declare class DashboardWidgetQueryList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DashboardWidgetQuery[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetQueryOutputReference;
}
export interface DashboardWidget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#display_type Dashboard#display_type}
    */
    readonly displayType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#widget_type Dashboard#widget_type}
    */
    readonly widgetType?: string;
    /**
    * layout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#layout Dashboard#layout}
    */
    readonly layout: DashboardWidgetLayout;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: DashboardWidgetQuery[] | cdktf.IResolvable;
}
export declare function dashboardWidgetToTerraform(struct?: DashboardWidget | cdktf.IResolvable): any;
export declare function dashboardWidgetToHclTerraform(struct?: DashboardWidget | cdktf.IResolvable): any;
export declare class DashboardWidgetOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidget | cdktf.IResolvable | undefined;
    set internalValue(value: DashboardWidget | cdktf.IResolvable | undefined);
    private _displayType?;
    get displayType(): string;
    set displayType(value: string);
    get displayTypeInput(): string | undefined;
    get id(): string;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _widgetType?;
    get widgetType(): string;
    set widgetType(value: string);
    resetWidgetType(): void;
    get widgetTypeInput(): string | undefined;
    private _layout;
    get layout(): DashboardWidgetLayoutOutputReference;
    putLayout(value: DashboardWidgetLayout): void;
    get layoutInput(): DashboardWidgetLayout | undefined;
    private _query;
    get query(): DashboardWidgetQueryList;
    putQuery(value: DashboardWidgetQuery[] | cdktf.IResolvable): void;
    get queryInput(): cdktf.IResolvable | DashboardWidgetQuery[] | undefined;
}
export declare class DashboardWidgetList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DashboardWidget[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard sentry_dashboard}
*/
export declare class Dashboard extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_dashboard";
    /**
    * Generates CDKTF code for importing a Dashboard resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Dashboard to import
    * @param importFromId The id of the existing Dashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Dashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/dashboard sentry_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DashboardConfig
    */
    constructor(scope: Construct, id: string, config: DashboardConfig);
    get id(): string;
    get internalId(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _widget;
    get widget(): DashboardWidgetList;
    putWidget(value: DashboardWidget[] | cdktf.IResolvable): void;
    resetWidget(): void;
    get widgetInput(): cdktf.IResolvable | DashboardWidget[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
