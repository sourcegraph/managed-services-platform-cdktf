import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NotificationActionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the integration that is used for sending the notification. Use the `sentry_organization_integration` data source to retrieve an integration. Required if `service_type` is `slack`, `pagerduty` or `opsgenie`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#integration_id NotificationAction#integration_id}
    */
    readonly integrationId?: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#organization NotificationAction#organization}
    */
    readonly organization: string;
    /**
    * The list of project slugs that the Notification Action is created for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#projects NotificationAction#projects}
    */
    readonly projects: string[];
    /**
    * The service that is used for sending the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#service_type NotificationAction#service_type}
    */
    readonly serviceType: string;
    /**
    * The display name of the target that is used for sending the notification (e.g. Slack channel name). Required if `service_type` is `slack` or `opsgenie`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#target_display NotificationAction#target_display}
    */
    readonly targetDisplay?: string;
    /**
    * The identifier of the target that is used for sending the notification (e.g. Slack channel ID). Required if `service_type` is `slack` or `opsgenie`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#target_identifier NotificationAction#target_identifier}
    */
    readonly targetIdentifier?: string;
    /**
    * The type of trigger that will activate this action. Valid values are `spike-protection`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#trigger_type NotificationAction#trigger_type}
    */
    readonly triggerType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action sentry_notification_action}
*/
export declare class NotificationAction extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_notification_action";
    /**
    * Generates CDKTF code for importing a NotificationAction resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationAction to import
    * @param importFromId The id of the existing NotificationAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/notification_action sentry_notification_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationActionConfig
    */
    constructor(scope: Construct, id: string, config: NotificationActionConfig);
    get id(): string;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    resetIntegrationId(): void;
    get integrationIdInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _projects?;
    get projects(): string[];
    set projects(value: string[]);
    get projectsInput(): string[] | undefined;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    get serviceTypeInput(): string | undefined;
    private _targetDisplay?;
    get targetDisplay(): string;
    set targetDisplay(value: string);
    resetTargetDisplay(): void;
    get targetDisplayInput(): string | undefined;
    private _targetIdentifier?;
    get targetIdentifier(): string;
    set targetIdentifier(value: string);
    resetTargetIdentifier(): void;
    get targetIdentifierInput(): string | undefined;
    private _triggerType?;
    get triggerType(): string;
    set triggerType(value: string);
    get triggerTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
