import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryOrganizationIntegrationsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integrations#organization DataSentryOrganizationIntegrations#organization}
    */
    readonly organization: string;
    /**
    * Specific integration provider to filter by such as `slack`. See [the list of supported providers](https://docs.sentry.io/integrations/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integrations#provider_key DataSentryOrganizationIntegrations#provider_key}
    */
    readonly providerKey?: string;
}
export interface DataSentryOrganizationIntegrationsIntegrations {
}
export declare function dataSentryOrganizationIntegrationsIntegrationsToTerraform(struct?: DataSentryOrganizationIntegrationsIntegrations): any;
export declare function dataSentryOrganizationIntegrationsIntegrationsToHclTerraform(struct?: DataSentryOrganizationIntegrationsIntegrations): any;
export declare class DataSentryOrganizationIntegrationsIntegrationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryOrganizationIntegrationsIntegrations | undefined;
    set internalValue(value: DataSentryOrganizationIntegrationsIntegrations | undefined);
    get id(): string;
    get name(): string;
    get providerKey(): string;
    get rawJson(): string;
}
export declare class DataSentryOrganizationIntegrationsIntegrationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryOrganizationIntegrationsIntegrationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integrations sentry_organization_integrations}
*/
export declare class DataSentryOrganizationIntegrations extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_organization_integrations";
    /**
    * Generates CDKTF code for importing a DataSentryOrganizationIntegrations resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryOrganizationIntegrations to import
    * @param importFromId The id of the existing DataSentryOrganizationIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryOrganizationIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integrations sentry_organization_integrations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryOrganizationIntegrationsConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryOrganizationIntegrationsConfig);
    private _integrations;
    get integrations(): DataSentryOrganizationIntegrationsIntegrationsList;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _providerKey?;
    get providerKey(): string;
    set providerKey(value: string);
    resetProviderKey(): void;
    get providerKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
