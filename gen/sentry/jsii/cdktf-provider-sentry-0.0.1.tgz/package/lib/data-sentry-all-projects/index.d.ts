import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryAllProjectsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The organization slug or internal ID to list projects for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_projects#organization DataSentryAllProjects#organization}
    */
    readonly organization: string;
}
export interface DataSentryAllProjectsProjectsTeams {
}
export declare function dataSentryAllProjectsProjectsTeamsToTerraform(struct?: DataSentryAllProjectsProjectsTeams): any;
export declare function dataSentryAllProjectsProjectsTeamsToHclTerraform(struct?: DataSentryAllProjectsProjectsTeams): any;
export declare class DataSentryAllProjectsProjectsTeamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryAllProjectsProjectsTeams | undefined;
    set internalValue(value: DataSentryAllProjectsProjectsTeams | undefined);
    get internalId(): string;
    get name(): string;
    get slug(): string;
}
export declare class DataSentryAllProjectsProjectsTeamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryAllProjectsProjectsTeamsOutputReference;
}
export interface DataSentryAllProjectsProjects {
}
export declare function dataSentryAllProjectsProjectsToTerraform(struct?: DataSentryAllProjectsProjects): any;
export declare function dataSentryAllProjectsProjectsToHclTerraform(struct?: DataSentryAllProjectsProjects): any;
export declare class DataSentryAllProjectsProjectsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryAllProjectsProjects | undefined;
    set internalValue(value: DataSentryAllProjectsProjects | undefined);
    get color(): string;
    get dateCreated(): string;
    get features(): string[];
    get internalId(): string;
    get name(): string;
    get platform(): string;
    get slug(): string;
    private _teams;
    get teams(): DataSentryAllProjectsProjectsTeamsList;
}
export declare class DataSentryAllProjectsProjectsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryAllProjectsProjectsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_projects sentry_all_projects}
*/
export declare class DataSentryAllProjects extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_all_projects";
    /**
    * Generates CDKTF code for importing a DataSentryAllProjects resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryAllProjects to import
    * @param importFromId The id of the existing DataSentryAllProjects that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_projects#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryAllProjects to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_projects sentry_all_projects} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryAllProjectsConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryAllProjectsConfig);
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get projectSlugs(): string[];
    private _projects;
    get projects(): DataSentryAllProjectsProjectsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
