import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryOrganizationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The unique URL slug for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization#slug DataSentryOrganization#slug}
    */
    readonly slug: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization sentry_organization}
*/
export declare class DataSentryOrganization extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_organization";
    /**
    * Generates CDKTF code for importing a DataSentryOrganization resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryOrganization to import
    * @param importFromId The id of the existing DataSentryOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization sentry_organization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryOrganizationConfig);
    get id(): string;
    get internalId(): string;
    get name(): string;
    private _slug?;
    get slug(): string;
    set slug(value: string);
    get slugInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
