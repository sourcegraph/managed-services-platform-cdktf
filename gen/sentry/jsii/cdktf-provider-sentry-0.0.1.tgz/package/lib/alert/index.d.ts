import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlertConfig extends cdktf.TerraformMetaArguments {
    /**
    * The filters to run before the action will fire and the action(s) to fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#action_filters Alert#action_filters}
    */
    readonly actionFilters: AlertActionFilters[] | cdktf.IResolvable;
    /**
    * Whether the alert is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#enabled Alert#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * The environment to filter alerts to. Omit or set to `null` to apply to all environments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#environment Alert#environment}
    */
    readonly environment?: string;
    /**
    * How often the alert should fire in minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#frequency_minutes Alert#frequency_minutes}
    */
    readonly frequencyMinutes: number;
    /**
    * ⚠️ The trigger condition types listed here are not natively supported by this provider and may be deprecated by Sentry in a future API version. Trigger condition types present on this alert that are not representable in `trigger_conditions` (e.g. `new_high_priority_issue`, `existing_high_priority_issue`, `issue_resolution_change`). When omitted from config these will be removed on the next apply. Set explicitly to preserve them.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#legacy_trigger_conditions Alert#legacy_trigger_conditions}
    */
    readonly legacyTriggerConditions?: string[];
    /**
    * The IDs of the monitors to create alerts for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#monitor_ids Alert#monitor_ids}
    */
    readonly monitorIds: string[];
    /**
    * The name of this alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#name Alert#name}
    */
    readonly name: string;
    /**
    * The organization slug or internal ID to create the alert for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#organization Alert#organization}
    */
    readonly organization: string;
    /**
    * The conditions on which the alert will trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#trigger_conditions Alert#trigger_conditions}
    */
    readonly triggerConditions?: AlertTriggerConditions[] | cdktf.IResolvable;
}
export interface AlertActionFiltersActionsDiscord {
    /**
    * The ID of the Discord channel to send the notification to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#channel_id Alert#channel_id}
    */
    readonly channelId: string;
    /**
    * The ID of the Discord integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * A list of tags to show in the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#tags Alert#tags}
    */
    readonly tags?: string;
}
export declare function alertActionFiltersActionsDiscordToTerraform(struct?: AlertActionFiltersActionsDiscord | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsDiscordToHclTerraform(struct?: AlertActionFiltersActionsDiscord | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsDiscordOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsDiscord | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsDiscord | cdktf.IResolvable | undefined);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    get channelIdInput(): string | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _tags?;
    get tags(): string;
    set tags(value: string);
    resetTags(): void;
    get tagsInput(): string | undefined;
}
export interface AlertActionFiltersActionsEmail {
    /**
    * The type of fallthrough to apply when choosing to notify issue owners. Only required if the target type is `issue_owners`. Valid values are: `AllMembers`, `ActiveMembers`, and `NoOne`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#fallthrough_type Alert#fallthrough_type}
    */
    readonly fallthroughType?: string;
    /**
    * The internal ID of the user or team. Only required if the target type is `team` or `user`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#target_id Alert#target_id}
    */
    readonly targetId?: string;
    /**
    * The type of recipient to notify. Valid values are: `issue_owners`, `team`, and `user`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#target_type Alert#target_type}
    */
    readonly targetType: string;
}
export declare function alertActionFiltersActionsEmailToTerraform(struct?: AlertActionFiltersActionsEmail | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsEmailToHclTerraform(struct?: AlertActionFiltersActionsEmail | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsEmailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsEmail | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsEmail | cdktf.IResolvable | undefined);
    private _fallthroughType?;
    get fallthroughType(): string;
    set fallthroughType(value: string);
    resetFallthroughType(): void;
    get fallthroughTypeInput(): string | undefined;
    private _targetId?;
    get targetId(): string;
    set targetId(value: string);
    resetTargetId(): void;
    get targetIdInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
}
export interface AlertActionFiltersActionsGithub {
    /**
    * The GitHub user to assign the issue to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#assignee Alert#assignee}
    */
    readonly assignee?: string;
    /**
    * The ID of the GitHub integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * A list of labels to assign to the issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#labels Alert#labels}
    */
    readonly labels?: string[];
    /**
    * The name of the repository to create the issue in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#repo Alert#repo}
    */
    readonly repo: string;
}
export declare function alertActionFiltersActionsGithubToTerraform(struct?: AlertActionFiltersActionsGithub | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsGithubToHclTerraform(struct?: AlertActionFiltersActionsGithub | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsGithubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsGithub | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsGithub | cdktf.IResolvable | undefined);
    private _assignee?;
    get assignee(): string;
    set assignee(value: string);
    resetAssignee(): void;
    get assigneeInput(): string | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    get repoInput(): string | undefined;
}
export interface AlertActionFiltersActionsJira {
    /**
    * Additional Jira fields to set on the created issue, keyed by Jira field ID (e.g. `customfield_10101`). Use this for custom fields and any built-in field not exposed above. Sentry's API converts camelCase keys to snake_case on write, which corrupts them, so camelCase field IDs must be written all-lowercase: use `fixversions`, not `fixVersions`. Jira matches field IDs case-insensitively, so the lowercase spelling resolves to the same field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#additional_fields Alert#additional_fields}
    */
    readonly additionalFields?: {
        [key: string]: string;
    };
    /**
    * The IDs of the Jira components to assign to the issue, used for triage routing. These are component IDs, not names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#components Alert#components}
    */
    readonly components?: string[];
    /**
    * The ID of the Jira integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * The ID of the type of issue that the ticket should be created as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_type Alert#issue_type}
    */
    readonly issueType: string;
    /**
    * A comma-separated list of labels to add to the issue (e.g. `oncall,triage`). Note: unlike the `github` action's `labels`, Jira expects a single comma-separated string rather than a list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#labels Alert#labels}
    */
    readonly labels?: string;
    /**
    * The ID of the priority to set on the issue. This is a priority ID, not a name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#priority Alert#priority}
    */
    readonly priority?: string;
    /**
    * The ID of the Jira project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#project Alert#project}
    */
    readonly project: string;
    /**
    * The Jira account ID of the user to set as the reporter of the issue. Useful for attributing automated tickets to a service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#reporter Alert#reporter}
    */
    readonly reporter?: string;
}
export declare function alertActionFiltersActionsJiraToTerraform(struct?: AlertActionFiltersActionsJira | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsJiraToHclTerraform(struct?: AlertActionFiltersActionsJira | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsJiraOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsJira | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsJira | cdktf.IResolvable | undefined);
    private _additionalFields?;
    get additionalFields(): {
        [key: string]: string;
    };
    set additionalFields(value: {
        [key: string]: string;
    });
    resetAdditionalFields(): void;
    get additionalFieldsInput(): {
        [key: string]: string;
    } | undefined;
    private _components?;
    get components(): string[];
    set components(value: string[]);
    resetComponents(): void;
    get componentsInput(): string[] | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _issueType?;
    get issueType(): string;
    set issueType(value: string);
    get issueTypeInput(): string | undefined;
    private _labels?;
    get labels(): string;
    set labels(value: string);
    resetLabels(): void;
    get labelsInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _reporter?;
    get reporter(): string;
    set reporter(value: string);
    resetReporter(): void;
    get reporterInput(): string | undefined;
}
export interface AlertActionFiltersActionsJiraServer {
    /**
    * Additional Jira Server fields to set on the created issue, keyed by Jira Server field ID (e.g. `customfield_10101`). Use this for custom fields and any built-in field not exposed above. Sentry's API converts camelCase keys to snake_case on write, which corrupts them, so camelCase field IDs must be written all-lowercase: use `fixversions`, not `fixVersions`. Jira matches field IDs case-insensitively, so the lowercase spelling resolves to the same field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#additional_fields Alert#additional_fields}
    */
    readonly additionalFields?: {
        [key: string]: string;
    };
    /**
    * The IDs of the Jira Server components to assign to the issue, used for triage routing. These are component IDs, not names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#components Alert#components}
    */
    readonly components?: string[];
    /**
    * The ID of the Jira Server integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * The ID of the type of issue that the ticket should be created as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_type Alert#issue_type}
    */
    readonly issueType: string;
    /**
    * A comma-separated list of labels to add to the issue (e.g. `oncall,triage`). Note: unlike the `github` action's `labels`, Jira Server expects a single comma-separated string rather than a list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#labels Alert#labels}
    */
    readonly labels?: string;
    /**
    * The ID of the priority to set on the issue. This is a priority ID, not a name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#priority Alert#priority}
    */
    readonly priority?: string;
    /**
    * The ID of the Jira project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#project Alert#project}
    */
    readonly project: string;
    /**
    * The Jira Server username of the user to set as the reporter of the issue. Useful for attributing automated tickets to a service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#reporter Alert#reporter}
    */
    readonly reporter?: string;
}
export declare function alertActionFiltersActionsJiraServerToTerraform(struct?: AlertActionFiltersActionsJiraServer | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsJiraServerToHclTerraform(struct?: AlertActionFiltersActionsJiraServer | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsJiraServerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsJiraServer | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsJiraServer | cdktf.IResolvable | undefined);
    private _additionalFields?;
    get additionalFields(): {
        [key: string]: string;
    };
    set additionalFields(value: {
        [key: string]: string;
    });
    resetAdditionalFields(): void;
    get additionalFieldsInput(): {
        [key: string]: string;
    } | undefined;
    private _components?;
    get components(): string[];
    set components(value: string[]);
    resetComponents(): void;
    get componentsInput(): string[] | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _issueType?;
    get issueType(): string;
    set issueType(value: string);
    get issueTypeInput(): string | undefined;
    private _labels?;
    get labels(): string;
    set labels(value: string);
    resetLabels(): void;
    get labelsInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _reporter?;
    get reporter(): string;
    set reporter(value: string);
    resetReporter(): void;
    get reporterInput(): string | undefined;
}
export interface AlertActionFiltersActionsMsteams {
    /**
    * The name of the Microsoft Teams channel to send the notification to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#channel_name Alert#channel_name}
    */
    readonly channelName: string;
    /**
    * The ID of the Microsoft Teams integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * The integration ID associated with the Microsoft Teams team.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#team_id Alert#team_id}
    */
    readonly teamId: string;
}
export declare function alertActionFiltersActionsMsteamsToTerraform(struct?: AlertActionFiltersActionsMsteams | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsMsteamsToHclTerraform(struct?: AlertActionFiltersActionsMsteams | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsMsteamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsMsteams | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsMsteams | cdktf.IResolvable | undefined);
    private _channelName?;
    get channelName(): string;
    set channelName(value: string);
    get channelNameInput(): string | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    get teamThreadId(): string;
}
export interface AlertActionFiltersActionsOpsgenie {
    /**
    * The ID of the OpsGenie integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * The priority level for the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#priority Alert#priority}
    */
    readonly priority: string;
    /**
    * The ID of the Opsgenie team to send the notification to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#team_id Alert#team_id}
    */
    readonly teamId: string;
    /**
    * The name of the Opsgenie team.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#team_name Alert#team_name}
    */
    readonly teamName: string;
}
export declare function alertActionFiltersActionsOpsgenieToTerraform(struct?: AlertActionFiltersActionsOpsgenie | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsOpsgenieToHclTerraform(struct?: AlertActionFiltersActionsOpsgenie | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsOpsgenieOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsOpsgenie | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsOpsgenie | cdktf.IResolvable | undefined);
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    get priorityInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _teamName?;
    get teamName(): string;
    set teamName(value: string);
    get teamNameInput(): string | undefined;
}
export interface AlertActionFiltersActionsPagerduty {
    /**
    * The ID of the PagerDuty integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * The ID of the PagerDuty service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#service_id Alert#service_id}
    */
    readonly serviceId: string;
    /**
    * The name of the service to create the ticket in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#service_name Alert#service_name}
    */
    readonly serviceName: string;
    /**
    * The PagerDuty severity level for the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#severity Alert#severity}
    */
    readonly severity: string;
}
export declare function alertActionFiltersActionsPagerdutyToTerraform(struct?: AlertActionFiltersActionsPagerduty | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsPagerdutyToHclTerraform(struct?: AlertActionFiltersActionsPagerduty | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsPagerdutyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsPagerduty | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsPagerduty | cdktf.IResolvable | undefined);
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    get severityInput(): string | undefined;
}
export interface AlertActionFiltersActionsPlugin {
}
export declare function alertActionFiltersActionsPluginToTerraform(struct?: AlertActionFiltersActionsPlugin | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsPluginToHclTerraform(struct?: AlertActionFiltersActionsPlugin | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsPluginOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsPlugin | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsPlugin | cdktf.IResolvable | undefined);
}
export interface AlertActionFiltersActionsSentryAppSettings {
    /**
    * The human-readable display label for the value. Required for async select fields whose option list is paginated by the third-party app — without it the field may appear blank under certain conditions in the Sentry UI after apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#label Alert#label}
    */
    readonly label?: string;
    /**
    * The name of the setting field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#name Alert#name}
    */
    readonly name: string;
    /**
    * The value of the setting field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: string;
}
export declare function alertActionFiltersActionsSentryAppSettingsToTerraform(struct?: AlertActionFiltersActionsSentryAppSettings | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsSentryAppSettingsToHclTerraform(struct?: AlertActionFiltersActionsSentryAppSettings | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsSentryAppSettingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFiltersActionsSentryAppSettings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsSentryAppSettings | cdktf.IResolvable | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class AlertActionFiltersActionsSentryAppSettingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFiltersActionsSentryAppSettings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersActionsSentryAppSettingsOutputReference;
}
export interface AlertActionFiltersActionsSentryApp {
    /**
    * The numeric Sentry App ID. Use `tostring(data.sentry_app_installation.<name>.sentry_app_id)` to source this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#sentry_app_id Alert#sentry_app_id}
    */
    readonly sentryAppId: string;
    /**
    * Key-value settings passed to the Sentry App action. Specifying `label` preserves the human-readable display name in the Sentry UI for async select fields whose options are paginated by the third-party app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#settings Alert#settings}
    */
    readonly settings?: AlertActionFiltersActionsSentryAppSettings[] | cdktf.IResolvable;
}
export declare function alertActionFiltersActionsSentryAppToTerraform(struct?: AlertActionFiltersActionsSentryApp | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsSentryAppToHclTerraform(struct?: AlertActionFiltersActionsSentryApp | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsSentryAppOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsSentryApp | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsSentryApp | cdktf.IResolvable | undefined);
    private _sentryAppId?;
    get sentryAppId(): string;
    set sentryAppId(value: string);
    get sentryAppIdInput(): string | undefined;
    private _settings;
    get settings(): AlertActionFiltersActionsSentryAppSettingsList;
    putSettings(value: AlertActionFiltersActionsSentryAppSettings[] | cdktf.IResolvable): void;
    resetSettings(): void;
    get settingsInput(): cdktf.IResolvable | AlertActionFiltersActionsSentryAppSettings[] | undefined;
}
export interface AlertActionFiltersActionsSlack {
    /**
    * The Slack channel ID to send the notification to. This is an optional field that can be used to avoid rate-limiting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#channel_id Alert#channel_id}
    */
    readonly channelId?: string;
    /**
    * The name of the Slack channel to send the notification to (e.g., #critical, Jane Schmidt).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#channel_name Alert#channel_name}
    */
    readonly channelName: string;
    /**
    * The ID of the Slack integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * Text to show alongside the notification. To @ a user, include their user id like `@<USER_ID>`. To include a clickable link, format the link and title like `<http://example.com|Click Here>`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#notes Alert#notes}
    */
    readonly notes?: string;
    /**
    * A list of tags to show in the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#tags Alert#tags}
    */
    readonly tags?: string;
}
export declare function alertActionFiltersActionsSlackToTerraform(struct?: AlertActionFiltersActionsSlack | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsSlackToHclTerraform(struct?: AlertActionFiltersActionsSlack | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsSlackOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsSlack | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsSlack | cdktf.IResolvable | undefined);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    resetChannelId(): void;
    get channelIdInput(): string | undefined;
    private _channelName?;
    get channelName(): string;
    set channelName(value: string);
    get channelNameInput(): string | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _notes?;
    get notes(): string;
    set notes(value: string);
    resetNotes(): void;
    get notesInput(): string | undefined;
    private _tags?;
    get tags(): string;
    set tags(value: string);
    resetTags(): void;
    get tagsInput(): string | undefined;
}
export interface AlertActionFiltersActionsVsts {
    /**
    * The ID of the OpsGenie integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#integration_id Alert#integration_id}
    */
    readonly integrationId: string;
    /**
    * The ID of the Azure DevOps project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#project Alert#project}
    */
    readonly project: string;
    /**
    * The type of work item to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#work_item_type Alert#work_item_type}
    */
    readonly workItemType: string;
}
export declare function alertActionFiltersActionsVstsToTerraform(struct?: AlertActionFiltersActionsVsts | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsVstsToHclTerraform(struct?: AlertActionFiltersActionsVsts | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsVstsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsVsts | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsVsts | cdktf.IResolvable | undefined);
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _workItemType?;
    get workItemType(): string;
    set workItemType(value: string);
    get workItemTypeInput(): string | undefined;
}
export interface AlertActionFiltersActionsWebhook {
    /**
    * The slug of the integration service to notify. Use the special value `webhooks` to notify all legacy plugin webhooks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#service Alert#service}
    */
    readonly service: string;
}
export declare function alertActionFiltersActionsWebhookToTerraform(struct?: AlertActionFiltersActionsWebhook | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsWebhookToHclTerraform(struct?: AlertActionFiltersActionsWebhook | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsWebhookOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersActionsWebhook | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActionsWebhook | cdktf.IResolvable | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface AlertActionFiltersActions {
    /**
    * Notify on Discord.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#discord Alert#discord}
    */
    readonly discord?: AlertActionFiltersActionsDiscord;
    /**
    * Notify on Preferred Channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#email Alert#email}
    */
    readonly email?: AlertActionFiltersActionsEmail;
    /**
    * Create a GitHub issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#github Alert#github}
    */
    readonly github?: AlertActionFiltersActionsGithub;
    /**
    * Create a Jira ticket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#jira Alert#jira}
    */
    readonly jira?: AlertActionFiltersActionsJira;
    /**
    * Create a Jira Server ticket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#jira_server Alert#jira_server}
    */
    readonly jiraServer?: AlertActionFiltersActionsJiraServer;
    /**
    * Notify on Microsoft Teams.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#msteams Alert#msteams}
    */
    readonly msteams?: AlertActionFiltersActionsMsteams;
    /**
    * Notify on OpsGenie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#opsgenie Alert#opsgenie}
    */
    readonly opsgenie?: AlertActionFiltersActionsOpsgenie;
    /**
    * Notify on PagerDuty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#pagerduty Alert#pagerduty}
    */
    readonly pagerduty?: AlertActionFiltersActionsPagerduty;
    /**
    * Send a notification to all legacy integrations (plugins). **Deprecated** Action type plugin is deprecated and cannot be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#plugin Alert#plugin}
    */
    readonly plugin?: AlertActionFiltersActionsPlugin;
    /**
    * Trigger an action in a Sentry App (e.g. Rootly).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#sentry_app Alert#sentry_app}
    */
    readonly sentryApp?: AlertActionFiltersActionsSentryApp;
    /**
    * Notify on Slack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#slack Alert#slack}
    */
    readonly slack?: AlertActionFiltersActionsSlack;
    /**
    * Notify on Azure DevOps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#vsts Alert#vsts}
    */
    readonly vsts?: AlertActionFiltersActionsVsts;
    /**
    * Send a notification via a legacy integration service (e.g. an internal integration's webhook). This is the successor to the `notify_event_service` action on the legacy `sentry_issue_alert` resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#webhook Alert#webhook}
    */
    readonly webhook?: AlertActionFiltersActionsWebhook;
}
export declare function alertActionFiltersActionsToTerraform(struct?: AlertActionFiltersActions | cdktf.IResolvable): any;
export declare function alertActionFiltersActionsToHclTerraform(struct?: AlertActionFiltersActions | cdktf.IResolvable): any;
export declare class AlertActionFiltersActionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFiltersActions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersActions | cdktf.IResolvable | undefined);
    private _discord;
    get discord(): AlertActionFiltersActionsDiscordOutputReference;
    putDiscord(value: AlertActionFiltersActionsDiscord): void;
    resetDiscord(): void;
    get discordInput(): cdktf.IResolvable | AlertActionFiltersActionsDiscord | undefined;
    private _email;
    get email(): AlertActionFiltersActionsEmailOutputReference;
    putEmail(value: AlertActionFiltersActionsEmail): void;
    resetEmail(): void;
    get emailInput(): cdktf.IResolvable | AlertActionFiltersActionsEmail | undefined;
    private _github;
    get github(): AlertActionFiltersActionsGithubOutputReference;
    putGithub(value: AlertActionFiltersActionsGithub): void;
    resetGithub(): void;
    get githubInput(): cdktf.IResolvable | AlertActionFiltersActionsGithub | undefined;
    private _jira;
    get jira(): AlertActionFiltersActionsJiraOutputReference;
    putJira(value: AlertActionFiltersActionsJira): void;
    resetJira(): void;
    get jiraInput(): cdktf.IResolvable | AlertActionFiltersActionsJira | undefined;
    private _jiraServer;
    get jiraServer(): AlertActionFiltersActionsJiraServerOutputReference;
    putJiraServer(value: AlertActionFiltersActionsJiraServer): void;
    resetJiraServer(): void;
    get jiraServerInput(): cdktf.IResolvable | AlertActionFiltersActionsJiraServer | undefined;
    private _msteams;
    get msteams(): AlertActionFiltersActionsMsteamsOutputReference;
    putMsteams(value: AlertActionFiltersActionsMsteams): void;
    resetMsteams(): void;
    get msteamsInput(): cdktf.IResolvable | AlertActionFiltersActionsMsteams | undefined;
    private _opsgenie;
    get opsgenie(): AlertActionFiltersActionsOpsgenieOutputReference;
    putOpsgenie(value: AlertActionFiltersActionsOpsgenie): void;
    resetOpsgenie(): void;
    get opsgenieInput(): cdktf.IResolvable | AlertActionFiltersActionsOpsgenie | undefined;
    private _pagerduty;
    get pagerduty(): AlertActionFiltersActionsPagerdutyOutputReference;
    putPagerduty(value: AlertActionFiltersActionsPagerduty): void;
    resetPagerduty(): void;
    get pagerdutyInput(): cdktf.IResolvable | AlertActionFiltersActionsPagerduty | undefined;
    private _plugin;
    get plugin(): AlertActionFiltersActionsPluginOutputReference;
    putPlugin(value: AlertActionFiltersActionsPlugin): void;
    resetPlugin(): void;
    get pluginInput(): cdktf.IResolvable | AlertActionFiltersActionsPlugin | undefined;
    private _sentryApp;
    get sentryApp(): AlertActionFiltersActionsSentryAppOutputReference;
    putSentryApp(value: AlertActionFiltersActionsSentryApp): void;
    resetSentryApp(): void;
    get sentryAppInput(): cdktf.IResolvable | AlertActionFiltersActionsSentryApp | undefined;
    private _slack;
    get slack(): AlertActionFiltersActionsSlackOutputReference;
    putSlack(value: AlertActionFiltersActionsSlack): void;
    resetSlack(): void;
    get slackInput(): cdktf.IResolvable | AlertActionFiltersActionsSlack | undefined;
    private _vsts;
    get vsts(): AlertActionFiltersActionsVstsOutputReference;
    putVsts(value: AlertActionFiltersActionsVsts): void;
    resetVsts(): void;
    get vstsInput(): cdktf.IResolvable | AlertActionFiltersActionsVsts | undefined;
    private _webhook;
    get webhook(): AlertActionFiltersActionsWebhookOutputReference;
    putWebhook(value: AlertActionFiltersActionsWebhook): void;
    resetWebhook(): void;
    get webhookInput(): cdktf.IResolvable | AlertActionFiltersActionsWebhook | undefined;
}
export declare class AlertActionFiltersActionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFiltersActions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersActionsOutputReference;
}
export interface AlertActionFiltersConditionsAgeComparison {
    /**
    * The type of comparison to perform. Valid values are: `older`, and `newer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#comparison_type Alert#comparison_type}
    */
    readonly comparisonType: string;
    /**
    * The unit of time for the age comparison. Valid values are: `minute`, `hour`, `day`, and `week`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#time Alert#time}
    */
    readonly time: string;
    /**
    * The value of the age comparison.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsAgeComparisonToTerraform(struct?: AlertActionFiltersConditionsAgeComparison | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsAgeComparisonToHclTerraform(struct?: AlertActionFiltersConditionsAgeComparison | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsAgeComparisonOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsAgeComparison | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsAgeComparison | cdktf.IResolvable | undefined);
    private _comparisonType?;
    get comparisonType(): string;
    set comparisonType(value: string);
    get comparisonTypeInput(): string | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsAssignedTo {
    /**
    * The internal ID of the user or team. Only required if the target type is `Member` or `Team`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#target_id Alert#target_id}
    */
    readonly targetId?: string;
    /**
    * Who the issue is assigned to. Valid values are: `Unassigned`, `Member`, and `Team`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#target_type Alert#target_type}
    */
    readonly targetType?: string;
}
export declare function alertActionFiltersConditionsAssignedToToTerraform(struct?: AlertActionFiltersConditionsAssignedTo | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsAssignedToToHclTerraform(struct?: AlertActionFiltersConditionsAssignedTo | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsAssignedToOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsAssignedTo | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsAssignedTo | cdktf.IResolvable | undefined);
    private _targetId?;
    get targetId(): string;
    set targetId(value: string);
    resetTargetId(): void;
    get targetIdInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
}
export interface AlertActionFiltersConditionsEventAttribute {
    /**
    * The attribute to evaluate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#attribute Alert#attribute}
    */
    readonly attribute: string;
    /**
    * The match type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#match Alert#match}
    */
    readonly match: string;
    /**
    * The value to compare against. Not required when `match` is `is` or `ns`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value?: string;
}
export declare function alertActionFiltersConditionsEventAttributeToTerraform(struct?: AlertActionFiltersConditionsEventAttribute | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsEventAttributeToHclTerraform(struct?: AlertActionFiltersConditionsEventAttribute | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsEventAttributeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsEventAttribute | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsEventAttribute | cdktf.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    get attributeInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AlertActionFiltersConditionsEventFrequencyCountFilters {
    /**
    * The attribute of the filter. Conflicts with `key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#attribute Alert#attribute}
    */
    readonly attribute?: string;
    /**
    * The key of the filter. Conflicts with `attribute`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#key Alert#key}
    */
    readonly key?: string;
    /**
    * The match type of the filter. Valid values are: `co`, `ew`, `eq`, `gte`, `gt`, `is`, `in`, `lte`, `lt`, `nc`, `new`, `ne`, `ns`, `nsw`, `nin`, and `sw`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#match Alert#match}
    */
    readonly match?: string;
    /**
    * The value of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value?: string;
}
export declare function alertActionFiltersConditionsEventFrequencyCountFiltersToTerraform(struct?: AlertActionFiltersConditionsEventFrequencyCountFilters | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsEventFrequencyCountFiltersToHclTerraform(struct?: AlertActionFiltersConditionsEventFrequencyCountFilters | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsEventFrequencyCountFiltersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFiltersConditionsEventFrequencyCountFilters | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsEventFrequencyCountFilters | cdktf.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AlertActionFiltersConditionsEventFrequencyCountFiltersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFiltersConditionsEventFrequencyCountFilters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersConditionsEventFrequencyCountFiltersOutputReference;
}
export interface AlertActionFiltersConditionsEventFrequencyCount {
    /**
    * A list of additional sub-filters to evaluate before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#filters Alert#filters}
    */
    readonly filters?: AlertActionFiltersConditionsEventFrequencyCountFilters[] | cdktf.IResolvable;
    /**
    * The time period in which to evaluate the value. e.g. Number of events in an issue is more than `value` in `interval`. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#interval Alert#interval}
    */
    readonly interval: string;
    /**
    * A positive integer representing the number of events in an issue that must come in before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsEventFrequencyCountToTerraform(struct?: AlertActionFiltersConditionsEventFrequencyCount | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsEventFrequencyCountToHclTerraform(struct?: AlertActionFiltersConditionsEventFrequencyCount | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsEventFrequencyCountOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsEventFrequencyCount | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsEventFrequencyCount | cdktf.IResolvable | undefined);
    private _filters;
    get filters(): AlertActionFiltersConditionsEventFrequencyCountFiltersList;
    putFilters(value: AlertActionFiltersConditionsEventFrequencyCountFilters[] | cdktf.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktf.IResolvable | AlertActionFiltersConditionsEventFrequencyCountFilters[] | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsEventFrequencyPercentFilters {
    /**
    * The attribute of the filter. Conflicts with `key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#attribute Alert#attribute}
    */
    readonly attribute?: string;
    /**
    * The key of the filter. Conflicts with `attribute`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#key Alert#key}
    */
    readonly key?: string;
    /**
    * The match type of the filter. Valid values are: `co`, `ew`, `eq`, `gte`, `gt`, `is`, `in`, `lte`, `lt`, `nc`, `new`, `ne`, `ns`, `nsw`, `nin`, and `sw`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#match Alert#match}
    */
    readonly match?: string;
    /**
    * The value of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value?: string;
}
export declare function alertActionFiltersConditionsEventFrequencyPercentFiltersToTerraform(struct?: AlertActionFiltersConditionsEventFrequencyPercentFilters | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsEventFrequencyPercentFiltersToHclTerraform(struct?: AlertActionFiltersConditionsEventFrequencyPercentFilters | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsEventFrequencyPercentFiltersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFiltersConditionsEventFrequencyPercentFilters | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsEventFrequencyPercentFilters | cdktf.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AlertActionFiltersConditionsEventFrequencyPercentFiltersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFiltersConditionsEventFrequencyPercentFilters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersConditionsEventFrequencyPercentFiltersOutputReference;
}
export interface AlertActionFiltersConditionsEventFrequencyPercent {
    /**
    * The time period to compare against. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#comparison_interval Alert#comparison_interval}
    */
    readonly comparisonInterval: string;
    /**
    * A list of additional sub-filters to evaluate before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#filters Alert#filters}
    */
    readonly filters?: AlertActionFiltersConditionsEventFrequencyPercentFilters[] | cdktf.IResolvable;
    /**
    * The time period in which to evaluate the value. e.g. Number of events in an issue is `comparisonInterval` percent higher `value` compared to `interval`. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#interval Alert#interval}
    */
    readonly interval: string;
    /**
    * A positive integer representing the number of events in an issue that must come in before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsEventFrequencyPercentToTerraform(struct?: AlertActionFiltersConditionsEventFrequencyPercent | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsEventFrequencyPercentToHclTerraform(struct?: AlertActionFiltersConditionsEventFrequencyPercent | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsEventFrequencyPercentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsEventFrequencyPercent | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsEventFrequencyPercent | cdktf.IResolvable | undefined);
    private _comparisonInterval?;
    get comparisonInterval(): string;
    set comparisonInterval(value: string);
    get comparisonIntervalInput(): string | undefined;
    private _filters;
    get filters(): AlertActionFiltersConditionsEventFrequencyPercentFiltersList;
    putFilters(value: AlertActionFiltersConditionsEventFrequencyPercentFilters[] | cdktf.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktf.IResolvable | AlertActionFiltersConditionsEventFrequencyPercentFilters[] | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters {
    /**
    * The attribute of the filter. Conflicts with `key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#attribute Alert#attribute}
    */
    readonly attribute?: string;
    /**
    * The key of the filter. Conflicts with `attribute`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#key Alert#key}
    */
    readonly key?: string;
    /**
    * The match type of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#match Alert#match}
    */
    readonly match?: string;
    /**
    * The value of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value?: string;
}
export declare function alertActionFiltersConditionsEventUniqueUserFrequencyCountFiltersToTerraform(struct?: AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsEventUniqueUserFrequencyCountFiltersToHclTerraform(struct?: AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsEventUniqueUserFrequencyCountFiltersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters | cdktf.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AlertActionFiltersConditionsEventUniqueUserFrequencyCountFiltersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersConditionsEventUniqueUserFrequencyCountFiltersOutputReference;
}
export interface AlertActionFiltersConditionsEventUniqueUserFrequencyCount {
    /**
    * A list of additional sub-filters to evaluate before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#filters Alert#filters}
    */
    readonly filters?: AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters[] | cdktf.IResolvable;
    /**
    * The time period in which to evaluate the value. e.g. Number of users affected by an issue is more than `value` in `interval`. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#interval Alert#interval}
    */
    readonly interval: string;
    /**
    * A positive integer representing the number of users that must be affected before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsEventUniqueUserFrequencyCountToTerraform(struct?: AlertActionFiltersConditionsEventUniqueUserFrequencyCount | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsEventUniqueUserFrequencyCountToHclTerraform(struct?: AlertActionFiltersConditionsEventUniqueUserFrequencyCount | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsEventUniqueUserFrequencyCountOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsEventUniqueUserFrequencyCount | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsEventUniqueUserFrequencyCount | cdktf.IResolvable | undefined);
    private _filters;
    get filters(): AlertActionFiltersConditionsEventUniqueUserFrequencyCountFiltersList;
    putFilters(value: AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters[] | cdktf.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktf.IResolvable | AlertActionFiltersConditionsEventUniqueUserFrequencyCountFilters[] | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsIssueCategory {
    /**
    * If `true`, the condition matches when the issue category is equal to `value`. If `false`, the condition matches when it is not equal. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#include Alert#include}
    */
    readonly include?: boolean | cdktf.IResolvable;
    /**
    * The issue category to filter to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsIssueCategoryToTerraform(struct?: AlertActionFiltersConditionsIssueCategory | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsIssueCategoryToHclTerraform(struct?: AlertActionFiltersConditionsIssueCategory | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsIssueCategoryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsIssueCategory | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsIssueCategory | cdktf.IResolvable | undefined);
    private _include?;
    get include(): boolean | cdktf.IResolvable;
    set include(value: boolean | cdktf.IResolvable);
    resetInclude(): void;
    get includeInput(): boolean | cdktf.IResolvable | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsIssueOccurrences {
    /**
    * A positive integer representing how many times the issue has to happen before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsIssueOccurrencesToTerraform(struct?: AlertActionFiltersConditionsIssueOccurrences | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsIssueOccurrencesToHclTerraform(struct?: AlertActionFiltersConditionsIssueOccurrences | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsIssueOccurrencesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsIssueOccurrences | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsIssueOccurrences | cdktf.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsIssuePriorityDeescalating {
    /**
    * The minimum priority threshold required to trigger a de-escalation event. The rule triggers when the historical peak priority meets this threshold, and the current priority drops below it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#comparison Alert#comparison}
    */
    readonly comparison: number;
}
export declare function alertActionFiltersConditionsIssuePriorityDeescalatingToTerraform(struct?: AlertActionFiltersConditionsIssuePriorityDeescalating | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsIssuePriorityDeescalatingToHclTerraform(struct?: AlertActionFiltersConditionsIssuePriorityDeescalating | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsIssuePriorityDeescalatingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsIssuePriorityDeescalating | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsIssuePriorityDeescalating | cdktf.IResolvable | undefined);
    private _comparison?;
    get comparison(): number;
    set comparison(value: number);
    get comparisonInput(): number | undefined;
}
export interface AlertActionFiltersConditionsIssuePriorityGreaterOrEqual {
    /**
    * The priority the issue must be for the alert to fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#comparison Alert#comparison}
    */
    readonly comparison: number;
}
export declare function alertActionFiltersConditionsIssuePriorityGreaterOrEqualToTerraform(struct?: AlertActionFiltersConditionsIssuePriorityGreaterOrEqual | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsIssuePriorityGreaterOrEqualToHclTerraform(struct?: AlertActionFiltersConditionsIssuePriorityGreaterOrEqual | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsIssuePriorityGreaterOrEqualOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsIssuePriorityGreaterOrEqual | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsIssuePriorityGreaterOrEqual | cdktf.IResolvable | undefined);
    private _comparison?;
    get comparison(): number;
    set comparison(value: number);
    get comparisonInput(): number | undefined;
}
export interface AlertActionFiltersConditionsIssueType {
    /**
    * If `true`, matches when the issue type equals `value`. If `false`, matches when it does not equal `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#include Alert#include}
    */
    readonly include: boolean | cdktf.IResolvable;
    /**
    * The issue type slug (e.g. `performance_large_http_payload`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: string;
}
export declare function alertActionFiltersConditionsIssueTypeToTerraform(struct?: AlertActionFiltersConditionsIssueType | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsIssueTypeToHclTerraform(struct?: AlertActionFiltersConditionsIssueType | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsIssueTypeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsIssueType | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsIssueType | cdktf.IResolvable | undefined);
    private _include?;
    get include(): boolean | cdktf.IResolvable;
    set include(value: boolean | cdktf.IResolvable);
    get includeInput(): boolean | cdktf.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface AlertActionFiltersConditionsLatestAdoptedRelease {
    /**
    * The age comparison to use. Valid values are: `older`, and `newer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#age_comparison Alert#age_comparison}
    */
    readonly ageComparison: string;
    /**
    * The environment to compare against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#environment Alert#environment}
    */
    readonly environment: string;
    /**
    * The release age type to use. Valid values are: `oldest`, and `newest`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#release_age_type Alert#release_age_type}
    */
    readonly releaseAgeType: string;
}
export declare function alertActionFiltersConditionsLatestAdoptedReleaseToTerraform(struct?: AlertActionFiltersConditionsLatestAdoptedRelease | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsLatestAdoptedReleaseToHclTerraform(struct?: AlertActionFiltersConditionsLatestAdoptedRelease | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsLatestAdoptedReleaseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsLatestAdoptedRelease | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsLatestAdoptedRelease | cdktf.IResolvable | undefined);
    private _ageComparison?;
    get ageComparison(): string;
    set ageComparison(value: string);
    get ageComparisonInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _releaseAgeType?;
    get releaseAgeType(): string;
    set releaseAgeType(value: string);
    get releaseAgeTypeInput(): string | undefined;
}
export interface AlertActionFiltersConditionsLatestRelease {
}
export declare function alertActionFiltersConditionsLatestReleaseToTerraform(struct?: AlertActionFiltersConditionsLatestRelease | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsLatestReleaseToHclTerraform(struct?: AlertActionFiltersConditionsLatestRelease | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsLatestReleaseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsLatestRelease | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsLatestRelease | cdktf.IResolvable | undefined);
}
export interface AlertActionFiltersConditionsLevel {
    /**
    * The level to compare against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#level Alert#level}
    */
    readonly level: number;
    /**
    * The comparison operator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#match Alert#match}
    */
    readonly match: string;
}
export declare function alertActionFiltersConditionsLevelToTerraform(struct?: AlertActionFiltersConditionsLevel | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsLevelToHclTerraform(struct?: AlertActionFiltersConditionsLevel | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsLevelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsLevel | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsLevel | cdktf.IResolvable | undefined);
    private _level?;
    get level(): number;
    set level(value: number);
    get levelInput(): number | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
}
export interface AlertActionFiltersConditionsPercentSessionsCount {
    /**
    * The time period in which to evaluate the value. e.g. Percentage of sessions affected by an issue is more than `value` in `interval`. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#interval Alert#interval}
    */
    readonly interval: string;
    /**
    * A positive integer representing the number of events in an issue that must come in before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsPercentSessionsCountToTerraform(struct?: AlertActionFiltersConditionsPercentSessionsCount | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsPercentSessionsCountToHclTerraform(struct?: AlertActionFiltersConditionsPercentSessionsCount | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsPercentSessionsCountOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsPercentSessionsCount | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsPercentSessionsCount | cdktf.IResolvable | undefined);
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsPercentSessionsPercentFilters {
    /**
    * The attribute of the filter. Conflicts with `key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#attribute Alert#attribute}
    */
    readonly attribute?: string;
    /**
    * The key of the filter. Conflicts with `attribute`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#key Alert#key}
    */
    readonly key?: string;
    /**
    * The match type of the filter. Valid values are: `co`, `ew`, `eq`, `gte`, `gt`, `is`, `in`, `lte`, `lt`, `nc`, `new`, `ne`, `ns`, `nsw`, `nin`, and `sw`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#match Alert#match}
    */
    readonly match?: string;
    /**
    * The value of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value?: string;
}
export declare function alertActionFiltersConditionsPercentSessionsPercentFiltersToTerraform(struct?: AlertActionFiltersConditionsPercentSessionsPercentFilters | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsPercentSessionsPercentFiltersToHclTerraform(struct?: AlertActionFiltersConditionsPercentSessionsPercentFilters | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsPercentSessionsPercentFiltersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFiltersConditionsPercentSessionsPercentFilters | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsPercentSessionsPercentFilters | cdktf.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AlertActionFiltersConditionsPercentSessionsPercentFiltersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFiltersConditionsPercentSessionsPercentFilters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersConditionsPercentSessionsPercentFiltersOutputReference;
}
export interface AlertActionFiltersConditionsPercentSessionsPercent {
    /**
    * The time period to compare against. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#comparison_interval Alert#comparison_interval}
    */
    readonly comparisonInterval: string;
    /**
    * A list of additional sub-filters to evaluate before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#filters Alert#filters}
    */
    readonly filters?: AlertActionFiltersConditionsPercentSessionsPercentFilters[] | cdktf.IResolvable;
    /**
    * The time period in which to evaluate the value. e.g. Percentage of sessions affected by an issue is `comparisonInterval` percent higher `value` compared to `interval`. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#interval Alert#interval}
    */
    readonly interval: string;
    /**
    * A positive integer representing the number of events in an issue that must come in before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertActionFiltersConditionsPercentSessionsPercentToTerraform(struct?: AlertActionFiltersConditionsPercentSessionsPercent | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsPercentSessionsPercentToHclTerraform(struct?: AlertActionFiltersConditionsPercentSessionsPercent | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsPercentSessionsPercentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsPercentSessionsPercent | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsPercentSessionsPercent | cdktf.IResolvable | undefined);
    private _comparisonInterval?;
    get comparisonInterval(): string;
    set comparisonInterval(value: string);
    get comparisonIntervalInput(): string | undefined;
    private _filters;
    get filters(): AlertActionFiltersConditionsPercentSessionsPercentFiltersList;
    putFilters(value: AlertActionFiltersConditionsPercentSessionsPercentFilters[] | cdktf.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktf.IResolvable | AlertActionFiltersConditionsPercentSessionsPercentFilters[] | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertActionFiltersConditionsTaggedEvent {
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#key Alert#key}
    */
    readonly key: string;
    /**
    * The comparison operator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#match Alert#match}
    */
    readonly match: string;
    /**
    * A string. Not required when match is `is` or `ns`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value?: string;
}
export declare function alertActionFiltersConditionsTaggedEventToTerraform(struct?: AlertActionFiltersConditionsTaggedEvent | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsTaggedEventToHclTerraform(struct?: AlertActionFiltersConditionsTaggedEvent | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsTaggedEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertActionFiltersConditionsTaggedEvent | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditionsTaggedEvent | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AlertActionFiltersConditions {
    /**
    * Issue age.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#age_comparison Alert#age_comparison}
    */
    readonly ageComparison?: AlertActionFiltersConditionsAgeComparison;
    /**
    * Issue assignment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#assigned_to Alert#assigned_to}
    */
    readonly assignedTo?: AlertActionFiltersConditionsAssignedTo;
    /**
    * The event's `attribute` value `match` `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#event_attribute Alert#event_attribute}
    */
    readonly eventAttribute?: AlertActionFiltersConditionsEventAttribute;
    /**
    * Number of events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#event_frequency_count Alert#event_frequency_count}
    */
    readonly eventFrequencyCount?: AlertActionFiltersConditionsEventFrequencyCount;
    /**
    * Percent of events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#event_frequency_percent Alert#event_frequency_percent}
    */
    readonly eventFrequencyPercent?: AlertActionFiltersConditionsEventFrequencyPercent;
    /**
    * Number of users affected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#event_unique_user_frequency_count Alert#event_unique_user_frequency_count}
    */
    readonly eventUniqueUserFrequencyCount?: AlertActionFiltersConditionsEventUniqueUserFrequencyCount;
    /**
    * Issue category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_category Alert#issue_category}
    */
    readonly issueCategory?: AlertActionFiltersConditionsIssueCategory;
    /**
    * Issue frequency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_occurrences Alert#issue_occurrences}
    */
    readonly issueOccurrences?: AlertActionFiltersConditionsIssueOccurrences;
    /**
    * De-escalation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_priority_deescalating Alert#issue_priority_deescalating}
    */
    readonly issuePriorityDeescalating?: AlertActionFiltersConditionsIssuePriorityDeescalating;
    /**
    * Issue priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_priority_greater_or_equal Alert#issue_priority_greater_or_equal}
    */
    readonly issuePriorityGreaterOrEqual?: AlertActionFiltersConditionsIssuePriorityGreaterOrEqual;
    /**
    * Issue type is (or is not) `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_type Alert#issue_type}
    */
    readonly issueType?: AlertActionFiltersConditionsIssueType;
    /**
    * The `release_age_type` adopted release associated with the event's issue is `age_comparison` than the latest adopted release in `environment`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#latest_adopted_release Alert#latest_adopted_release}
    */
    readonly latestAdoptedRelease?: AlertActionFiltersConditionsLatestAdoptedRelease;
    /**
    * The event is from the latest release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#latest_release Alert#latest_release}
    */
    readonly latestRelease?: AlertActionFiltersConditionsLatestRelease;
    /**
    * The event's level match `level`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#level Alert#level}
    */
    readonly level?: AlertActionFiltersConditionsLevel;
    /**
    * Percentage of sessions affected count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#percent_sessions_count Alert#percent_sessions_count}
    */
    readonly percentSessionsCount?: AlertActionFiltersConditionsPercentSessionsCount;
    /**
    * Percentage of sessions affected percent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#percent_sessions_percent Alert#percent_sessions_percent}
    */
    readonly percentSessionsPercent?: AlertActionFiltersConditionsPercentSessionsPercent;
    /**
    * The event's tags `key` match `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#tagged_event Alert#tagged_event}
    */
    readonly taggedEvent?: AlertActionFiltersConditionsTaggedEvent;
}
export declare function alertActionFiltersConditionsToTerraform(struct?: AlertActionFiltersConditions | cdktf.IResolvable): any;
export declare function alertActionFiltersConditionsToHclTerraform(struct?: AlertActionFiltersConditions | cdktf.IResolvable): any;
export declare class AlertActionFiltersConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFiltersConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFiltersConditions | cdktf.IResolvable | undefined);
    private _ageComparison;
    get ageComparison(): AlertActionFiltersConditionsAgeComparisonOutputReference;
    putAgeComparison(value: AlertActionFiltersConditionsAgeComparison): void;
    resetAgeComparison(): void;
    get ageComparisonInput(): cdktf.IResolvable | AlertActionFiltersConditionsAgeComparison | undefined;
    private _assignedTo;
    get assignedTo(): AlertActionFiltersConditionsAssignedToOutputReference;
    putAssignedTo(value: AlertActionFiltersConditionsAssignedTo): void;
    resetAssignedTo(): void;
    get assignedToInput(): cdktf.IResolvable | AlertActionFiltersConditionsAssignedTo | undefined;
    private _eventAttribute;
    get eventAttribute(): AlertActionFiltersConditionsEventAttributeOutputReference;
    putEventAttribute(value: AlertActionFiltersConditionsEventAttribute): void;
    resetEventAttribute(): void;
    get eventAttributeInput(): cdktf.IResolvable | AlertActionFiltersConditionsEventAttribute | undefined;
    private _eventFrequencyCount;
    get eventFrequencyCount(): AlertActionFiltersConditionsEventFrequencyCountOutputReference;
    putEventFrequencyCount(value: AlertActionFiltersConditionsEventFrequencyCount): void;
    resetEventFrequencyCount(): void;
    get eventFrequencyCountInput(): cdktf.IResolvable | AlertActionFiltersConditionsEventFrequencyCount | undefined;
    private _eventFrequencyPercent;
    get eventFrequencyPercent(): AlertActionFiltersConditionsEventFrequencyPercentOutputReference;
    putEventFrequencyPercent(value: AlertActionFiltersConditionsEventFrequencyPercent): void;
    resetEventFrequencyPercent(): void;
    get eventFrequencyPercentInput(): cdktf.IResolvable | AlertActionFiltersConditionsEventFrequencyPercent | undefined;
    private _eventUniqueUserFrequencyCount;
    get eventUniqueUserFrequencyCount(): AlertActionFiltersConditionsEventUniqueUserFrequencyCountOutputReference;
    putEventUniqueUserFrequencyCount(value: AlertActionFiltersConditionsEventUniqueUserFrequencyCount): void;
    resetEventUniqueUserFrequencyCount(): void;
    get eventUniqueUserFrequencyCountInput(): cdktf.IResolvable | AlertActionFiltersConditionsEventUniqueUserFrequencyCount | undefined;
    private _issueCategory;
    get issueCategory(): AlertActionFiltersConditionsIssueCategoryOutputReference;
    putIssueCategory(value: AlertActionFiltersConditionsIssueCategory): void;
    resetIssueCategory(): void;
    get issueCategoryInput(): cdktf.IResolvable | AlertActionFiltersConditionsIssueCategory | undefined;
    private _issueOccurrences;
    get issueOccurrences(): AlertActionFiltersConditionsIssueOccurrencesOutputReference;
    putIssueOccurrences(value: AlertActionFiltersConditionsIssueOccurrences): void;
    resetIssueOccurrences(): void;
    get issueOccurrencesInput(): cdktf.IResolvable | AlertActionFiltersConditionsIssueOccurrences | undefined;
    private _issuePriorityDeescalating;
    get issuePriorityDeescalating(): AlertActionFiltersConditionsIssuePriorityDeescalatingOutputReference;
    putIssuePriorityDeescalating(value: AlertActionFiltersConditionsIssuePriorityDeescalating): void;
    resetIssuePriorityDeescalating(): void;
    get issuePriorityDeescalatingInput(): cdktf.IResolvable | AlertActionFiltersConditionsIssuePriorityDeescalating | undefined;
    private _issuePriorityGreaterOrEqual;
    get issuePriorityGreaterOrEqual(): AlertActionFiltersConditionsIssuePriorityGreaterOrEqualOutputReference;
    putIssuePriorityGreaterOrEqual(value: AlertActionFiltersConditionsIssuePriorityGreaterOrEqual): void;
    resetIssuePriorityGreaterOrEqual(): void;
    get issuePriorityGreaterOrEqualInput(): cdktf.IResolvable | AlertActionFiltersConditionsIssuePriorityGreaterOrEqual | undefined;
    private _issueType;
    get issueType(): AlertActionFiltersConditionsIssueTypeOutputReference;
    putIssueType(value: AlertActionFiltersConditionsIssueType): void;
    resetIssueType(): void;
    get issueTypeInput(): cdktf.IResolvable | AlertActionFiltersConditionsIssueType | undefined;
    private _latestAdoptedRelease;
    get latestAdoptedRelease(): AlertActionFiltersConditionsLatestAdoptedReleaseOutputReference;
    putLatestAdoptedRelease(value: AlertActionFiltersConditionsLatestAdoptedRelease): void;
    resetLatestAdoptedRelease(): void;
    get latestAdoptedReleaseInput(): cdktf.IResolvable | AlertActionFiltersConditionsLatestAdoptedRelease | undefined;
    private _latestRelease;
    get latestRelease(): AlertActionFiltersConditionsLatestReleaseOutputReference;
    putLatestRelease(value: AlertActionFiltersConditionsLatestRelease): void;
    resetLatestRelease(): void;
    get latestReleaseInput(): cdktf.IResolvable | AlertActionFiltersConditionsLatestRelease | undefined;
    private _level;
    get level(): AlertActionFiltersConditionsLevelOutputReference;
    putLevel(value: AlertActionFiltersConditionsLevel): void;
    resetLevel(): void;
    get levelInput(): cdktf.IResolvable | AlertActionFiltersConditionsLevel | undefined;
    private _percentSessionsCount;
    get percentSessionsCount(): AlertActionFiltersConditionsPercentSessionsCountOutputReference;
    putPercentSessionsCount(value: AlertActionFiltersConditionsPercentSessionsCount): void;
    resetPercentSessionsCount(): void;
    get percentSessionsCountInput(): cdktf.IResolvable | AlertActionFiltersConditionsPercentSessionsCount | undefined;
    private _percentSessionsPercent;
    get percentSessionsPercent(): AlertActionFiltersConditionsPercentSessionsPercentOutputReference;
    putPercentSessionsPercent(value: AlertActionFiltersConditionsPercentSessionsPercent): void;
    resetPercentSessionsPercent(): void;
    get percentSessionsPercentInput(): cdktf.IResolvable | AlertActionFiltersConditionsPercentSessionsPercent | undefined;
    private _taggedEvent;
    get taggedEvent(): AlertActionFiltersConditionsTaggedEventOutputReference;
    putTaggedEvent(value: AlertActionFiltersConditionsTaggedEvent): void;
    resetTaggedEvent(): void;
    get taggedEventInput(): cdktf.IResolvable | AlertActionFiltersConditionsTaggedEvent | undefined;
}
export declare class AlertActionFiltersConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFiltersConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersConditionsOutputReference;
}
export interface AlertActionFilters {
    /**
    * The actions to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#actions Alert#actions}
    */
    readonly actions: AlertActionFiltersActions[] | cdktf.IResolvable;
    /**
    * The conditions to evaluate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#conditions Alert#conditions}
    */
    readonly conditions?: AlertActionFiltersConditions[] | cdktf.IResolvable;
    /**
    * The logic to apply to the conditions. `any` will evaluate all conditions, and return true if any of those are met. `any-short` will stop evaluating conditions as soon as one is met. `all` will evaluate all conditions, and return true if all of those are met. `none` will return true if none of the conditions are met, will return false immediately if any are met. Valid values are: `any`, `any-short`, `all`, and `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#logic_type Alert#logic_type}
    */
    readonly logicType: string;
}
export declare function alertActionFiltersToTerraform(struct?: AlertActionFilters | cdktf.IResolvable): any;
export declare function alertActionFiltersToHclTerraform(struct?: AlertActionFilters | cdktf.IResolvable): any;
export declare class AlertActionFiltersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertActionFilters | cdktf.IResolvable | undefined;
    set internalValue(value: AlertActionFilters | cdktf.IResolvable | undefined);
    private _actions;
    get actions(): AlertActionFiltersActionsList;
    putActions(value: AlertActionFiltersActions[] | cdktf.IResolvable): void;
    get actionsInput(): cdktf.IResolvable | AlertActionFiltersActions[] | undefined;
    private _conditions;
    get conditions(): AlertActionFiltersConditionsList;
    putConditions(value: AlertActionFiltersConditions[] | cdktf.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktf.IResolvable | AlertActionFiltersConditions[] | undefined;
    private _logicType?;
    get logicType(): string;
    set logicType(value: string);
    get logicTypeInput(): string | undefined;
}
export declare class AlertActionFiltersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertActionFilters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertActionFiltersOutputReference;
}
export interface AlertTriggerConditionsEventFrequencyCount {
    /**
    * The time period in which to evaluate the event count. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#interval Alert#interval}
    */
    readonly interval: string;
    /**
    * The number of events that must be exceeded before the alert will fire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#value Alert#value}
    */
    readonly value: number;
}
export declare function alertTriggerConditionsEventFrequencyCountToTerraform(struct?: AlertTriggerConditionsEventFrequencyCount | cdktf.IResolvable): any;
export declare function alertTriggerConditionsEventFrequencyCountToHclTerraform(struct?: AlertTriggerConditionsEventFrequencyCount | cdktf.IResolvable): any;
export declare class AlertTriggerConditionsEventFrequencyCountOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertTriggerConditionsEventFrequencyCount | cdktf.IResolvable | undefined;
    set internalValue(value: AlertTriggerConditionsEventFrequencyCount | cdktf.IResolvable | undefined);
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AlertTriggerConditionsFirstSeenEvent {
}
export declare function alertTriggerConditionsFirstSeenEventToTerraform(struct?: AlertTriggerConditionsFirstSeenEvent | cdktf.IResolvable): any;
export declare function alertTriggerConditionsFirstSeenEventToHclTerraform(struct?: AlertTriggerConditionsFirstSeenEvent | cdktf.IResolvable): any;
export declare class AlertTriggerConditionsFirstSeenEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertTriggerConditionsFirstSeenEvent | cdktf.IResolvable | undefined;
    set internalValue(value: AlertTriggerConditionsFirstSeenEvent | cdktf.IResolvable | undefined);
}
export interface AlertTriggerConditionsIssueResolvedTrigger {
}
export declare function alertTriggerConditionsIssueResolvedTriggerToTerraform(struct?: AlertTriggerConditionsIssueResolvedTrigger | cdktf.IResolvable): any;
export declare function alertTriggerConditionsIssueResolvedTriggerToHclTerraform(struct?: AlertTriggerConditionsIssueResolvedTrigger | cdktf.IResolvable): any;
export declare class AlertTriggerConditionsIssueResolvedTriggerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertTriggerConditionsIssueResolvedTrigger | cdktf.IResolvable | undefined;
    set internalValue(value: AlertTriggerConditionsIssueResolvedTrigger | cdktf.IResolvable | undefined);
}
export interface AlertTriggerConditionsReappearedEvent {
}
export declare function alertTriggerConditionsReappearedEventToTerraform(struct?: AlertTriggerConditionsReappearedEvent | cdktf.IResolvable): any;
export declare function alertTriggerConditionsReappearedEventToHclTerraform(struct?: AlertTriggerConditionsReappearedEvent | cdktf.IResolvable): any;
export declare class AlertTriggerConditionsReappearedEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertTriggerConditionsReappearedEvent | cdktf.IResolvable | undefined;
    set internalValue(value: AlertTriggerConditionsReappearedEvent | cdktf.IResolvable | undefined);
}
export interface AlertTriggerConditionsRegressionEvent {
}
export declare function alertTriggerConditionsRegressionEventToTerraform(struct?: AlertTriggerConditionsRegressionEvent | cdktf.IResolvable): any;
export declare function alertTriggerConditionsRegressionEventToHclTerraform(struct?: AlertTriggerConditionsRegressionEvent | cdktf.IResolvable): any;
export declare class AlertTriggerConditionsRegressionEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertTriggerConditionsRegressionEvent | cdktf.IResolvable | undefined;
    set internalValue(value: AlertTriggerConditionsRegressionEvent | cdktf.IResolvable | undefined);
}
export interface AlertTriggerConditions {
    /**
    * Number of events seen by the workflow exceeds a threshold within an interval.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#event_frequency_count Alert#event_frequency_count}
    */
    readonly eventFrequencyCount?: AlertTriggerConditionsEventFrequencyCount;
    /**
    * A new issue is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#first_seen_event Alert#first_seen_event}
    */
    readonly firstSeenEvent?: AlertTriggerConditionsFirstSeenEvent;
    /**
    * An issue is resolved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#issue_resolved_trigger Alert#issue_resolved_trigger}
    */
    readonly issueResolvedTrigger?: AlertTriggerConditionsIssueResolvedTrigger;
    /**
    * An issue escalates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#reappeared_event Alert#reappeared_event}
    */
    readonly reappearedEvent?: AlertTriggerConditionsReappearedEvent;
    /**
    * A resolved issue becomes unresolved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#regression_event Alert#regression_event}
    */
    readonly regressionEvent?: AlertTriggerConditionsRegressionEvent;
}
export declare function alertTriggerConditionsToTerraform(struct?: AlertTriggerConditions | cdktf.IResolvable): any;
export declare function alertTriggerConditionsToHclTerraform(struct?: AlertTriggerConditions | cdktf.IResolvable): any;
export declare class AlertTriggerConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertTriggerConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertTriggerConditions | cdktf.IResolvable | undefined);
    private _eventFrequencyCount;
    get eventFrequencyCount(): AlertTriggerConditionsEventFrequencyCountOutputReference;
    putEventFrequencyCount(value: AlertTriggerConditionsEventFrequencyCount): void;
    resetEventFrequencyCount(): void;
    get eventFrequencyCountInput(): cdktf.IResolvable | AlertTriggerConditionsEventFrequencyCount | undefined;
    private _firstSeenEvent;
    get firstSeenEvent(): AlertTriggerConditionsFirstSeenEventOutputReference;
    putFirstSeenEvent(value: AlertTriggerConditionsFirstSeenEvent): void;
    resetFirstSeenEvent(): void;
    get firstSeenEventInput(): cdktf.IResolvable | AlertTriggerConditionsFirstSeenEvent | undefined;
    private _issueResolvedTrigger;
    get issueResolvedTrigger(): AlertTriggerConditionsIssueResolvedTriggerOutputReference;
    putIssueResolvedTrigger(value: AlertTriggerConditionsIssueResolvedTrigger): void;
    resetIssueResolvedTrigger(): void;
    get issueResolvedTriggerInput(): cdktf.IResolvable | AlertTriggerConditionsIssueResolvedTrigger | undefined;
    private _reappearedEvent;
    get reappearedEvent(): AlertTriggerConditionsReappearedEventOutputReference;
    putReappearedEvent(value: AlertTriggerConditionsReappearedEvent): void;
    resetReappearedEvent(): void;
    get reappearedEventInput(): cdktf.IResolvable | AlertTriggerConditionsReappearedEvent | undefined;
    private _regressionEvent;
    get regressionEvent(): AlertTriggerConditionsRegressionEventOutputReference;
    putRegressionEvent(value: AlertTriggerConditionsRegressionEvent): void;
    resetRegressionEvent(): void;
    get regressionEventInput(): cdktf.IResolvable | AlertTriggerConditionsRegressionEvent | undefined;
}
export declare class AlertTriggerConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertTriggerConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertTriggerConditionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert sentry_alert}
*/
export declare class Alert extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_alert";
    /**
    * Generates CDKTF code for importing a Alert resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Alert to import
    * @param importFromId The id of the existing Alert that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Alert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/alert sentry_alert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertConfig
    */
    constructor(scope: Construct, id: string, config: AlertConfig);
    private _actionFilters;
    get actionFilters(): AlertActionFiltersList;
    putActionFilters(value: AlertActionFilters[] | cdktf.IResolvable): void;
    get actionFiltersInput(): cdktf.IResolvable | AlertActionFilters[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _frequencyMinutes?;
    get frequencyMinutes(): number;
    set frequencyMinutes(value: number);
    get frequencyMinutesInput(): number | undefined;
    get id(): string;
    private _legacyTriggerConditions?;
    get legacyTriggerConditions(): string[];
    set legacyTriggerConditions(value: string[]);
    resetLegacyTriggerConditions(): void;
    get legacyTriggerConditionsInput(): string[] | undefined;
    private _monitorIds?;
    get monitorIds(): string[];
    set monitorIds(value: string[]);
    get monitorIdsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _triggerConditions;
    get triggerConditions(): AlertTriggerConditionsList;
    putTriggerConditions(value: AlertTriggerConditions[] | cdktf.IResolvable): void;
    resetTriggerConditions(): void;
    get triggerConditionsInput(): cdktf.IResolvable | AlertTriggerConditions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
