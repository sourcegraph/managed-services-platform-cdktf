import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MetricAlertConfig extends cdktf.TerraformMetaArguments {
    /**
    * The aggregation criteria to apply
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#aggregate MetricAlert#aggregate}
    */
    readonly aggregate: string;
    /**
    * An optional int representing the time delta to use as the comparison period, in minutes. Required when using a percentage change threshold
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#comparison_delta MetricAlert#comparison_delta}
    */
    readonly comparisonDelta?: number;
    /**
    * The Sentry Alert category
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#dataset MetricAlert#dataset}
    */
    readonly dataset?: string;
    /**
    * Perform Alert rule in a specific environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#environment MetricAlert#environment}
    */
    readonly environment?: string;
    /**
    * The events type of dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#event_types MetricAlert#event_types}
    */
    readonly eventTypes?: string[];
    /**
    * The metric alert name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#name MetricAlert#name}
    */
    readonly name: string;
    /**
    * The slug of the organization the metric alert belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#organization MetricAlert#organization}
    */
    readonly organization: string;
    /**
    * Specifies the owner id of this Alert rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#owner MetricAlert#owner}
    */
    readonly owner?: string;
    /**
    * The slug of the project to create the metric alert for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#project MetricAlert#project}
    */
    readonly project: string;
    /**
    * The query filter to apply
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#query MetricAlert#query}
    */
    readonly query: string;
    /**
    * The value at which the Alert rule resolves
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#resolve_threshold MetricAlert#resolve_threshold}
    */
    readonly resolveThreshold?: number;
    /**
    * The type of threshold
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#threshold_type MetricAlert#threshold_type}
    */
    readonly thresholdType: number;
    /**
    * The period to evaluate the Alert rule in minutes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#time_window MetricAlert#time_window}
    */
    readonly timeWindow: number;
    /**
    * trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#trigger MetricAlert#trigger}
    */
    readonly trigger: MetricAlertTrigger[] | cdktf.IResolvable;
}
export interface MetricAlertTriggerAction {
    /**
    * Slack channel ID to avoid rate-limiting, see [here](https://docs.sentry.io/product/integrations/notification-incidents/slack/#rate-limiting-error)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#input_channel_id MetricAlert#input_channel_id}
    */
    readonly inputChannelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#integration_id MetricAlert#integration_id}
    */
    readonly integrationId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#priority MetricAlert#priority}
    */
    readonly priority?: string;
    /**
    * The ID of the Sentry App (required when type is sentry_app)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#sentry_app_id MetricAlert#sentry_app_id}
    */
    readonly sentryAppId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#target_identifier MetricAlert#target_identifier}
    */
    readonly targetIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#target_type MetricAlert#target_type}
    */
    readonly targetType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#type MetricAlert#type}
    */
    readonly type: string;
}
export declare function metricAlertTriggerActionToTerraform(struct?: MetricAlertTriggerAction | cdktf.IResolvable): any;
export declare function metricAlertTriggerActionToHclTerraform(struct?: MetricAlertTriggerAction | cdktf.IResolvable): any;
export declare class MetricAlertTriggerActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MetricAlertTriggerAction | cdktf.IResolvable | undefined;
    set internalValue(value: MetricAlertTriggerAction | cdktf.IResolvable | undefined);
    get id(): string;
    private _inputChannelId?;
    get inputChannelId(): string;
    set inputChannelId(value: string);
    resetInputChannelId(): void;
    get inputChannelIdInput(): string | undefined;
    private _integrationId?;
    get integrationId(): number;
    set integrationId(value: number);
    resetIntegrationId(): void;
    get integrationIdInput(): number | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _sentryAppId?;
    get sentryAppId(): number;
    set sentryAppId(value: number);
    resetSentryAppId(): void;
    get sentryAppIdInput(): number | undefined;
    private _targetIdentifier?;
    get targetIdentifier(): string;
    set targetIdentifier(value: string);
    resetTargetIdentifier(): void;
    get targetIdentifierInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class MetricAlertTriggerActionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: MetricAlertTriggerAction[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MetricAlertTriggerActionOutputReference;
}
export interface MetricAlertTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#alert_threshold MetricAlert#alert_threshold}
    */
    readonly alertThreshold: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#label MetricAlert#label}
    */
    readonly label: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#resolve_threshold MetricAlert#resolve_threshold}
    */
    readonly resolveThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#threshold_type MetricAlert#threshold_type}
    */
    readonly thresholdType: number;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#action MetricAlert#action}
    */
    readonly action: MetricAlertTriggerAction[] | cdktf.IResolvable;
}
export declare function metricAlertTriggerToTerraform(struct?: MetricAlertTrigger | cdktf.IResolvable): any;
export declare function metricAlertTriggerToHclTerraform(struct?: MetricAlertTrigger | cdktf.IResolvable): any;
export declare class MetricAlertTriggerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MetricAlertTrigger | cdktf.IResolvable | undefined;
    set internalValue(value: MetricAlertTrigger | cdktf.IResolvable | undefined);
    private _alertThreshold?;
    get alertThreshold(): number;
    set alertThreshold(value: number);
    get alertThresholdInput(): number | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _resolveThreshold?;
    get resolveThreshold(): number;
    set resolveThreshold(value: number);
    resetResolveThreshold(): void;
    get resolveThresholdInput(): number | undefined;
    private _thresholdType?;
    get thresholdType(): number;
    set thresholdType(value: number);
    get thresholdTypeInput(): number | undefined;
    private _action;
    get action(): MetricAlertTriggerActionList;
    putAction(value: MetricAlertTriggerAction[] | cdktf.IResolvable): void;
    get actionInput(): cdktf.IResolvable | MetricAlertTriggerAction[] | undefined;
}
export declare class MetricAlertTriggerList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: MetricAlertTrigger[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MetricAlertTriggerOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert sentry_metric_alert}
*/
export declare class MetricAlert extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_metric_alert";
    /**
    * Generates CDKTF code for importing a MetricAlert resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MetricAlert to import
    * @param importFromId The id of the existing MetricAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MetricAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_alert sentry_metric_alert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MetricAlertConfig
    */
    constructor(scope: Construct, id: string, config: MetricAlertConfig);
    private _aggregate?;
    get aggregate(): string;
    set aggregate(value: string);
    get aggregateInput(): string | undefined;
    private _comparisonDelta?;
    get comparisonDelta(): number;
    set comparisonDelta(value: number);
    resetComparisonDelta(): void;
    get comparisonDeltaInput(): number | undefined;
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    resetDataset(): void;
    get datasetInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _eventTypes?;
    get eventTypes(): string[];
    set eventTypes(value: string[]);
    resetEventTypes(): void;
    get eventTypesInput(): string[] | undefined;
    get id(): string;
    get internalId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _resolveThreshold?;
    get resolveThreshold(): number;
    set resolveThreshold(value: number);
    resetResolveThreshold(): void;
    get resolveThresholdInput(): number | undefined;
    private _thresholdType?;
    get thresholdType(): number;
    set thresholdType(value: number);
    get thresholdTypeInput(): number | undefined;
    private _timeWindow?;
    get timeWindow(): number;
    set timeWindow(value: number);
    get timeWindowInput(): number | undefined;
    private _trigger;
    get trigger(): MetricAlertTriggerList;
    putTrigger(value: MetricAlertTrigger[] | cdktf.IResolvable): void;
    get triggerInput(): cdktf.IResolvable | MetricAlertTrigger[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
