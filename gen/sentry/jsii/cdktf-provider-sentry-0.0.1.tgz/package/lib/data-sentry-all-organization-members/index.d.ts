import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryAllOrganizationMembersConfig extends cdktf.TerraformMetaArguments {
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_organization_members#organization DataSentryAllOrganizationMembers#organization}
    */
    readonly organization: string;
}
export interface DataSentryAllOrganizationMembersMembers {
}
export declare function dataSentryAllOrganizationMembersMembersToTerraform(struct?: DataSentryAllOrganizationMembersMembers): any;
export declare function dataSentryAllOrganizationMembersMembersToHclTerraform(struct?: DataSentryAllOrganizationMembersMembers): any;
export declare class DataSentryAllOrganizationMembersMembersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryAllOrganizationMembersMembers | undefined;
    set internalValue(value: DataSentryAllOrganizationMembersMembers | undefined);
    get email(): string;
    get id(): string;
    get role(): string;
}
export declare class DataSentryAllOrganizationMembersMembersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryAllOrganizationMembersMembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_organization_members sentry_all_organization_members}
*/
export declare class DataSentryAllOrganizationMembers extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_all_organization_members";
    /**
    * Generates CDKTF code for importing a DataSentryAllOrganizationMembers resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryAllOrganizationMembers to import
    * @param importFromId The id of the existing DataSentryAllOrganizationMembers that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_organization_members#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryAllOrganizationMembers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/all_organization_members sentry_all_organization_members} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryAllOrganizationMembersConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryAllOrganizationMembersConfig);
    private _members;
    get members(): DataSentryAllOrganizationMembersMembersList;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
