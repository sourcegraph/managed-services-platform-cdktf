import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryUptimeMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * The internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/uptime_monitor#id DataSentryUptimeMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The organization slug or internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/uptime_monitor#organization DataSentryUptimeMonitor#organization}
    */
    readonly organization: string;
}
export interface DataSentryUptimeMonitorOwner {
}
export declare function dataSentryUptimeMonitorOwnerToTerraform(struct?: DataSentryUptimeMonitorOwner): any;
export declare function dataSentryUptimeMonitorOwnerToHclTerraform(struct?: DataSentryUptimeMonitorOwner): any;
export declare class DataSentryUptimeMonitorOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryUptimeMonitorOwner | undefined;
    set internalValue(value: DataSentryUptimeMonitorOwner | undefined);
    get teamId(): string;
    get userId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/uptime_monitor sentry_uptime_monitor}
*/
export declare class DataSentryUptimeMonitor extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_uptime_monitor";
    /**
    * Generates CDKTF code for importing a DataSentryUptimeMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryUptimeMonitor to import
    * @param importFromId The id of the existing DataSentryUptimeMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/uptime_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryUptimeMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/uptime_monitor sentry_uptime_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryUptimeMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryUptimeMonitorConfig);
    get assertionJson(): string;
    get body(): string;
    get description(): string;
    get downtimeThreshold(): number;
    get enabled(): cdktf.IResolvable;
    get environment(): string;
    private _headers;
    get headers(): cdktf.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get intervalSeconds(): number;
    get method(): string;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner;
    get owner(): DataSentryUptimeMonitorOwnerOutputReference;
    get projectId(): string;
    get recoveryThreshold(): number;
    get timeoutMs(): number;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
