import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryOrganizationIntegrationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integration#name DataSentryOrganizationIntegration#name}
    */
    readonly name: string;
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integration#organization DataSentryOrganizationIntegration#organization}
    */
    readonly organization: string;
    /**
    * Specific integration provider to filter by such as `slack`. See [the list of supported providers](https://docs.sentry.io/integrations/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integration#provider_key DataSentryOrganizationIntegration#provider_key}
    */
    readonly providerKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integration sentry_organization_integration}
*/
export declare class DataSentryOrganizationIntegration extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_organization_integration";
    /**
    * Generates CDKTF code for importing a DataSentryOrganizationIntegration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryOrganizationIntegration to import
    * @param importFromId The id of the existing DataSentryOrganizationIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryOrganizationIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_integration sentry_organization_integration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryOrganizationIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryOrganizationIntegrationConfig);
    get id(): string;
    get internalId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _providerKey?;
    get providerKey(): string;
    set providerKey(value: string);
    get providerKeyInput(): string | undefined;
    get rawJson(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
