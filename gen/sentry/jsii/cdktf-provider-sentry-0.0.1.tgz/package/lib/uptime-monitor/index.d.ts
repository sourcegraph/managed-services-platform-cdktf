import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UptimeMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * Define conditions that must be met for the check to be considered successful.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#assertion_json UptimeMonitor#assertion_json}
    */
    readonly assertionJson?: string;
    /**
    * The request body to send. Only applicable for methods that support a body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#body UptimeMonitor#body}
    */
    readonly body?: string;
    /**
    * A description of the monitor. Will be used in the resulting issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#description UptimeMonitor#description}
    */
    readonly description?: string;
    /**
    * Number of consecutive failed checks required to mark monitor as down. Defaults to `3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#downtime_threshold UptimeMonitor#downtime_threshold}
    */
    readonly downtimeThreshold?: number;
    /**
    * Whether the monitor is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#enabled UptimeMonitor#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Name of the environment to create uptime issues in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#environment UptimeMonitor#environment}
    */
    readonly environment: string;
    /**
    * The headers to send with the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#headers UptimeMonitor#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * The amount of time between each uptime check request. Valid values are: `60`, `300`, `600`, `1200`, `1800`, and `3600`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#interval_seconds UptimeMonitor#interval_seconds}
    */
    readonly intervalSeconds: number;
    /**
    * The HTTP method to use for the request. Valid values are: `GET`, `POST`, `HEAD`, `PUT`, `DELETE`, `PATCH`, and `OPTIONS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#method UptimeMonitor#method}
    */
    readonly method: string;
    /**
    * The name of this monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#name UptimeMonitor#name}
    */
    readonly name: string;
    /**
    * The organization slug or internal ID to create the monitor for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#organization UptimeMonitor#organization}
    */
    readonly organization: string;
    /**
    * Sentry will assign new issues to this assignee.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#owner UptimeMonitor#owner}
    */
    readonly owner?: UptimeMonitorOwner;
    /**
    * The project slug or internal ID to create the monitor for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#project UptimeMonitor#project}
    */
    readonly project: string;
    /**
    * Number of consecutive successful checks required to mark monitor as recovered. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#recovery_threshold UptimeMonitor#recovery_threshold}
    */
    readonly recoveryThreshold?: number;
    /**
    * The request timeout in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#timeout_ms UptimeMonitor#timeout_ms}
    */
    readonly timeoutMs: number;
    /**
    * The URL to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#url UptimeMonitor#url}
    */
    readonly url: string;
}
export interface UptimeMonitorOwner {
    /**
    * The team internal ID to assign new issues to. Conflicts with `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#team_id UptimeMonitor#team_id}
    */
    readonly teamId?: string;
    /**
    * The user ID to assign new issues to. Conflicts with `team_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#user_id UptimeMonitor#user_id}
    */
    readonly userId?: string;
}
export declare function uptimeMonitorOwnerToTerraform(struct?: UptimeMonitorOwner | cdktf.IResolvable): any;
export declare function uptimeMonitorOwnerToHclTerraform(struct?: UptimeMonitorOwner | cdktf.IResolvable): any;
export declare class UptimeMonitorOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UptimeMonitorOwner | cdktf.IResolvable | undefined;
    set internalValue(value: UptimeMonitorOwner | cdktf.IResolvable | undefined);
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    resetTeamId(): void;
    get teamIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor sentry_uptime_monitor}
*/
export declare class UptimeMonitor extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_uptime_monitor";
    /**
    * Generates CDKTF code for importing a UptimeMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UptimeMonitor to import
    * @param importFromId The id of the existing UptimeMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UptimeMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/uptime_monitor sentry_uptime_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UptimeMonitorConfig
    */
    constructor(scope: Construct, id: string, config: UptimeMonitorConfig);
    private _assertionJson?;
    get assertionJson(): string;
    set assertionJson(value: string);
    resetAssertionJson(): void;
    get assertionJsonInput(): string | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _downtimeThreshold?;
    get downtimeThreshold(): number;
    set downtimeThreshold(value: number);
    resetDowntimeThreshold(): void;
    get downtimeThresholdInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    get intervalSecondsInput(): number | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner;
    get owner(): UptimeMonitorOwnerOutputReference;
    putOwner(value: UptimeMonitorOwner): void;
    resetOwner(): void;
    get ownerInput(): cdktf.IResolvable | UptimeMonitorOwner | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _recoveryThreshold?;
    get recoveryThreshold(): number;
    set recoveryThreshold(value: number);
    resetRecoveryThreshold(): void;
    get recoveryThresholdInput(): number | undefined;
    private _timeoutMs?;
    get timeoutMs(): number;
    set timeoutMs(value: number);
    get timeoutMsInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
