import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MetricMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * Aggregate query to run on the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#aggregate MetricMonitor#aggregate}
    */
    readonly aggregate: string;
    /**
    * Issue detection condition group configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#condition_group MetricMonitor#condition_group}
    */
    readonly conditionGroup: MetricMonitorConditionGroup;
    /**
    * Dataset to run the aggregate query on. Valid values are: `events`, `transactions`, `discover`, `outcomes`, `outcomes_raw`, `sessions`, `metrics`, `generic_metrics`, `replays`, `profiles`, `search_issues`, `functions`, `spans`, and `events_analytics_platform`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#dataset MetricMonitor#dataset}
    */
    readonly dataset: string;
    /**
    * A description of the monitor. Will be used in the resulting issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#description MetricMonitor#description}
    */
    readonly description?: string;
    /**
    * Whether the monitor is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#enabled MetricMonitor#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Environment to run the aggregate query on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#environment MetricMonitor#environment}
    */
    readonly environment?: string;
    /**
    * Event types to run the aggregate query on. Valid values are: `error`, `default`, `transaction`, `trace_item_span`, `trace_item_log`, and `trace_item_metric`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#event_types MetricMonitor#event_types}
    */
    readonly eventTypes: string[];
    /**
    * Extrapolation mode to use for the aggregate query. Valid values are: `unknown`, `none`, `client_and_server_weighted`, and `server_weighted`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#extrapolation_mode MetricMonitor#extrapolation_mode}
    */
    readonly extrapolationMode?: string;
    /**
    * The issue detection type configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#issue_detection MetricMonitor#issue_detection}
    */
    readonly issueDetection: MetricMonitorIssueDetection;
    /**
    * The name of this monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#name MetricMonitor#name}
    */
    readonly name: string;
    /**
    * The organization slug or internal ID to create the monitor for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#organization MetricMonitor#organization}
    */
    readonly organization: string;
    /**
    * Sentry will assign new issues to this assignee.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#owner MetricMonitor#owner}
    */
    readonly owner?: MetricMonitorOwner;
    /**
    * The project slug or internal ID to create the monitor for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#project MetricMonitor#project}
    */
    readonly project: string;
    /**
    * An event search query to subscribe to and monitor for alerts. For example, to filter transactions so that only those with status code 400 are included, you could use `http.status_code:400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#query MetricMonitor#query}
    */
    readonly query?: string;
    /**
    * The type of query. If no value is provided, `query_type` is set to the default for the specified `dataset.` Valid values are: `error`, `performance`, and `crash_rate`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#query_type MetricMonitor#query_type}
    */
    readonly queryType?: string;
    /**
    * The time window in seconds to use for the aggregate query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#time_window_seconds MetricMonitor#time_window_seconds}
    */
    readonly timeWindowSeconds?: number;
}
export interface MetricMonitorConditionGroupConditions {
    /**
    * The value to compare against. Only required for types other than `anomaly_detection`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#comparison MetricMonitor#comparison}
    */
    readonly comparison?: number;
    /**
    * Choose your level of anomaly responsiveness. Higher thresholds means alerts for most anomalies. Lower thresholds means alerts only for larger ones. Only required for `anomaly_detection` type. Valid values are: `low`, `medium`, and `high`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#comparison_sensitivity MetricMonitor#comparison_sensitivity}
    */
    readonly comparisonSensitivity?: string;
    /**
    * Decide if you want to be alerted to anomalies that are moving above, below, or in both directions in relation to your threshold. Only required for `anomaly_detection` type. Valid values are: `above`, `below`, and `above_and_below`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#comparison_threshold_type MetricMonitor#comparison_threshold_type}
    */
    readonly comparisonThresholdType?: string;
    /**
    * When the condition is met, the result will be set to this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#condition_result MetricMonitor#condition_result}
    */
    readonly conditionResult: number;
    /**
    * The type of condition. Valid values are: `eq`, `gte`, `gt`, `lte`, `lt`, `ne`, `anomaly_detection`, `age_comparison`, `assigned_to`, `event_attribute`, `event_created_by_detector`, `event_seen_count`, `every_event`, `existing_high_priority_issue`, `first_seen_event`, `issue_category`, `issue_occurrences`, `issue_open_duration`, `issue_priority_deescalating`, `issue_priority_equals`, `issue_priority_greater_or_equal`, `issue_resolution_change`, `issue_resolved_trigger`, `issue_type`, `latest_adopted_release`, `latest_release`, `level`, `new_high_priority_issue`, `reappeared_event`, `regression_event`, `tagged_event`, `event_frequency_count`, `event_frequency_percent`, `event_unique_user_frequency_count`, `event_unique_user_frequency_percent`, `percent_sessions_count`, `percent_sessions_percent`, and `seer_activity_trigger`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#type MetricMonitor#type}
    */
    readonly type: string;
}
export declare function metricMonitorConditionGroupConditionsToTerraform(struct?: MetricMonitorConditionGroupConditions | cdktf.IResolvable): any;
export declare function metricMonitorConditionGroupConditionsToHclTerraform(struct?: MetricMonitorConditionGroupConditions | cdktf.IResolvable): any;
export declare class MetricMonitorConditionGroupConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MetricMonitorConditionGroupConditions | cdktf.IResolvable | undefined;
    set internalValue(value: MetricMonitorConditionGroupConditions | cdktf.IResolvable | undefined);
    private _comparison?;
    get comparison(): number;
    set comparison(value: number);
    resetComparison(): void;
    get comparisonInput(): number | undefined;
    private _comparisonSensitivity?;
    get comparisonSensitivity(): string;
    set comparisonSensitivity(value: string);
    resetComparisonSensitivity(): void;
    get comparisonSensitivityInput(): string | undefined;
    private _comparisonThresholdType?;
    get comparisonThresholdType(): string;
    set comparisonThresholdType(value: string);
    resetComparisonThresholdType(): void;
    get comparisonThresholdTypeInput(): string | undefined;
    private _conditionResult?;
    get conditionResult(): number;
    set conditionResult(value: number);
    get conditionResultInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class MetricMonitorConditionGroupConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: MetricMonitorConditionGroupConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MetricMonitorConditionGroupConditionsOutputReference;
}
export interface MetricMonitorConditionGroup {
    /**
    * Issue detection conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#conditions MetricMonitor#conditions}
    */
    readonly conditions: MetricMonitorConditionGroupConditions[] | cdktf.IResolvable;
    /**
    * The logic to apply to the conditions. `any` will evaluate all conditions, and return true if any of those are met. `any-short` will stop evaluating conditions as soon as one is met. `all` will evaluate all conditions, and return true if all of those are met. `none` will return true if none of the conditions are met, will return false immediately if any are met. Valid values are: `any`, `any-short`, `all`, and `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#logic_type MetricMonitor#logic_type}
    */
    readonly logicType?: string;
}
export declare function metricMonitorConditionGroupToTerraform(struct?: MetricMonitorConditionGroup | cdktf.IResolvable): any;
export declare function metricMonitorConditionGroupToHclTerraform(struct?: MetricMonitorConditionGroup | cdktf.IResolvable): any;
export declare class MetricMonitorConditionGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetricMonitorConditionGroup | cdktf.IResolvable | undefined;
    set internalValue(value: MetricMonitorConditionGroup | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): MetricMonitorConditionGroupConditionsList;
    putConditions(value: MetricMonitorConditionGroupConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | MetricMonitorConditionGroupConditions[] | undefined;
    private _logicType?;
    get logicType(): string;
    set logicType(value: string);
    resetLogicType(): void;
    get logicTypeInput(): string | undefined;
}
export interface MetricMonitorIssueDetection {
    /**
    * The comparison delta in seconds to use for the aggregate query. Only required for `percent` type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#comparison_delta MetricMonitor#comparison_delta}
    */
    readonly comparisonDelta?: number;
    /**
    * `static`: Threshold based monitor; `percent`: Change based monitor; `dynamic`: Dynamic monitor. Valid values are: `static`, `percent`, and `dynamic`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#type MetricMonitor#type}
    */
    readonly type: string;
}
export declare function metricMonitorIssueDetectionToTerraform(struct?: MetricMonitorIssueDetection | cdktf.IResolvable): any;
export declare function metricMonitorIssueDetectionToHclTerraform(struct?: MetricMonitorIssueDetection | cdktf.IResolvable): any;
export declare class MetricMonitorIssueDetectionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetricMonitorIssueDetection | cdktf.IResolvable | undefined;
    set internalValue(value: MetricMonitorIssueDetection | cdktf.IResolvable | undefined);
    private _comparisonDelta?;
    get comparisonDelta(): number;
    set comparisonDelta(value: number);
    resetComparisonDelta(): void;
    get comparisonDeltaInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface MetricMonitorOwner {
    /**
    * The team internal ID to assign new issues to. Conflicts with `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#team_id MetricMonitor#team_id}
    */
    readonly teamId?: string;
    /**
    * The user ID to assign new issues to. Conflicts with `team_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#user_id MetricMonitor#user_id}
    */
    readonly userId?: string;
}
export declare function metricMonitorOwnerToTerraform(struct?: MetricMonitorOwner | cdktf.IResolvable): any;
export declare function metricMonitorOwnerToHclTerraform(struct?: MetricMonitorOwner | cdktf.IResolvable): any;
export declare class MetricMonitorOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetricMonitorOwner | cdktf.IResolvable | undefined;
    set internalValue(value: MetricMonitorOwner | cdktf.IResolvable | undefined);
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    resetTeamId(): void;
    get teamIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor sentry_metric_monitor}
*/
export declare class MetricMonitor extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_metric_monitor";
    /**
    * Generates CDKTF code for importing a MetricMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MetricMonitor to import
    * @param importFromId The id of the existing MetricMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MetricMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/metric_monitor sentry_metric_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MetricMonitorConfig
    */
    constructor(scope: Construct, id: string, config: MetricMonitorConfig);
    private _aggregate?;
    get aggregate(): string;
    set aggregate(value: string);
    get aggregateInput(): string | undefined;
    private _conditionGroup;
    get conditionGroup(): MetricMonitorConditionGroupOutputReference;
    putConditionGroup(value: MetricMonitorConditionGroup): void;
    get conditionGroupInput(): cdktf.IResolvable | MetricMonitorConditionGroup | undefined;
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _eventTypes?;
    get eventTypes(): string[];
    set eventTypes(value: string[]);
    get eventTypesInput(): string[] | undefined;
    private _extrapolationMode?;
    get extrapolationMode(): string;
    set extrapolationMode(value: string);
    resetExtrapolationMode(): void;
    get extrapolationModeInput(): string | undefined;
    get id(): string;
    private _issueDetection;
    get issueDetection(): MetricMonitorIssueDetectionOutputReference;
    putIssueDetection(value: MetricMonitorIssueDetection): void;
    get issueDetectionInput(): cdktf.IResolvable | MetricMonitorIssueDetection | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner;
    get owner(): MetricMonitorOwnerOutputReference;
    putOwner(value: MetricMonitorOwner): void;
    resetOwner(): void;
    get ownerInput(): cdktf.IResolvable | MetricMonitorOwner | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _queryType?;
    get queryType(): string;
    set queryType(value: string);
    resetQueryType(): void;
    get queryTypeInput(): string | undefined;
    private _timeWindowSeconds?;
    get timeWindowSeconds(): number;
    set timeWindowSeconds(value: number);
    resetTimeWindowSeconds(): void;
    get timeWindowSecondsInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
