import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryOrganizationMemberConfig extends cdktf.TerraformMetaArguments {
    /**
    * The email of the organization member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_member#email DataSentryOrganizationMember#email}
    */
    readonly email: string;
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_member#organization DataSentryOrganizationMember#organization}
    */
    readonly organization: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_member sentry_organization_member}
*/
export declare class DataSentryOrganizationMember extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_organization_member";
    /**
    * Generates CDKTF code for importing a DataSentryOrganizationMember resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryOrganizationMember to import
    * @param importFromId The id of the existing DataSentryOrganizationMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryOrganizationMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/organization_member sentry_organization_member} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryOrganizationMemberConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryOrganizationMemberConfig);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    get id(): string;
    get internalId(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get role(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
