import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The JavaScript loader script configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#javascript_loader_script Key#javascript_loader_script}
    */
    readonly javascriptLoaderScript?: KeyJavascriptLoaderScript;
    /**
    * The name of the client key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#name Key#name}
    */
    readonly name: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#organization Key#organization}
    */
    readonly organization: string;
    /**
    * The project of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#project Key#project}
    */
    readonly project: string;
    /**
    * Number of events that can be reported within the rate limit window.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#rate_limit_count Key#rate_limit_count}
    */
    readonly rateLimitCount?: number;
    /**
    * Length of time in seconds that will be considered when checking the rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#rate_limit_window Key#rate_limit_window}
    */
    readonly rateLimitWindow?: number;
}
export interface KeyJavascriptLoaderScript {
    /**
    * The version of the browser SDK to load.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#browser_sdk_version Key#browser_sdk_version}
    */
    readonly browserSdkVersion?: string;
    /**
    * Whether debug bundles & logging are enabled for this key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#debug_enabled Key#debug_enabled}
    */
    readonly debugEnabled?: boolean | cdktf.IResolvable;
    /**
    * Whether performance monitoring is enabled for this key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#performance_monitoring_enabled Key#performance_monitoring_enabled}
    */
    readonly performanceMonitoringEnabled?: boolean | cdktf.IResolvable;
    /**
    * Whether session replay is enabled for this key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#session_replay_enabled Key#session_replay_enabled}
    */
    readonly sessionReplayEnabled?: boolean | cdktf.IResolvable;
}
export declare function keyJavascriptLoaderScriptToTerraform(struct?: KeyJavascriptLoaderScript | cdktf.IResolvable): any;
export declare function keyJavascriptLoaderScriptToHclTerraform(struct?: KeyJavascriptLoaderScript | cdktf.IResolvable): any;
export declare class KeyJavascriptLoaderScriptOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KeyJavascriptLoaderScript | cdktf.IResolvable | undefined;
    set internalValue(value: KeyJavascriptLoaderScript | cdktf.IResolvable | undefined);
    private _browserSdkVersion?;
    get browserSdkVersion(): string;
    set browserSdkVersion(value: string);
    resetBrowserSdkVersion(): void;
    get browserSdkVersionInput(): string | undefined;
    private _debugEnabled?;
    get debugEnabled(): boolean | cdktf.IResolvable;
    set debugEnabled(value: boolean | cdktf.IResolvable);
    resetDebugEnabled(): void;
    get debugEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _performanceMonitoringEnabled?;
    get performanceMonitoringEnabled(): boolean | cdktf.IResolvable;
    set performanceMonitoringEnabled(value: boolean | cdktf.IResolvable);
    resetPerformanceMonitoringEnabled(): void;
    get performanceMonitoringEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sessionReplayEnabled?;
    get sessionReplayEnabled(): boolean | cdktf.IResolvable;
    set sessionReplayEnabled(value: boolean | cdktf.IResolvable);
    resetSessionReplayEnabled(): void;
    get sessionReplayEnabledInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key sentry_key}
*/
export declare class Key extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_key";
    /**
    * Generates CDKTF code for importing a Key resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Key to import
    * @param importFromId The id of the existing Key that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Key to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/key sentry_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KeyConfig
    */
    constructor(scope: Construct, id: string, config: KeyConfig);
    private _dsn;
    get dsn(): cdktf.StringMap;
    get dsnCsp(): string;
    get dsnPublic(): string;
    get dsnSecret(): string;
    get id(): string;
    private _javascriptLoaderScript;
    get javascriptLoaderScript(): KeyJavascriptLoaderScriptOutputReference;
    putJavascriptLoaderScript(value: KeyJavascriptLoaderScript): void;
    resetJavascriptLoaderScript(): void;
    get javascriptLoaderScriptInput(): cdktf.IResolvable | KeyJavascriptLoaderScript | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get projectId(): string;
    get public(): string;
    private _rateLimitCount?;
    get rateLimitCount(): number;
    set rateLimitCount(value: number);
    resetRateLimitCount(): void;
    get rateLimitCountInput(): number | undefined;
    private _rateLimitWindow?;
    get rateLimitWindow(): number;
    set rateLimitWindow(value: number);
    resetRateLimitWindow(): void;
    get rateLimitWindowInput(): number | undefined;
    get secret(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
