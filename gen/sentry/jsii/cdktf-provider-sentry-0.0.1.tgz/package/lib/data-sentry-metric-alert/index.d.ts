import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryMetricAlertConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_alert#id DataSentryMetricAlert#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The internal ID for this metric alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_alert#internal_id DataSentryMetricAlert#internal_id}
    */
    readonly internalId: string;
    /**
    * The slug of the organization the metric alert belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_alert#organization DataSentryMetricAlert#organization}
    */
    readonly organization: string;
    /**
    * The slug of the project the metric alert belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_alert#project DataSentryMetricAlert#project}
    */
    readonly project: string;
}
export interface DataSentryMetricAlertTriggerAction {
}
export declare function dataSentryMetricAlertTriggerActionToTerraform(struct?: DataSentryMetricAlertTriggerAction): any;
export declare function dataSentryMetricAlertTriggerActionToHclTerraform(struct?: DataSentryMetricAlertTriggerAction): any;
export declare class DataSentryMetricAlertTriggerActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryMetricAlertTriggerAction | undefined;
    set internalValue(value: DataSentryMetricAlertTriggerAction | undefined);
    get id(): string;
    get inputChannelId(): string;
    get integrationId(): number;
    get targetIdentifier(): string;
    get targetType(): string;
    get type(): string;
}
export declare class DataSentryMetricAlertTriggerActionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryMetricAlertTriggerActionOutputReference;
}
export interface DataSentryMetricAlertTrigger {
}
export declare function dataSentryMetricAlertTriggerToTerraform(struct?: DataSentryMetricAlertTrigger): any;
export declare function dataSentryMetricAlertTriggerToHclTerraform(struct?: DataSentryMetricAlertTrigger): any;
export declare class DataSentryMetricAlertTriggerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryMetricAlertTrigger | undefined;
    set internalValue(value: DataSentryMetricAlertTrigger | undefined);
    private _action;
    get action(): DataSentryMetricAlertTriggerActionList;
    get alertThreshold(): number;
    get id(): string;
    get label(): string;
    get resolveThreshold(): number;
    get thresholdType(): number;
}
export declare class DataSentryMetricAlertTriggerList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryMetricAlertTriggerOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_alert sentry_metric_alert}
*/
export declare class DataSentryMetricAlert extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_metric_alert";
    /**
    * Generates CDKTF code for importing a DataSentryMetricAlert resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryMetricAlert to import
    * @param importFromId The id of the existing DataSentryMetricAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryMetricAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_alert sentry_metric_alert} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryMetricAlertConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryMetricAlertConfig);
    get aggregate(): string;
    get dataset(): string;
    get environment(): string;
    get eventTypes(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _internalId?;
    get internalId(): string;
    set internalId(value: string);
    get internalIdInput(): string | undefined;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get owner(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get query(): string;
    get resolveThreshold(): number;
    get thresholdType(): number;
    get timeWindow(): number;
    private _trigger;
    get trigger(): DataSentryMetricAlertTriggerList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
