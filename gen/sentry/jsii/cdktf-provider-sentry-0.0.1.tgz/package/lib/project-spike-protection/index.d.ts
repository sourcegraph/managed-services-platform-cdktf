import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectSpikeProtectionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Toggle the browser-extensions, localhost, filtered-transaction, or web-crawlers filter on or off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_spike_protection#enabled ProjectSpikeProtection#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_spike_protection#organization ProjectSpikeProtection#organization}
    */
    readonly organization: string;
    /**
    * The project of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_spike_protection#project ProjectSpikeProtection#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_spike_protection sentry_project_spike_protection}
*/
export declare class ProjectSpikeProtection extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_project_spike_protection";
    /**
    * Generates CDKTF code for importing a ProjectSpikeProtection resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectSpikeProtection to import
    * @param importFromId The id of the existing ProjectSpikeProtection that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_spike_protection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectSpikeProtection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_spike_protection sentry_project_spike_protection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectSpikeProtectionConfig
    */
    constructor(scope: Construct, id: string, config: ProjectSpikeProtectionConfig);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
