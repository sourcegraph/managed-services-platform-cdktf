import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface OrganizationCodeMappingConfig extends cdktf.TerraformMetaArguments {
    /**
    * Default branch of your code we fall back to if you do not have commit tracking set up.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#default_branch OrganizationCodeMapping#default_branch}
    */
    readonly defaultBranch: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#id OrganizationCodeMapping#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Sentry Organization Integration ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#integration_id OrganizationCodeMapping#integration_id}
    */
    readonly integrationId: string;
    /**
    * The slug of the organization the code mapping is under.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#organization OrganizationCodeMapping#organization}
    */
    readonly organization: string;
    /**
    * Sentry Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#project_id OrganizationCodeMapping#project_id}
    */
    readonly projectId: string;
    /**
    * Sentry Organization Repository ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#repository_id OrganizationCodeMapping#repository_id}
    */
    readonly repositoryId: string;
    /**
    * https://docs.sentry.io/product/integrations/source-code-mgmt/github/#stack-trace-linking
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#source_root OrganizationCodeMapping#source_root}
    */
    readonly sourceRoot?: string;
    /**
    * https://docs.sentry.io/product/integrations/source-code-mgmt/github/#stack-trace-linking
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#stack_root OrganizationCodeMapping#stack_root}
    */
    readonly stackRoot?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping sentry_organization_code_mapping}
*/
export declare class OrganizationCodeMapping extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_organization_code_mapping";
    /**
    * Generates CDKTF code for importing a OrganizationCodeMapping resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrganizationCodeMapping to import
    * @param importFromId The id of the existing OrganizationCodeMapping that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrganizationCodeMapping to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/organization_code_mapping sentry_organization_code_mapping} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationCodeMappingConfig
    */
    constructor(scope: Construct, id: string, config: OrganizationCodeMappingConfig);
    private _defaultBranch?;
    get defaultBranch(): string;
    set defaultBranch(value: string);
    get defaultBranchInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    get internalId(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    private _sourceRoot?;
    get sourceRoot(): string;
    set sourceRoot(value: string);
    resetSourceRoot(): void;
    get sourceRootInput(): string | undefined;
    private _stackRoot?;
    get stackRoot(): string;
    set stackRoot(value: string);
    resetStackRoot(): void;
    get stackRootInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
