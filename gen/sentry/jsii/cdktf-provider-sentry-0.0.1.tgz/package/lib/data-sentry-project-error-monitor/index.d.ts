import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryProjectErrorMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * Return the first monitor found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_error_monitor#first DataSentryProjectErrorMonitor#first}
    */
    readonly first?: boolean | cdktf.IResolvable;
    /**
    * The organization slug or internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_error_monitor#organization DataSentryProjectErrorMonitor#organization}
    */
    readonly organization: string;
    /**
    * The project slug or internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_error_monitor#project DataSentryProjectErrorMonitor#project}
    */
    readonly project: string;
}
export interface DataSentryProjectErrorMonitorOwner {
}
export declare function dataSentryProjectErrorMonitorOwnerToTerraform(struct?: DataSentryProjectErrorMonitorOwner): any;
export declare function dataSentryProjectErrorMonitorOwnerToHclTerraform(struct?: DataSentryProjectErrorMonitorOwner): any;
export declare class DataSentryProjectErrorMonitorOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryProjectErrorMonitorOwner | undefined;
    set internalValue(value: DataSentryProjectErrorMonitorOwner | undefined);
    get teamId(): string;
    get userId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_error_monitor sentry_project_error_monitor}
*/
export declare class DataSentryProjectErrorMonitor extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_project_error_monitor";
    /**
    * Generates CDKTF code for importing a DataSentryProjectErrorMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryProjectErrorMonitor to import
    * @param importFromId The id of the existing DataSentryProjectErrorMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_error_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryProjectErrorMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_error_monitor sentry_project_error_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryProjectErrorMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryProjectErrorMonitorConfig);
    get description(): string;
    get enabled(): cdktf.IResolvable;
    private _first?;
    get first(): boolean | cdktf.IResolvable;
    set first(value: boolean | cdktf.IResolvable);
    resetFirst(): void;
    get firstInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner;
    get owner(): DataSentryProjectErrorMonitorOwnerOutputReference;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
