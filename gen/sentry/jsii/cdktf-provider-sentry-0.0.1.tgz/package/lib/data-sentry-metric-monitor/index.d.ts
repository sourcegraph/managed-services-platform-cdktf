import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryMetricMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * The internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_monitor#id DataSentryMetricMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The organization slug or internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_monitor#organization DataSentryMetricMonitor#organization}
    */
    readonly organization: string;
}
export interface DataSentryMetricMonitorConditionGroupConditions {
}
export declare function dataSentryMetricMonitorConditionGroupConditionsToTerraform(struct?: DataSentryMetricMonitorConditionGroupConditions): any;
export declare function dataSentryMetricMonitorConditionGroupConditionsToHclTerraform(struct?: DataSentryMetricMonitorConditionGroupConditions): any;
export declare class DataSentryMetricMonitorConditionGroupConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryMetricMonitorConditionGroupConditions | undefined;
    set internalValue(value: DataSentryMetricMonitorConditionGroupConditions | undefined);
    get comparison(): number;
    get comparisonSensitivity(): string;
    get comparisonThresholdType(): string;
    get conditionResult(): number;
    get type(): string;
}
export declare class DataSentryMetricMonitorConditionGroupConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryMetricMonitorConditionGroupConditionsOutputReference;
}
export interface DataSentryMetricMonitorConditionGroup {
}
export declare function dataSentryMetricMonitorConditionGroupToTerraform(struct?: DataSentryMetricMonitorConditionGroup): any;
export declare function dataSentryMetricMonitorConditionGroupToHclTerraform(struct?: DataSentryMetricMonitorConditionGroup): any;
export declare class DataSentryMetricMonitorConditionGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryMetricMonitorConditionGroup | undefined;
    set internalValue(value: DataSentryMetricMonitorConditionGroup | undefined);
    private _conditions;
    get conditions(): DataSentryMetricMonitorConditionGroupConditionsList;
    get logicType(): string;
}
export interface DataSentryMetricMonitorIssueDetection {
}
export declare function dataSentryMetricMonitorIssueDetectionToTerraform(struct?: DataSentryMetricMonitorIssueDetection): any;
export declare function dataSentryMetricMonitorIssueDetectionToHclTerraform(struct?: DataSentryMetricMonitorIssueDetection): any;
export declare class DataSentryMetricMonitorIssueDetectionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryMetricMonitorIssueDetection | undefined;
    set internalValue(value: DataSentryMetricMonitorIssueDetection | undefined);
    get comparisonDelta(): number;
    get type(): string;
}
export interface DataSentryMetricMonitorOwner {
}
export declare function dataSentryMetricMonitorOwnerToTerraform(struct?: DataSentryMetricMonitorOwner): any;
export declare function dataSentryMetricMonitorOwnerToHclTerraform(struct?: DataSentryMetricMonitorOwner): any;
export declare class DataSentryMetricMonitorOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryMetricMonitorOwner | undefined;
    set internalValue(value: DataSentryMetricMonitorOwner | undefined);
    get teamId(): string;
    get userId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_monitor sentry_metric_monitor}
*/
export declare class DataSentryMetricMonitor extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_metric_monitor";
    /**
    * Generates CDKTF code for importing a DataSentryMetricMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryMetricMonitor to import
    * @param importFromId The id of the existing DataSentryMetricMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryMetricMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/metric_monitor sentry_metric_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryMetricMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryMetricMonitorConfig);
    get aggregate(): string;
    private _conditionGroup;
    get conditionGroup(): DataSentryMetricMonitorConditionGroupOutputReference;
    get dataset(): string;
    get description(): string;
    get enabled(): cdktf.IResolvable;
    get environment(): string;
    get eventTypes(): string[];
    get extrapolationMode(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _issueDetection;
    get issueDetection(): DataSentryMetricMonitorIssueDetectionOutputReference;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner;
    get owner(): DataSentryMetricMonitorOwnerOutputReference;
    get projectId(): string;
    get query(): string;
    get queryType(): string;
    get timeWindowSeconds(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
