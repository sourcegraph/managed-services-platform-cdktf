import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TeamMemberConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the member to add to the team.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team_member#member_id TeamMember#member_id}
    */
    readonly memberId: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team_member#organization TeamMember#organization}
    */
    readonly organization: string;
    /**
    * The role of the member in the team. When not set, resolve to the minimum team role given by this member's organization role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team_member#role TeamMember#role}
    */
    readonly role?: string;
    /**
    * The slug of the team to add the member to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team_member#team TeamMember#team}
    */
    readonly team: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team_member sentry_team_member}
*/
export declare class TeamMember extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_team_member";
    /**
    * Generates CDKTF code for importing a TeamMember resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamMember to import
    * @param importFromId The id of the existing TeamMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/team_member sentry_team_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamMemberConfig
    */
    constructor(scope: Construct, id: string, config: TeamMemberConfig);
    get effectiveRole(): string;
    get id(): string;
    private _memberId?;
    get memberId(): string;
    set memberId(value: string);
    get memberIdInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _team?;
    get team(): string;
    set team(value: string);
    get teamInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
