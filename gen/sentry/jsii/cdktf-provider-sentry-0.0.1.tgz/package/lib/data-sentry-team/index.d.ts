import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryTeamConfig extends cdktf.TerraformMetaArguments {
    /**
    * The organization slug or internal ID of the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/team#organization DataSentryTeam#organization}
    */
    readonly organization: string;
    /**
    * The team slug.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/team#slug DataSentryTeam#slug}
    */
    readonly slug: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/team sentry_team}
*/
export declare class DataSentryTeam extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_team";
    /**
    * Generates CDKTF code for importing a DataSentryTeam resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryTeam to import
    * @param importFromId The id of the existing DataSentryTeam that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/team#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryTeam to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/team sentry_team} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryTeamConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryTeamConfig);
    get hasAccess(): cdktf.IResolvable;
    get id(): string;
    get internalId(): string;
    get isMember(): cdktf.IResolvable;
    get isPending(): cdktf.IResolvable;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _slug?;
    get slug(): string;
    set slug(value: string);
    get slugInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
