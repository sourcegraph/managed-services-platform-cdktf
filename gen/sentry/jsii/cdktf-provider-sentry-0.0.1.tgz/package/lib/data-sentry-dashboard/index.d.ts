import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryDashboardConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/dashboard#id DataSentryDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The internal ID for this dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/dashboard#internal_id DataSentryDashboard#internal_id}
    */
    readonly internalId: string;
    /**
    * The slug of the organization the dashboard belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/dashboard#organization DataSentryDashboard#organization}
    */
    readonly organization: string;
}
export interface DataSentryDashboardWidgetLayout {
}
export declare function dataSentryDashboardWidgetLayoutToTerraform(struct?: DataSentryDashboardWidgetLayout): any;
export declare function dataSentryDashboardWidgetLayoutToHclTerraform(struct?: DataSentryDashboardWidgetLayout): any;
export declare class DataSentryDashboardWidgetLayoutOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryDashboardWidgetLayout | undefined;
    set internalValue(value: DataSentryDashboardWidgetLayout | undefined);
    get h(): number;
    get minH(): number;
    get w(): number;
    get x(): number;
    get y(): number;
}
export declare class DataSentryDashboardWidgetLayoutList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryDashboardWidgetLayoutOutputReference;
}
export interface DataSentryDashboardWidgetQuery {
}
export declare function dataSentryDashboardWidgetQueryToTerraform(struct?: DataSentryDashboardWidgetQuery): any;
export declare function dataSentryDashboardWidgetQueryToHclTerraform(struct?: DataSentryDashboardWidgetQuery): any;
export declare class DataSentryDashboardWidgetQueryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryDashboardWidgetQuery | undefined;
    set internalValue(value: DataSentryDashboardWidgetQuery | undefined);
    get aggregates(): string[];
    get columns(): string[];
    get conditions(): string;
    get fieldAliases(): string[];
    get fields(): string[];
    get id(): string;
    get name(): string;
    get orderBy(): string;
}
export declare class DataSentryDashboardWidgetQueryList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryDashboardWidgetQueryOutputReference;
}
export interface DataSentryDashboardWidget {
}
export declare function dataSentryDashboardWidgetToTerraform(struct?: DataSentryDashboardWidget): any;
export declare function dataSentryDashboardWidgetToHclTerraform(struct?: DataSentryDashboardWidget): any;
export declare class DataSentryDashboardWidgetOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryDashboardWidget | undefined;
    set internalValue(value: DataSentryDashboardWidget | undefined);
    get displayType(): string;
    get id(): string;
    get interval(): string;
    private _layout;
    get layout(): DataSentryDashboardWidgetLayoutList;
    get limit(): number;
    private _query;
    get query(): DataSentryDashboardWidgetQueryList;
    get title(): string;
    get widgetType(): string;
}
export declare class DataSentryDashboardWidgetList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryDashboardWidgetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/dashboard sentry_dashboard}
*/
export declare class DataSentryDashboard extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_dashboard";
    /**
    * Generates CDKTF code for importing a DataSentryDashboard resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryDashboard to import
    * @param importFromId The id of the existing DataSentryDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/dashboard sentry_dashboard} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryDashboardConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryDashboardConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _internalId?;
    get internalId(): string;
    set internalId(value: string);
    get internalIdInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get title(): string;
    private _widget;
    get widget(): DataSentryDashboardWidgetList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
