import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * Configure origin URLs which Sentry should accept events from. This is used for communication with clients like [sentry-javascript](https://github.com/getsentry/sentry-javascript).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#client_security Project#client_security}
    */
    readonly clientSecurity?: ProjectClientSecurity;
    /**
    * Whether to create a default key on project creation. By default, Sentry will create a key for you. If you wish to manage keys manually, set this to false and create keys using the `sentry_key` resource. Note that this only takes effect on project creation, not on project update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#default_key Project#default_key}
    */
    readonly defaultKey?: boolean | cdktf.IResolvable;
    /**
    * Whether to create a default issue alert. Defaults to true where the behavior is to alert the user on every new issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#default_rules Project#default_rules}
    */
    readonly defaultRules?: boolean | cdktf.IResolvable;
    /**
    * The maximum amount of time (in seconds) to wait between scheduling digests for delivery.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#digests_max_delay Project#digests_max_delay}
    */
    readonly digestsMaxDelay?: number;
    /**
    * The minimum amount of time (in seconds) to wait between scheduling digests for delivery after the initial scheduling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#digests_min_delay Project#digests_min_delay}
    */
    readonly digestsMinDelay?: number;
    /**
    * Custom filters for this project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#filters Project#filters}
    */
    readonly filters?: ProjectFilters;
    /**
    * This can be used to modify the fingerprint rules on the server with custom rules. Rules follow the pattern `matcher:glob -> fingerprint, values`. To learn more about fingerprint rules, [read the docs](https://docs.sentry.io/concepts/data-management/event-grouping/fingerprint-rules/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#fingerprinting_rules Project#fingerprinting_rules}
    */
    readonly fingerprintingRules?: string;
    /**
    * This can be used to enhance the grouping algorithm with custom rules. Rules follow the pattern `matcher:glob [v^]?[+-]flag`. To learn more about stack trace rules, [read the docs](https://docs.sentry.io/concepts/data-management/event-grouping/stack-trace-rules/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#grouping_enhancements Project#grouping_enhancements}
    */
    readonly groupingEnhancements?: string;
    /**
    * A list of strings with tag keys to highlight on this project's issues. E.g. ['release', 'environment']
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#highlight_tags Project#highlight_tags}
    */
    readonly highlightTags?: string[];
    /**
    * The name for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#name Project#name}
    */
    readonly name: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#organization Project#organization}
    */
    readonly organization: string;
    /**
    * The platform for this project. Use `other` for platforms not listed. Valid values are: `other`, `android`, `apple`, `apple-ios`, `apple-macos`, `bun`, `capacitor`, `cordova`, `dart`, `deno`, `dotnet`, `dotnet-aspnet`, `dotnet-aspnetcore`, `dotnet-awslambda`, `dotnet-gcpfunctions`, `dotnet-maui`, `dotnet-uwp`, `dotnet-winforms`, `dotnet-wpf`, `dotnet-xamarin`, `electron`, `elixir`, `flutter`, `go`, `go-echo`, `go-fasthttp`, `go-fiber`, `go-gin`, `go-http`, `go-iris`, `go-martini`, `go-negroni`, `godot`, `ionic`, `java`, `java-log4j2`, `java-logback`, `java-spring`, `java-spring-boot`, `javascript`, `javascript-angular`, `javascript-astro`, `javascript-ember`, `javascript-gatsby`, `javascript-nextjs`, `javascript-nuxt`, `javascript-react`, `javascript-react-router`, `javascript-remix`, `javascript-solid`, `javascript-solidstart`, `javascript-svelte`, `javascript-sveltekit`, `javascript-tanstackstart-react`, `javascript-vue`, `kotlin`, `minidump`, `native`, `native-qt`, `nintendo-switch`, `node`, `node-awslambda`, `node-azurefunctions`, `node-cloudflare-pages`, `node-cloudflare-workers`, `node-connect`, `node-express`, `node-fastify`, `node-gcpfunctions`, `node-hapi`, `node-hono`, `node-koa`, `node-nestjs`, `php`, `php-laravel`, `php-symfony`, `playstation`, `powershell`, `python`, `python-aiohttp`, `python-asgi`, `python-awslambda`, `python-bottle`, `python-celery`, `python-chalice`, `python-django`, `python-falcon`, `python-fastapi`, `python-flask`, `python-gcpfunctions`, `python-litestar`, `python-pylons`, `python-pymongo`, `python-pyramid`, `python-quart`, `python-rq`, `python-sanic`, `python-serverless`, `python-starlette`, `python-tornado`, `python-tryton`, `python-wsgi`, `react-native`, `ruby`, `ruby-rack`, `ruby-rails`, `rust`, `unity`, `unreal`, and `xbox`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#platform Project#platform}
    */
    readonly platform: string;
    /**
    * Hours in which an issue is automatically resolve if not seen after this amount of time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#resolve_age Project#resolve_age}
    */
    readonly resolveAge?: number;
    /**
    * The optional slug for this project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#slug Project#slug}
    */
    readonly slug?: string;
    /**
    * The slugs of the teams to create the project for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#teams Project#teams}
    */
    readonly teams: string[];
}
export interface ProjectClientSecurity {
    /**
    * A list of allowed domains. Examples: https://example.com, *, *.example.com, *:80.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#allowed_domains Project#allowed_domains}
    */
    readonly allowedDomains?: string[];
    /**
    * Enable JavaScript source fetching. Allow Sentry to scrape missing JavaScript source context when possible.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#scrape_javascript Project#scrape_javascript}
    */
    readonly scrapeJavascript?: boolean | cdktf.IResolvable;
    /**
    * Security Token. Outbound requests matching Allowed Domains will have the header "{security_token_header}: {security_token}" appended.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#security_token Project#security_token}
    */
    readonly securityToken?: string;
    /**
    * Security Token Header. Outbound requests matching Allowed Domains will have the header "{security_token_header}: {security_token}" appended.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#security_token_header Project#security_token_header}
    */
    readonly securityTokenHeader?: string;
    /**
    * Verify TLS/SSL. Outbound requests will verify TLS (sometimes known as SSL) connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#verify_tls_ssl Project#verify_tls_ssl}
    */
    readonly verifyTlsSsl?: boolean | cdktf.IResolvable;
}
export declare function projectClientSecurityToTerraform(struct?: ProjectClientSecurity | cdktf.IResolvable): any;
export declare function projectClientSecurityToHclTerraform(struct?: ProjectClientSecurity | cdktf.IResolvable): any;
export declare class ProjectClientSecurityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectClientSecurity | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectClientSecurity | cdktf.IResolvable | undefined);
    private _allowedDomains?;
    get allowedDomains(): string[];
    set allowedDomains(value: string[]);
    resetAllowedDomains(): void;
    get allowedDomainsInput(): string[] | undefined;
    private _scrapeJavascript?;
    get scrapeJavascript(): boolean | cdktf.IResolvable;
    set scrapeJavascript(value: boolean | cdktf.IResolvable);
    resetScrapeJavascript(): void;
    get scrapeJavascriptInput(): boolean | cdktf.IResolvable | undefined;
    private _securityToken?;
    get securityToken(): string;
    set securityToken(value: string);
    resetSecurityToken(): void;
    get securityTokenInput(): string | undefined;
    private _securityTokenHeader?;
    get securityTokenHeader(): string;
    set securityTokenHeader(value: string);
    resetSecurityTokenHeader(): void;
    get securityTokenHeaderInput(): string | undefined;
    private _verifyTlsSsl?;
    get verifyTlsSsl(): boolean | cdktf.IResolvable;
    set verifyTlsSsl(value: boolean | cdktf.IResolvable);
    resetVerifyTlsSsl(): void;
    get verifyTlsSslInput(): boolean | cdktf.IResolvable | undefined;
}
export interface ProjectFilters {
    /**
    * Filter events from these IP addresses. (e.g. 127.0.0.1 or 10.0.0.0/8)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#blacklisted_ips Project#blacklisted_ips}
    */
    readonly blacklistedIps?: string[];
    /**
    * Filter events by error messages. Allows [glob pattern matching](https://en.wikipedia.org/wiki/Glob_(programming)). (e.g. TypeError* or *: integer division or modulo by zero)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#error_messages Project#error_messages}
    */
    readonly errorMessages?: string[];
    /**
    * Filter events from these releases. Allows [glob pattern matching](https://en.wikipedia.org/wiki/Glob_(programming)). (e.g. 1.* or [!3].[0-9].*)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#releases Project#releases}
    */
    readonly releases?: string[];
}
export declare function projectFiltersToTerraform(struct?: ProjectFilters | cdktf.IResolvable): any;
export declare function projectFiltersToHclTerraform(struct?: ProjectFilters | cdktf.IResolvable): any;
export declare class ProjectFiltersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectFilters | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectFilters | cdktf.IResolvable | undefined);
    private _blacklistedIps?;
    get blacklistedIps(): string[];
    set blacklistedIps(value: string[]);
    resetBlacklistedIps(): void;
    get blacklistedIpsInput(): string[] | undefined;
    private _errorMessages?;
    get errorMessages(): string[];
    set errorMessages(value: string[]);
    resetErrorMessages(): void;
    get errorMessagesInput(): string[] | undefined;
    private _releases?;
    get releases(): string[];
    set releases(value: string[]);
    resetReleases(): void;
    get releasesInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project sentry_project}
*/
export declare class Project extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_project";
    /**
    * Generates CDKTF code for importing a Project resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Project to import
    * @param importFromId The id of the existing Project that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Project to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project sentry_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectConfig
    */
    constructor(scope: Construct, id: string, config: ProjectConfig);
    private _clientSecurity;
    get clientSecurity(): ProjectClientSecurityOutputReference;
    putClientSecurity(value: ProjectClientSecurity): void;
    resetClientSecurity(): void;
    get clientSecurityInput(): cdktf.IResolvable | ProjectClientSecurity | undefined;
    private _defaultKey?;
    get defaultKey(): boolean | cdktf.IResolvable;
    set defaultKey(value: boolean | cdktf.IResolvable);
    resetDefaultKey(): void;
    get defaultKeyInput(): boolean | cdktf.IResolvable | undefined;
    private _defaultRules?;
    get defaultRules(): boolean | cdktf.IResolvable;
    set defaultRules(value: boolean | cdktf.IResolvable);
    resetDefaultRules(): void;
    get defaultRulesInput(): boolean | cdktf.IResolvable | undefined;
    private _digestsMaxDelay?;
    get digestsMaxDelay(): number;
    set digestsMaxDelay(value: number);
    resetDigestsMaxDelay(): void;
    get digestsMaxDelayInput(): number | undefined;
    private _digestsMinDelay?;
    get digestsMinDelay(): number;
    set digestsMinDelay(value: number);
    resetDigestsMinDelay(): void;
    get digestsMinDelayInput(): number | undefined;
    get features(): string[];
    private _filters;
    get filters(): ProjectFiltersOutputReference;
    putFilters(value: ProjectFilters): void;
    resetFilters(): void;
    get filtersInput(): cdktf.IResolvable | ProjectFilters | undefined;
    private _fingerprintingRules?;
    get fingerprintingRules(): string;
    set fingerprintingRules(value: string);
    resetFingerprintingRules(): void;
    get fingerprintingRulesInput(): string | undefined;
    private _groupingEnhancements?;
    get groupingEnhancements(): string;
    set groupingEnhancements(value: string);
    resetGroupingEnhancements(): void;
    get groupingEnhancementsInput(): string | undefined;
    private _highlightTags?;
    get highlightTags(): string[];
    set highlightTags(value: string[]);
    resetHighlightTags(): void;
    get highlightTagsInput(): string[] | undefined;
    get id(): string;
    get internalId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _platform?;
    get platform(): string;
    set platform(value: string);
    get platformInput(): string | undefined;
    private _resolveAge?;
    get resolveAge(): number;
    set resolveAge(value: number);
    resetResolveAge(): void;
    get resolveAgeInput(): number | undefined;
    private _slug?;
    get slug(): string;
    set slug(value: string);
    resetSlug(): void;
    get slugInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    get teamsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
