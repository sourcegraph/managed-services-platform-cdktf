import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntegrationPagerdutyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the PagerDuty integration. Source from the URL `https://<organization>.sentry.io/settings/integrations/pagerduty/<integration-id>/` or use the `sentry_organization_integration` data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_pagerduty#integration_id IntegrationPagerduty#integration_id}
    */
    readonly integrationId: string;
    /**
    * The integration key of the PagerDuty service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_pagerduty#integration_key IntegrationPagerduty#integration_key}
    */
    readonly integrationKey: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_pagerduty#organization IntegrationPagerduty#organization}
    */
    readonly organization: string;
    /**
    * The name of the PagerDuty service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_pagerduty#service IntegrationPagerduty#service}
    */
    readonly service: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_pagerduty sentry_integration_pagerduty}
*/
export declare class IntegrationPagerduty extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_integration_pagerduty";
    /**
    * Generates CDKTF code for importing a IntegrationPagerduty resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationPagerduty to import
    * @param importFromId The id of the existing IntegrationPagerduty that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_pagerduty#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationPagerduty to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_pagerduty sentry_integration_pagerduty} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationPagerdutyConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationPagerdutyConfig);
    get id(): string;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _integrationKey?;
    get integrationKey(): string;
    set integrationKey(value: string);
    get integrationKeyInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
