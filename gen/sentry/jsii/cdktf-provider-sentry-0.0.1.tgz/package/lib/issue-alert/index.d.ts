import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IssueAlertConfig extends cdktf.TerraformMetaArguments {
    /**
    * Trigger actions when an event is captured by Sentry and `any` or `all` of the specified conditions happen. Valid values are: `all`, and `any`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#action_match IssueAlert#action_match}
    */
    readonly actionMatch: string;
    /**
    * **Deprecated** in favor of `actions_v2`. A list of actions that take place when all required conditions and filters for the rule are met. In JSON string format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#actions IssueAlert#actions}
    */
    readonly actions?: string;
    /**
    * A list of actions that take place when all required conditions and filters for the rule are met.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#actions_v2 IssueAlert#actions_v2}
    */
    readonly actionsV2?: IssueAlertActionsV2[] | cdktf.IResolvable;
    /**
    * **Deprecated** in favor of `conditions_v2`. A list of triggers that determine when the rule fires. In JSON string format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#conditions IssueAlert#conditions}
    */
    readonly conditions?: string;
    /**
    * A list of triggers that determine when the rule fires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#conditions_v2 IssueAlert#conditions_v2}
    */
    readonly conditionsV2?: IssueAlertConditionsV2[] | cdktf.IResolvable;
    /**
    * Perform issue alert in a specific environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#environment IssueAlert#environment}
    */
    readonly environment?: string;
    /**
    * A string determining which filters need to be true before any actions take place. Required when a value is provided for `filters`. Valid values are: `all`, `any`, and `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#filter_match IssueAlert#filter_match}
    */
    readonly filterMatch?: string;
    /**
    * **Deprecated** in favor of `filters_v2`. A list of filters that determine if a rule fires after the necessary conditions have been met. In JSON string format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#filters IssueAlert#filters}
    */
    readonly filters?: string;
    /**
    * A list of filters that determine if a rule fires after the necessary conditions have been met.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#filters_v2 IssueAlert#filters_v2}
    */
    readonly filtersV2?: IssueAlertFiltersV2[] | cdktf.IResolvable;
    /**
    * Perform actions at most once every `X` minutes for this issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#frequency IssueAlert#frequency}
    */
    readonly frequency: number;
    /**
    * The issue alert name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#name IssueAlert#name}
    */
    readonly name: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#organization IssueAlert#organization}
    */
    readonly organization: string;
    /**
    * The ID of the team or user that owns the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#owner IssueAlert#owner}
    */
    readonly owner?: string;
    /**
    * The project of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#project IssueAlert#project}
    */
    readonly project: string;
}
export interface IssueAlertActionsV2AzureDevopsCreateTicket {
    /**
    * The integration ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#integration IssueAlert#integration}
    */
    readonly integration: string;
    /**
    * The ID of the Azure DevOps project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#project IssueAlert#project}
    */
    readonly project: string;
    /**
    * The type of work item to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#work_item_type IssueAlert#work_item_type}
    */
    readonly workItemType: string;
}
export declare function issueAlertActionsV2AzureDevopsCreateTicketToTerraform(struct?: IssueAlertActionsV2AzureDevopsCreateTicket | cdktf.IResolvable): any;
export declare function issueAlertActionsV2AzureDevopsCreateTicketToHclTerraform(struct?: IssueAlertActionsV2AzureDevopsCreateTicket | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2AzureDevopsCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2AzureDevopsCreateTicket | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2AzureDevopsCreateTicket | cdktf.IResolvable | undefined);
    private _integration?;
    get integration(): string;
    set integration(value: string);
    get integrationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _workItemType?;
    get workItemType(): string;
    set workItemType(value: string);
    get workItemTypeInput(): string | undefined;
}
export interface IssueAlertActionsV2DiscordNotifyService {
    /**
    * The ID of the channel to send the notification to. You must enter either a channel ID or a channel URL, not a channel name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#channel_id IssueAlert#channel_id}
    */
    readonly channelId: string;
    /**
    * The integration ID associated with the Discord server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#server IssueAlert#server}
    */
    readonly server: string;
    /**
    * A string of tags to show in the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#tags IssueAlert#tags}
    */
    readonly tags?: string[];
}
export declare function issueAlertActionsV2DiscordNotifyServiceToTerraform(struct?: IssueAlertActionsV2DiscordNotifyService | cdktf.IResolvable): any;
export declare function issueAlertActionsV2DiscordNotifyServiceToHclTerraform(struct?: IssueAlertActionsV2DiscordNotifyService | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2DiscordNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2DiscordNotifyService | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2DiscordNotifyService | cdktf.IResolvable | undefined);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    get channelIdInput(): string | undefined;
    get name(): string;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
}
export interface IssueAlertActionsV2GithubCreateTicket {
    /**
    * The GitHub user to assign the issue to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#assignee IssueAlert#assignee}
    */
    readonly assignee?: string;
    /**
    * The integration ID associated with GitHub.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#integration IssueAlert#integration}
    */
    readonly integration: string;
    /**
    * A list of labels to assign to the issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#labels IssueAlert#labels}
    */
    readonly labels?: string[];
    /**
    * The name of the repository to create the issue in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#repo IssueAlert#repo}
    */
    readonly repo: string;
}
export declare function issueAlertActionsV2GithubCreateTicketToTerraform(struct?: IssueAlertActionsV2GithubCreateTicket | cdktf.IResolvable): any;
export declare function issueAlertActionsV2GithubCreateTicketToHclTerraform(struct?: IssueAlertActionsV2GithubCreateTicket | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2GithubCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2GithubCreateTicket | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2GithubCreateTicket | cdktf.IResolvable | undefined);
    private _assignee?;
    get assignee(): string;
    set assignee(value: string);
    resetAssignee(): void;
    get assigneeInput(): string | undefined;
    private _integration?;
    get integration(): string;
    set integration(value: string);
    get integrationInput(): string | undefined;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    get name(): string;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    get repoInput(): string | undefined;
}
export interface IssueAlertActionsV2GithubEnterpriseCreateTicket {
    /**
    * The GitHub user to assign the issue to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#assignee IssueAlert#assignee}
    */
    readonly assignee?: string;
    /**
    * The integration ID associated with GitHub Enterprise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#integration IssueAlert#integration}
    */
    readonly integration: string;
    /**
    * A list of labels to assign to the issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#labels IssueAlert#labels}
    */
    readonly labels?: string[];
    /**
    * The name of the repository to create the issue in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#repo IssueAlert#repo}
    */
    readonly repo: string;
}
export declare function issueAlertActionsV2GithubEnterpriseCreateTicketToTerraform(struct?: IssueAlertActionsV2GithubEnterpriseCreateTicket | cdktf.IResolvable): any;
export declare function issueAlertActionsV2GithubEnterpriseCreateTicketToHclTerraform(struct?: IssueAlertActionsV2GithubEnterpriseCreateTicket | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2GithubEnterpriseCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2GithubEnterpriseCreateTicket | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2GithubEnterpriseCreateTicket | cdktf.IResolvable | undefined);
    private _assignee?;
    get assignee(): string;
    set assignee(value: string);
    resetAssignee(): void;
    get assigneeInput(): string | undefined;
    private _integration?;
    get integration(): string;
    set integration(value: string);
    get integrationInput(): string | undefined;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    get name(): string;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    get repoInput(): string | undefined;
}
export interface IssueAlertActionsV2JiraCreateTicket {
    /**
    * The integration ID associated with Jira.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#integration IssueAlert#integration}
    */
    readonly integration: string;
    /**
    * The ID of the type of issue that the ticket should be created as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#issue_type IssueAlert#issue_type}
    */
    readonly issueType: string;
    /**
    * The ID of the Jira project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#project IssueAlert#project}
    */
    readonly project: string;
}
export declare function issueAlertActionsV2JiraCreateTicketToTerraform(struct?: IssueAlertActionsV2JiraCreateTicket | cdktf.IResolvable): any;
export declare function issueAlertActionsV2JiraCreateTicketToHclTerraform(struct?: IssueAlertActionsV2JiraCreateTicket | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2JiraCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2JiraCreateTicket | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2JiraCreateTicket | cdktf.IResolvable | undefined);
    private _integration?;
    get integration(): string;
    set integration(value: string);
    get integrationInput(): string | undefined;
    private _issueType?;
    get issueType(): string;
    set issueType(value: string);
    get issueTypeInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
}
export interface IssueAlertActionsV2JiraServerCreateTicket {
    /**
    * The integration ID associated with Jira Server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#integration IssueAlert#integration}
    */
    readonly integration: string;
    /**
    * The ID of the type of issue that the ticket should be created as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#issue_type IssueAlert#issue_type}
    */
    readonly issueType: string;
    /**
    * The ID of the Jira Server project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#project IssueAlert#project}
    */
    readonly project: string;
}
export declare function issueAlertActionsV2JiraServerCreateTicketToTerraform(struct?: IssueAlertActionsV2JiraServerCreateTicket | cdktf.IResolvable): any;
export declare function issueAlertActionsV2JiraServerCreateTicketToHclTerraform(struct?: IssueAlertActionsV2JiraServerCreateTicket | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2JiraServerCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2JiraServerCreateTicket | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2JiraServerCreateTicket | cdktf.IResolvable | undefined);
    private _integration?;
    get integration(): string;
    set integration(value: string);
    get integrationInput(): string | undefined;
    private _issueType?;
    get issueType(): string;
    set issueType(value: string);
    get issueTypeInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
}
export interface IssueAlertActionsV2MsteamsNotifyService {
    /**
    * The name of the channel to send the notification to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#channel IssueAlert#channel}
    */
    readonly channel: string;
    /**
    * The integration ID associated with the Microsoft Teams team.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#team IssueAlert#team}
    */
    readonly team: string;
}
export declare function issueAlertActionsV2MsteamsNotifyServiceToTerraform(struct?: IssueAlertActionsV2MsteamsNotifyService | cdktf.IResolvable): any;
export declare function issueAlertActionsV2MsteamsNotifyServiceToHclTerraform(struct?: IssueAlertActionsV2MsteamsNotifyService | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2MsteamsNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2MsteamsNotifyService | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2MsteamsNotifyService | cdktf.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    get channelId(): string;
    get name(): string;
    private _team?;
    get team(): string;
    set team(value: string);
    get teamInput(): string | undefined;
}
export interface IssueAlertActionsV2NotifyEmail {
    /**
    * Who the notification should be sent to if there are no suggested assignees. Valid values are: `AllMembers`, `ActiveMembers`, and `NoOne`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#fallthrough_type IssueAlert#fallthrough_type}
    */
    readonly fallthroughType?: string;
    /**
    * The ID of the Member or Team the notification should be sent to. Only required when `target_type` is `Team` or `Member`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#target_identifier IssueAlert#target_identifier}
    */
    readonly targetIdentifier?: string;
    /**
    * Valid values are: `IssueOwners`, `Team`, and `Member`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#target_type IssueAlert#target_type}
    */
    readonly targetType: string;
}
export declare function issueAlertActionsV2NotifyEmailToTerraform(struct?: IssueAlertActionsV2NotifyEmail | cdktf.IResolvable): any;
export declare function issueAlertActionsV2NotifyEmailToHclTerraform(struct?: IssueAlertActionsV2NotifyEmail | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2NotifyEmailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2NotifyEmail | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2NotifyEmail | cdktf.IResolvable | undefined);
    private _fallthroughType?;
    get fallthroughType(): string;
    set fallthroughType(value: string);
    resetFallthroughType(): void;
    get fallthroughTypeInput(): string | undefined;
    get name(): string;
    private _targetIdentifier?;
    get targetIdentifier(): string;
    set targetIdentifier(value: string);
    resetTargetIdentifier(): void;
    get targetIdentifierInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
}
export interface IssueAlertActionsV2NotifyEvent {
}
export declare function issueAlertActionsV2NotifyEventToTerraform(struct?: IssueAlertActionsV2NotifyEvent | cdktf.IResolvable): any;
export declare function issueAlertActionsV2NotifyEventToHclTerraform(struct?: IssueAlertActionsV2NotifyEvent | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2NotifyEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2NotifyEvent | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2NotifyEvent | cdktf.IResolvable | undefined);
    get name(): string;
}
export interface IssueAlertActionsV2NotifyEventSentryApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#sentry_app_installation_uuid IssueAlert#sentry_app_installation_uuid}
    */
    readonly sentryAppInstallationUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#settings IssueAlert#settings}
    */
    readonly settings?: {
        [key: string]: string;
    };
    /**
    * Optional mapping of setting keys to human-readable display labels. This is primarily used for `async-select` fields in the Sentry UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#settings_labels IssueAlert#settings_labels}
    */
    readonly settingsLabels?: {
        [key: string]: string;
    };
}
export declare function issueAlertActionsV2NotifyEventSentryAppToTerraform(struct?: IssueAlertActionsV2NotifyEventSentryApp | cdktf.IResolvable): any;
export declare function issueAlertActionsV2NotifyEventSentryAppToHclTerraform(struct?: IssueAlertActionsV2NotifyEventSentryApp | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2NotifyEventSentryAppOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2NotifyEventSentryApp | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2NotifyEventSentryApp | cdktf.IResolvable | undefined);
    get name(): string;
    private _sentryAppInstallationUuid?;
    get sentryAppInstallationUuid(): string;
    set sentryAppInstallationUuid(value: string);
    get sentryAppInstallationUuidInput(): string | undefined;
    private _settings?;
    get settings(): {
        [key: string]: string;
    };
    set settings(value: {
        [key: string]: string;
    });
    resetSettings(): void;
    get settingsInput(): {
        [key: string]: string;
    } | undefined;
    private _settingsLabels?;
    get settingsLabels(): {
        [key: string]: string;
    };
    set settingsLabels(value: {
        [key: string]: string;
    });
    resetSettingsLabels(): void;
    get settingsLabelsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface IssueAlertActionsV2NotifyEventService {
    /**
    * The slug of the integration service. Sourced from `https://terraform-provider-sentry.sentry.io/settings/developer-settings/<service>/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#service IssueAlert#service}
    */
    readonly service: string;
}
export declare function issueAlertActionsV2NotifyEventServiceToTerraform(struct?: IssueAlertActionsV2NotifyEventService | cdktf.IResolvable): any;
export declare function issueAlertActionsV2NotifyEventServiceToHclTerraform(struct?: IssueAlertActionsV2NotifyEventService | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2NotifyEventServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2NotifyEventService | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2NotifyEventService | cdktf.IResolvable | undefined);
    get name(): string;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface IssueAlertActionsV2OpsgenieNotifyTeam {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#account IssueAlert#account}
    */
    readonly account: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#priority IssueAlert#priority}
    */
    readonly priority: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#team IssueAlert#team}
    */
    readonly team: string;
}
export declare function issueAlertActionsV2OpsgenieNotifyTeamToTerraform(struct?: IssueAlertActionsV2OpsgenieNotifyTeam | cdktf.IResolvable): any;
export declare function issueAlertActionsV2OpsgenieNotifyTeamToHclTerraform(struct?: IssueAlertActionsV2OpsgenieNotifyTeam | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2OpsgenieNotifyTeamOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2OpsgenieNotifyTeam | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2OpsgenieNotifyTeam | cdktf.IResolvable | undefined);
    private _account?;
    get account(): string;
    set account(value: string);
    get accountInput(): string | undefined;
    get name(): string;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    get priorityInput(): string | undefined;
    private _team?;
    get team(): string;
    set team(value: string);
    get teamInput(): string | undefined;
}
export interface IssueAlertActionsV2PagerdutyNotifyService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#account IssueAlert#account}
    */
    readonly account: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#service IssueAlert#service}
    */
    readonly service: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#severity IssueAlert#severity}
    */
    readonly severity: string;
}
export declare function issueAlertActionsV2PagerdutyNotifyServiceToTerraform(struct?: IssueAlertActionsV2PagerdutyNotifyService | cdktf.IResolvable): any;
export declare function issueAlertActionsV2PagerdutyNotifyServiceToHclTerraform(struct?: IssueAlertActionsV2PagerdutyNotifyService | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2PagerdutyNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2PagerdutyNotifyService | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2PagerdutyNotifyService | cdktf.IResolvable | undefined);
    private _account?;
    get account(): string;
    set account(value: string);
    get accountInput(): string | undefined;
    get name(): string;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    get severityInput(): string | undefined;
}
export interface IssueAlertActionsV2SlackNotifyService {
    /**
    * The name of the channel to send the notification to (e.g., #critical, Jane Schmidt).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#channel IssueAlert#channel}
    */
    readonly channel: string;
    /**
    * The ID of the channel to send the notification to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#channel_id IssueAlert#channel_id}
    */
    readonly channelId?: string;
    /**
    * Text to show alongside the notification. To @ a user, include their user id like `@<USER_ID>`. To include a clickable link, format the link and title like `<http://example.com|Click Here>`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#notes IssueAlert#notes}
    */
    readonly notes?: string;
    /**
    * A string of tags to show in the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#tags IssueAlert#tags}
    */
    readonly tags?: string[];
    /**
    * The integration ID associated with the Slack workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#workspace IssueAlert#workspace}
    */
    readonly workspace: string;
}
export declare function issueAlertActionsV2SlackNotifyServiceToTerraform(struct?: IssueAlertActionsV2SlackNotifyService | cdktf.IResolvable): any;
export declare function issueAlertActionsV2SlackNotifyServiceToHclTerraform(struct?: IssueAlertActionsV2SlackNotifyService | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2SlackNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertActionsV2SlackNotifyService | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2SlackNotifyService | cdktf.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    resetChannelId(): void;
    get channelIdInput(): string | undefined;
    get name(): string;
    private _notes?;
    get notes(): string;
    set notes(value: string);
    resetNotes(): void;
    get notesInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
}
export interface IssueAlertActionsV2 {
    /**
    * Create an Azure DevOps work item in `integration`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#azure_devops_create_ticket IssueAlert#azure_devops_create_ticket}
    */
    readonly azureDevopsCreateTicket?: IssueAlertActionsV2AzureDevopsCreateTicket;
    /**
    * Send a notification to the `server` Discord server in the channel with ID or URL: `channel_id` and show tags `tags` in the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#discord_notify_service IssueAlert#discord_notify_service}
    */
    readonly discordNotifyService?: IssueAlertActionsV2DiscordNotifyService;
    /**
    * Create a GitHub issue in `integration`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#github_create_ticket IssueAlert#github_create_ticket}
    */
    readonly githubCreateTicket?: IssueAlertActionsV2GithubCreateTicket;
    /**
    * Create a GitHub Enterprise issue in `integration`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#github_enterprise_create_ticket IssueAlert#github_enterprise_create_ticket}
    */
    readonly githubEnterpriseCreateTicket?: IssueAlertActionsV2GithubEnterpriseCreateTicket;
    /**
    * Create a Jira issue in `integration`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#jira_create_ticket IssueAlert#jira_create_ticket}
    */
    readonly jiraCreateTicket?: IssueAlertActionsV2JiraCreateTicket;
    /**
    * Create a Jira Server issue in `integration`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#jira_server_create_ticket IssueAlert#jira_server_create_ticket}
    */
    readonly jiraServerCreateTicket?: IssueAlertActionsV2JiraServerCreateTicket;
    /**
    * Send a notification to the `team` Team to `channel`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#msteams_notify_service IssueAlert#msteams_notify_service}
    */
    readonly msteamsNotifyService?: IssueAlertActionsV2MsteamsNotifyService;
    /**
    * Send a notification to `target_type` and if none can be found then send a notification to `fallthrough_type`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#notify_email IssueAlert#notify_email}
    */
    readonly notifyEmail?: IssueAlertActionsV2NotifyEmail;
    /**
    * Send a notification to all legacy integrations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#notify_event IssueAlert#notify_event}
    */
    readonly notifyEvent?: IssueAlertActionsV2NotifyEvent;
    /**
    * Send a notification to a Sentry app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#notify_event_sentry_app IssueAlert#notify_event_sentry_app}
    */
    readonly notifyEventSentryApp?: IssueAlertActionsV2NotifyEventSentryApp;
    /**
    * Send a notification via an integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#notify_event_service IssueAlert#notify_event_service}
    */
    readonly notifyEventService?: IssueAlertActionsV2NotifyEventService;
    /**
    * Send a notification to Opsgenie account `account` and team `team` with `priority` priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#opsgenie_notify_team IssueAlert#opsgenie_notify_team}
    */
    readonly opsgenieNotifyTeam?: IssueAlertActionsV2OpsgenieNotifyTeam;
    /**
    * Send a notification to PagerDuty account `account` and service `service` with `severity` severity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#pagerduty_notify_service IssueAlert#pagerduty_notify_service}
    */
    readonly pagerdutyNotifyService?: IssueAlertActionsV2PagerdutyNotifyService;
    /**
    * Send a notification to the `workspace` Slack workspace to `channel` (optionally, an ID: `channel_id`) and show tags `tags` and notes `notes` in notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#slack_notify_service IssueAlert#slack_notify_service}
    */
    readonly slackNotifyService?: IssueAlertActionsV2SlackNotifyService;
}
export declare function issueAlertActionsV2ToTerraform(struct?: IssueAlertActionsV2 | cdktf.IResolvable): any;
export declare function issueAlertActionsV2ToHclTerraform(struct?: IssueAlertActionsV2 | cdktf.IResolvable): any;
export declare class IssueAlertActionsV2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IssueAlertActionsV2 | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertActionsV2 | cdktf.IResolvable | undefined);
    private _azureDevopsCreateTicket;
    get azureDevopsCreateTicket(): IssueAlertActionsV2AzureDevopsCreateTicketOutputReference;
    putAzureDevopsCreateTicket(value: IssueAlertActionsV2AzureDevopsCreateTicket): void;
    resetAzureDevopsCreateTicket(): void;
    get azureDevopsCreateTicketInput(): cdktf.IResolvable | IssueAlertActionsV2AzureDevopsCreateTicket | undefined;
    private _discordNotifyService;
    get discordNotifyService(): IssueAlertActionsV2DiscordNotifyServiceOutputReference;
    putDiscordNotifyService(value: IssueAlertActionsV2DiscordNotifyService): void;
    resetDiscordNotifyService(): void;
    get discordNotifyServiceInput(): cdktf.IResolvable | IssueAlertActionsV2DiscordNotifyService | undefined;
    private _githubCreateTicket;
    get githubCreateTicket(): IssueAlertActionsV2GithubCreateTicketOutputReference;
    putGithubCreateTicket(value: IssueAlertActionsV2GithubCreateTicket): void;
    resetGithubCreateTicket(): void;
    get githubCreateTicketInput(): cdktf.IResolvable | IssueAlertActionsV2GithubCreateTicket | undefined;
    private _githubEnterpriseCreateTicket;
    get githubEnterpriseCreateTicket(): IssueAlertActionsV2GithubEnterpriseCreateTicketOutputReference;
    putGithubEnterpriseCreateTicket(value: IssueAlertActionsV2GithubEnterpriseCreateTicket): void;
    resetGithubEnterpriseCreateTicket(): void;
    get githubEnterpriseCreateTicketInput(): cdktf.IResolvable | IssueAlertActionsV2GithubEnterpriseCreateTicket | undefined;
    private _jiraCreateTicket;
    get jiraCreateTicket(): IssueAlertActionsV2JiraCreateTicketOutputReference;
    putJiraCreateTicket(value: IssueAlertActionsV2JiraCreateTicket): void;
    resetJiraCreateTicket(): void;
    get jiraCreateTicketInput(): cdktf.IResolvable | IssueAlertActionsV2JiraCreateTicket | undefined;
    private _jiraServerCreateTicket;
    get jiraServerCreateTicket(): IssueAlertActionsV2JiraServerCreateTicketOutputReference;
    putJiraServerCreateTicket(value: IssueAlertActionsV2JiraServerCreateTicket): void;
    resetJiraServerCreateTicket(): void;
    get jiraServerCreateTicketInput(): cdktf.IResolvable | IssueAlertActionsV2JiraServerCreateTicket | undefined;
    private _msteamsNotifyService;
    get msteamsNotifyService(): IssueAlertActionsV2MsteamsNotifyServiceOutputReference;
    putMsteamsNotifyService(value: IssueAlertActionsV2MsteamsNotifyService): void;
    resetMsteamsNotifyService(): void;
    get msteamsNotifyServiceInput(): cdktf.IResolvable | IssueAlertActionsV2MsteamsNotifyService | undefined;
    private _notifyEmail;
    get notifyEmail(): IssueAlertActionsV2NotifyEmailOutputReference;
    putNotifyEmail(value: IssueAlertActionsV2NotifyEmail): void;
    resetNotifyEmail(): void;
    get notifyEmailInput(): cdktf.IResolvable | IssueAlertActionsV2NotifyEmail | undefined;
    private _notifyEvent;
    get notifyEvent(): IssueAlertActionsV2NotifyEventOutputReference;
    putNotifyEvent(value: IssueAlertActionsV2NotifyEvent): void;
    resetNotifyEvent(): void;
    get notifyEventInput(): cdktf.IResolvable | IssueAlertActionsV2NotifyEvent | undefined;
    private _notifyEventSentryApp;
    get notifyEventSentryApp(): IssueAlertActionsV2NotifyEventSentryAppOutputReference;
    putNotifyEventSentryApp(value: IssueAlertActionsV2NotifyEventSentryApp): void;
    resetNotifyEventSentryApp(): void;
    get notifyEventSentryAppInput(): cdktf.IResolvable | IssueAlertActionsV2NotifyEventSentryApp | undefined;
    private _notifyEventService;
    get notifyEventService(): IssueAlertActionsV2NotifyEventServiceOutputReference;
    putNotifyEventService(value: IssueAlertActionsV2NotifyEventService): void;
    resetNotifyEventService(): void;
    get notifyEventServiceInput(): cdktf.IResolvable | IssueAlertActionsV2NotifyEventService | undefined;
    private _opsgenieNotifyTeam;
    get opsgenieNotifyTeam(): IssueAlertActionsV2OpsgenieNotifyTeamOutputReference;
    putOpsgenieNotifyTeam(value: IssueAlertActionsV2OpsgenieNotifyTeam): void;
    resetOpsgenieNotifyTeam(): void;
    get opsgenieNotifyTeamInput(): cdktf.IResolvable | IssueAlertActionsV2OpsgenieNotifyTeam | undefined;
    private _pagerdutyNotifyService;
    get pagerdutyNotifyService(): IssueAlertActionsV2PagerdutyNotifyServiceOutputReference;
    putPagerdutyNotifyService(value: IssueAlertActionsV2PagerdutyNotifyService): void;
    resetPagerdutyNotifyService(): void;
    get pagerdutyNotifyServiceInput(): cdktf.IResolvable | IssueAlertActionsV2PagerdutyNotifyService | undefined;
    private _slackNotifyService;
    get slackNotifyService(): IssueAlertActionsV2SlackNotifyServiceOutputReference;
    putSlackNotifyService(value: IssueAlertActionsV2SlackNotifyService): void;
    resetSlackNotifyService(): void;
    get slackNotifyServiceInput(): cdktf.IResolvable | IssueAlertActionsV2SlackNotifyService | undefined;
}
export declare class IssueAlertActionsV2List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: IssueAlertActionsV2[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IssueAlertActionsV2OutputReference;
}
export interface IssueAlertConditionsV2EventFrequency {
    /**
    * `m` for minutes, `h` for hours, `d` for days, and `w` for weeks. Valid values are: `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#comparison_interval IssueAlert#comparison_interval}
    */
    readonly comparisonInterval?: string;
    /**
    * Valid values are: `count`, and `percent`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#comparison_type IssueAlert#comparison_type}
    */
    readonly comparisonType: string;
    /**
    * `m` for minutes, `h` for hours, `d` for days, and `w` for weeks. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#interval IssueAlert#interval}
    */
    readonly interval?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value: number;
}
export declare function issueAlertConditionsV2EventFrequencyToTerraform(struct?: IssueAlertConditionsV2EventFrequency | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2EventFrequencyToHclTerraform(struct?: IssueAlertConditionsV2EventFrequency | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2EventFrequencyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2EventFrequency | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2EventFrequency | cdktf.IResolvable | undefined);
    private _comparisonInterval?;
    get comparisonInterval(): string;
    set comparisonInterval(value: string);
    resetComparisonInterval(): void;
    get comparisonIntervalInput(): string | undefined;
    private _comparisonType?;
    get comparisonType(): string;
    set comparisonType(value: string);
    get comparisonTypeInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    get name(): string;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface IssueAlertConditionsV2EventFrequencyPercent {
    /**
    * `m` for minutes, `h` for hours, `d` for days, and `w` for weeks. Valid values are: `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#comparison_interval IssueAlert#comparison_interval}
    */
    readonly comparisonInterval?: string;
    /**
    * Valid values are: `count`, and `percent`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#comparison_type IssueAlert#comparison_type}
    */
    readonly comparisonType: string;
    /**
    * `m` for minutes, `h` for hours. Valid values are: `5m`, `10m`, `30m`, and `1h`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#interval IssueAlert#interval}
    */
    readonly interval: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value: number;
}
export declare function issueAlertConditionsV2EventFrequencyPercentToTerraform(struct?: IssueAlertConditionsV2EventFrequencyPercent | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2EventFrequencyPercentToHclTerraform(struct?: IssueAlertConditionsV2EventFrequencyPercent | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2EventFrequencyPercentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2EventFrequencyPercent | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2EventFrequencyPercent | cdktf.IResolvable | undefined);
    private _comparisonInterval?;
    get comparisonInterval(): string;
    set comparisonInterval(value: string);
    resetComparisonInterval(): void;
    get comparisonIntervalInput(): string | undefined;
    private _comparisonType?;
    get comparisonType(): string;
    set comparisonType(value: string);
    get comparisonTypeInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    get name(): string;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface IssueAlertConditionsV2EventUniqueUserFrequency {
    /**
    * `m` for minutes, `h` for hours, `d` for days, and `w` for weeks. Valid values are: `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#comparison_interval IssueAlert#comparison_interval}
    */
    readonly comparisonInterval?: string;
    /**
    * Valid values are: `count`, and `percent`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#comparison_type IssueAlert#comparison_type}
    */
    readonly comparisonType: string;
    /**
    * `m` for minutes, `h` for hours, `d` for days, and `w` for weeks. Valid values are: `1m`, `5m`, `15m`, `1h`, `1d`, `1w`, and `30d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#interval IssueAlert#interval}
    */
    readonly interval?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value: number;
}
export declare function issueAlertConditionsV2EventUniqueUserFrequencyToTerraform(struct?: IssueAlertConditionsV2EventUniqueUserFrequency | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2EventUniqueUserFrequencyToHclTerraform(struct?: IssueAlertConditionsV2EventUniqueUserFrequency | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2EventUniqueUserFrequencyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2EventUniqueUserFrequency | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2EventUniqueUserFrequency | cdktf.IResolvable | undefined);
    private _comparisonInterval?;
    get comparisonInterval(): string;
    set comparisonInterval(value: string);
    resetComparisonInterval(): void;
    get comparisonIntervalInput(): string | undefined;
    private _comparisonType?;
    get comparisonType(): string;
    set comparisonType(value: string);
    get comparisonTypeInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    get name(): string;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface IssueAlertConditionsV2ExistingHighPriorityIssue {
}
export declare function issueAlertConditionsV2ExistingHighPriorityIssueToTerraform(struct?: IssueAlertConditionsV2ExistingHighPriorityIssue | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2ExistingHighPriorityIssueToHclTerraform(struct?: IssueAlertConditionsV2ExistingHighPriorityIssue | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2ExistingHighPriorityIssueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2ExistingHighPriorityIssue | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2ExistingHighPriorityIssue | cdktf.IResolvable | undefined);
    get name(): string;
}
export interface IssueAlertConditionsV2FirstSeenEvent {
}
export declare function issueAlertConditionsV2FirstSeenEventToTerraform(struct?: IssueAlertConditionsV2FirstSeenEvent | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2FirstSeenEventToHclTerraform(struct?: IssueAlertConditionsV2FirstSeenEvent | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2FirstSeenEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2FirstSeenEvent | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2FirstSeenEvent | cdktf.IResolvable | undefined);
    get name(): string;
}
export interface IssueAlertConditionsV2NewHighPriorityIssue {
}
export declare function issueAlertConditionsV2NewHighPriorityIssueToTerraform(struct?: IssueAlertConditionsV2NewHighPriorityIssue | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2NewHighPriorityIssueToHclTerraform(struct?: IssueAlertConditionsV2NewHighPriorityIssue | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2NewHighPriorityIssueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2NewHighPriorityIssue | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2NewHighPriorityIssue | cdktf.IResolvable | undefined);
    get name(): string;
}
export interface IssueAlertConditionsV2ReappearedEvent {
}
export declare function issueAlertConditionsV2ReappearedEventToTerraform(struct?: IssueAlertConditionsV2ReappearedEvent | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2ReappearedEventToHclTerraform(struct?: IssueAlertConditionsV2ReappearedEvent | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2ReappearedEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2ReappearedEvent | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2ReappearedEvent | cdktf.IResolvable | undefined);
    get name(): string;
}
export interface IssueAlertConditionsV2RegressionEvent {
}
export declare function issueAlertConditionsV2RegressionEventToTerraform(struct?: IssueAlertConditionsV2RegressionEvent | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2RegressionEventToHclTerraform(struct?: IssueAlertConditionsV2RegressionEvent | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2RegressionEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertConditionsV2RegressionEvent | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2RegressionEvent | cdktf.IResolvable | undefined);
    get name(): string;
}
export interface IssueAlertConditionsV2 {
    /**
    * When the `comparison_type` is `count`, the number of events in an issue is more than `value` in `interval`. When the `comparison_type` is `percent`, the number of events in an issue is `value` % higher in `interval` compared to `comparison_interval` ago.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#event_frequency IssueAlert#event_frequency}
    */
    readonly eventFrequency?: IssueAlertConditionsV2EventFrequency;
    /**
    * When the `comparison_type` is `count`, the percent of sessions affected by an issue is more than `value` in `interval`. When the `comparison_type` is `percent`, the percent of sessions affected by an issue is `value` % higher in `interval` compared to `comparison_interval` ago.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#event_frequency_percent IssueAlert#event_frequency_percent}
    */
    readonly eventFrequencyPercent?: IssueAlertConditionsV2EventFrequencyPercent;
    /**
    * When the `comparison_type` is `count`, the number of users affected by an issue is more than `value` in `interval`. When the `comparison_type` is `percent`, the number of users affected by an issue is `value` % higher in `interval` compared to `comparison_interval` ago.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#event_unique_user_frequency IssueAlert#event_unique_user_frequency}
    */
    readonly eventUniqueUserFrequency?: IssueAlertConditionsV2EventUniqueUserFrequency;
    /**
    * Sentry marks an existing issue as high priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#existing_high_priority_issue IssueAlert#existing_high_priority_issue}
    */
    readonly existingHighPriorityIssue?: IssueAlertConditionsV2ExistingHighPriorityIssue;
    /**
    * A new issue is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#first_seen_event IssueAlert#first_seen_event}
    */
    readonly firstSeenEvent?: IssueAlertConditionsV2FirstSeenEvent;
    /**
    * Sentry marks a new issue as high priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#new_high_priority_issue IssueAlert#new_high_priority_issue}
    */
    readonly newHighPriorityIssue?: IssueAlertConditionsV2NewHighPriorityIssue;
    /**
    * The issue changes state from ignored to unresolved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#reappeared_event IssueAlert#reappeared_event}
    */
    readonly reappearedEvent?: IssueAlertConditionsV2ReappearedEvent;
    /**
    * The issue changes state from resolved to unresolved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#regression_event IssueAlert#regression_event}
    */
    readonly regressionEvent?: IssueAlertConditionsV2RegressionEvent;
}
export declare function issueAlertConditionsV2ToTerraform(struct?: IssueAlertConditionsV2 | cdktf.IResolvable): any;
export declare function issueAlertConditionsV2ToHclTerraform(struct?: IssueAlertConditionsV2 | cdktf.IResolvable): any;
export declare class IssueAlertConditionsV2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IssueAlertConditionsV2 | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertConditionsV2 | cdktf.IResolvable | undefined);
    private _eventFrequency;
    get eventFrequency(): IssueAlertConditionsV2EventFrequencyOutputReference;
    putEventFrequency(value: IssueAlertConditionsV2EventFrequency): void;
    resetEventFrequency(): void;
    get eventFrequencyInput(): cdktf.IResolvable | IssueAlertConditionsV2EventFrequency | undefined;
    private _eventFrequencyPercent;
    get eventFrequencyPercent(): IssueAlertConditionsV2EventFrequencyPercentOutputReference;
    putEventFrequencyPercent(value: IssueAlertConditionsV2EventFrequencyPercent): void;
    resetEventFrequencyPercent(): void;
    get eventFrequencyPercentInput(): cdktf.IResolvable | IssueAlertConditionsV2EventFrequencyPercent | undefined;
    private _eventUniqueUserFrequency;
    get eventUniqueUserFrequency(): IssueAlertConditionsV2EventUniqueUserFrequencyOutputReference;
    putEventUniqueUserFrequency(value: IssueAlertConditionsV2EventUniqueUserFrequency): void;
    resetEventUniqueUserFrequency(): void;
    get eventUniqueUserFrequencyInput(): cdktf.IResolvable | IssueAlertConditionsV2EventUniqueUserFrequency | undefined;
    private _existingHighPriorityIssue;
    get existingHighPriorityIssue(): IssueAlertConditionsV2ExistingHighPriorityIssueOutputReference;
    putExistingHighPriorityIssue(value: IssueAlertConditionsV2ExistingHighPriorityIssue): void;
    resetExistingHighPriorityIssue(): void;
    get existingHighPriorityIssueInput(): cdktf.IResolvable | IssueAlertConditionsV2ExistingHighPriorityIssue | undefined;
    private _firstSeenEvent;
    get firstSeenEvent(): IssueAlertConditionsV2FirstSeenEventOutputReference;
    putFirstSeenEvent(value: IssueAlertConditionsV2FirstSeenEvent): void;
    resetFirstSeenEvent(): void;
    get firstSeenEventInput(): cdktf.IResolvable | IssueAlertConditionsV2FirstSeenEvent | undefined;
    private _newHighPriorityIssue;
    get newHighPriorityIssue(): IssueAlertConditionsV2NewHighPriorityIssueOutputReference;
    putNewHighPriorityIssue(value: IssueAlertConditionsV2NewHighPriorityIssue): void;
    resetNewHighPriorityIssue(): void;
    get newHighPriorityIssueInput(): cdktf.IResolvable | IssueAlertConditionsV2NewHighPriorityIssue | undefined;
    private _reappearedEvent;
    get reappearedEvent(): IssueAlertConditionsV2ReappearedEventOutputReference;
    putReappearedEvent(value: IssueAlertConditionsV2ReappearedEvent): void;
    resetReappearedEvent(): void;
    get reappearedEventInput(): cdktf.IResolvable | IssueAlertConditionsV2ReappearedEvent | undefined;
    private _regressionEvent;
    get regressionEvent(): IssueAlertConditionsV2RegressionEventOutputReference;
    putRegressionEvent(value: IssueAlertConditionsV2RegressionEvent): void;
    resetRegressionEvent(): void;
    get regressionEventInput(): cdktf.IResolvable | IssueAlertConditionsV2RegressionEvent | undefined;
}
export declare class IssueAlertConditionsV2List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: IssueAlertConditionsV2[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IssueAlertConditionsV2OutputReference;
}
export interface IssueAlertFiltersV2AgeComparison {
    /**
    * Valid values are: `older`, and `newer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#comparison_type IssueAlert#comparison_type}
    */
    readonly comparisonType: string;
    /**
    * Valid values are: `minute`, `hour`, `day`, and `week`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#time IssueAlert#time}
    */
    readonly time: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value: number;
}
export declare function issueAlertFiltersV2AgeComparisonToTerraform(struct?: IssueAlertFiltersV2AgeComparison | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2AgeComparisonToHclTerraform(struct?: IssueAlertFiltersV2AgeComparison | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2AgeComparisonOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2AgeComparison | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2AgeComparison | cdktf.IResolvable | undefined);
    private _comparisonType?;
    get comparisonType(): string;
    set comparisonType(value: string);
    get comparisonTypeInput(): string | undefined;
    get name(): string;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface IssueAlertFiltersV2AssignedTo {
    /**
    * The target's ID. Only required when `target_type` is `Team` or `Member`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#target_identifier IssueAlert#target_identifier}
    */
    readonly targetIdentifier?: string;
    /**
    * Valid values are: `Unassigned`, `Team`, and `Member`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#target_type IssueAlert#target_type}
    */
    readonly targetType: string;
}
export declare function issueAlertFiltersV2AssignedToToTerraform(struct?: IssueAlertFiltersV2AssignedTo | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2AssignedToToHclTerraform(struct?: IssueAlertFiltersV2AssignedTo | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2AssignedToOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2AssignedTo | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2AssignedTo | cdktf.IResolvable | undefined);
    get name(): string;
    private _targetIdentifier?;
    get targetIdentifier(): string;
    set targetIdentifier(value: string);
    resetTargetIdentifier(): void;
    get targetIdentifierInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
}
export interface IssueAlertFiltersV2EventAttribute {
    /**
    * Valid values are: `message`, `platform`, `environment`, `type`, `error.handled`, `error.unhandled`, `error.main_thread`, `exception.type`, `exception.value`, `user.id`, `user.email`, `user.username`, `user.ip_address`, `http.method`, `http.url`, `http.status_code`, `sdk.name`, `stacktrace.code`, `stacktrace.module`, `stacktrace.filename`, `stacktrace.abs_path`, `stacktrace.package`, `unreal.crash_type`, `app.in_foreground`, `os.distribution_name`, `os.distribution_version`, `symbolicated_in_app`, `ota_updates.channel`, `ota_updates.runtime_version`, and `ota_updates.update_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#attribute IssueAlert#attribute}
    */
    readonly attribute: string;
    /**
    * The comparison operator. Valid values are: `CONTAINS`, `ENDS_WITH`, `EQUAL`, `GREATER_OR_EQUAL`, `GREATER`, `IS_SET`, `IS_IN`, `LESS_OR_EQUAL`, `LESS`, `NOT_CONTAINS`, `NOT_ENDS_WITH`, `NOT_EQUAL`, `NOT_SET`, `NOT_STARTS_WITH`, `NOT_IN`, and `STARTS_WITH`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#match IssueAlert#match}
    */
    readonly match: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value?: string;
}
export declare function issueAlertFiltersV2EventAttributeToTerraform(struct?: IssueAlertFiltersV2EventAttribute | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2EventAttributeToHclTerraform(struct?: IssueAlertFiltersV2EventAttribute | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2EventAttributeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2EventAttribute | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2EventAttribute | cdktf.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    get attributeInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
    get name(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface IssueAlertFiltersV2IssueCategory {
    /**
    * Valid values are: `Error`, `Performance`, `Profile`, `Cron`, `Replay`, `Feedback`, `Uptime`, `Metric_Alert`, `Test_Notification`, `Outage`, `Metric`, `Db_Query`, `Http_Client`, `Frontend`, `Mobile`, `Ai_Detected`, `Preprod`, and `Configuration`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value: string;
}
export declare function issueAlertFiltersV2IssueCategoryToTerraform(struct?: IssueAlertFiltersV2IssueCategory | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2IssueCategoryToHclTerraform(struct?: IssueAlertFiltersV2IssueCategory | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2IssueCategoryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2IssueCategory | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2IssueCategory | cdktf.IResolvable | undefined);
    get name(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface IssueAlertFiltersV2IssueOccurrences {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value: number;
}
export declare function issueAlertFiltersV2IssueOccurrencesToTerraform(struct?: IssueAlertFiltersV2IssueOccurrences | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2IssueOccurrencesToHclTerraform(struct?: IssueAlertFiltersV2IssueOccurrences | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2IssueOccurrencesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2IssueOccurrences | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2IssueOccurrences | cdktf.IResolvable | undefined);
    get name(): string;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface IssueAlertFiltersV2LatestAdoptedRelease {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#environment IssueAlert#environment}
    */
    readonly environment: string;
    /**
    * Valid values are: `older`, and `newer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#older_or_newer IssueAlert#older_or_newer}
    */
    readonly olderOrNewer: string;
    /**
    * Valid values are: `oldest`, and `newest`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#oldest_or_newest IssueAlert#oldest_or_newest}
    */
    readonly oldestOrNewest: string;
}
export declare function issueAlertFiltersV2LatestAdoptedReleaseToTerraform(struct?: IssueAlertFiltersV2LatestAdoptedRelease | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2LatestAdoptedReleaseToHclTerraform(struct?: IssueAlertFiltersV2LatestAdoptedRelease | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2LatestAdoptedReleaseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2LatestAdoptedRelease | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2LatestAdoptedRelease | cdktf.IResolvable | undefined);
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    get name(): string;
    private _olderOrNewer?;
    get olderOrNewer(): string;
    set olderOrNewer(value: string);
    get olderOrNewerInput(): string | undefined;
    private _oldestOrNewest?;
    get oldestOrNewest(): string;
    set oldestOrNewest(value: string);
    get oldestOrNewestInput(): string | undefined;
}
export interface IssueAlertFiltersV2LatestRelease {
}
export declare function issueAlertFiltersV2LatestReleaseToTerraform(struct?: IssueAlertFiltersV2LatestRelease | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2LatestReleaseToHclTerraform(struct?: IssueAlertFiltersV2LatestRelease | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2LatestReleaseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2LatestRelease | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2LatestRelease | cdktf.IResolvable | undefined);
    get name(): string;
}
export interface IssueAlertFiltersV2Level {
    /**
    * Valid values are: `sample`, `debug`, `info`, `warning`, `error`, and `fatal`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#level IssueAlert#level}
    */
    readonly level: string;
    /**
    * The comparison operator. Valid values are: `EQUAL`, `GREATER_OR_EQUAL`, and `LESS_OR_EQUAL`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#match IssueAlert#match}
    */
    readonly match: string;
}
export declare function issueAlertFiltersV2LevelToTerraform(struct?: IssueAlertFiltersV2Level | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2LevelToHclTerraform(struct?: IssueAlertFiltersV2Level | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2LevelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2Level | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2Level | cdktf.IResolvable | undefined);
    private _level?;
    get level(): string;
    set level(value: string);
    get levelInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
    get name(): string;
}
export interface IssueAlertFiltersV2TaggedEvent {
    /**
    * The tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#key IssueAlert#key}
    */
    readonly key: string;
    /**
    * The comparison operator. Valid values are: `CONTAINS`, `ENDS_WITH`, `EQUAL`, `GREATER_OR_EQUAL`, `GREATER`, `IS_SET`, `IS_IN`, `LESS_OR_EQUAL`, `LESS`, `NOT_CONTAINS`, `NOT_ENDS_WITH`, `NOT_EQUAL`, `NOT_SET`, `NOT_STARTS_WITH`, `NOT_IN`, and `STARTS_WITH`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#match IssueAlert#match}
    */
    readonly match: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#value IssueAlert#value}
    */
    readonly value?: string;
}
export declare function issueAlertFiltersV2TaggedEventToTerraform(struct?: IssueAlertFiltersV2TaggedEvent | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2TaggedEventToHclTerraform(struct?: IssueAlertFiltersV2TaggedEvent | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2TaggedEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IssueAlertFiltersV2TaggedEvent | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2TaggedEvent | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
    get name(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface IssueAlertFiltersV2 {
    /**
    * The issue is older or newer than `value` `time`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#age_comparison IssueAlert#age_comparison}
    */
    readonly ageComparison?: IssueAlertFiltersV2AgeComparison;
    /**
    * The issue is assigned to no one, team, or member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#assigned_to IssueAlert#assigned_to}
    */
    readonly assignedTo?: IssueAlertFiltersV2AssignedTo;
    /**
    * The event's `attribute` value `match` `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#event_attribute IssueAlert#event_attribute}
    */
    readonly eventAttribute?: IssueAlertFiltersV2EventAttribute;
    /**
    * The issue's category is equal to `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#issue_category IssueAlert#issue_category}
    */
    readonly issueCategory?: IssueAlertFiltersV2IssueCategory;
    /**
    * The issue has happened at least `value` times (Note: this is approximate).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#issue_occurrences IssueAlert#issue_occurrences}
    */
    readonly issueOccurrences?: IssueAlertFiltersV2IssueOccurrences;
    /**
    * The {oldest_or_newest} adopted release associated with the event's issue is {older_or_newer} than the latest adopted release in {environment}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#latest_adopted_release IssueAlert#latest_adopted_release}
    */
    readonly latestAdoptedRelease?: IssueAlertFiltersV2LatestAdoptedRelease;
    /**
    * The event is from the latest release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#latest_release IssueAlert#latest_release}
    */
    readonly latestRelease?: IssueAlertFiltersV2LatestRelease;
    /**
    * The event's level is `match` `level`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#level IssueAlert#level}
    */
    readonly level?: IssueAlertFiltersV2Level;
    /**
    * The event's tags match `key` `match` `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#tagged_event IssueAlert#tagged_event}
    */
    readonly taggedEvent?: IssueAlertFiltersV2TaggedEvent;
}
export declare function issueAlertFiltersV2ToTerraform(struct?: IssueAlertFiltersV2 | cdktf.IResolvable): any;
export declare function issueAlertFiltersV2ToHclTerraform(struct?: IssueAlertFiltersV2 | cdktf.IResolvable): any;
export declare class IssueAlertFiltersV2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IssueAlertFiltersV2 | cdktf.IResolvable | undefined;
    set internalValue(value: IssueAlertFiltersV2 | cdktf.IResolvable | undefined);
    private _ageComparison;
    get ageComparison(): IssueAlertFiltersV2AgeComparisonOutputReference;
    putAgeComparison(value: IssueAlertFiltersV2AgeComparison): void;
    resetAgeComparison(): void;
    get ageComparisonInput(): cdktf.IResolvable | IssueAlertFiltersV2AgeComparison | undefined;
    private _assignedTo;
    get assignedTo(): IssueAlertFiltersV2AssignedToOutputReference;
    putAssignedTo(value: IssueAlertFiltersV2AssignedTo): void;
    resetAssignedTo(): void;
    get assignedToInput(): cdktf.IResolvable | IssueAlertFiltersV2AssignedTo | undefined;
    private _eventAttribute;
    get eventAttribute(): IssueAlertFiltersV2EventAttributeOutputReference;
    putEventAttribute(value: IssueAlertFiltersV2EventAttribute): void;
    resetEventAttribute(): void;
    get eventAttributeInput(): cdktf.IResolvable | IssueAlertFiltersV2EventAttribute | undefined;
    private _issueCategory;
    get issueCategory(): IssueAlertFiltersV2IssueCategoryOutputReference;
    putIssueCategory(value: IssueAlertFiltersV2IssueCategory): void;
    resetIssueCategory(): void;
    get issueCategoryInput(): cdktf.IResolvable | IssueAlertFiltersV2IssueCategory | undefined;
    private _issueOccurrences;
    get issueOccurrences(): IssueAlertFiltersV2IssueOccurrencesOutputReference;
    putIssueOccurrences(value: IssueAlertFiltersV2IssueOccurrences): void;
    resetIssueOccurrences(): void;
    get issueOccurrencesInput(): cdktf.IResolvable | IssueAlertFiltersV2IssueOccurrences | undefined;
    private _latestAdoptedRelease;
    get latestAdoptedRelease(): IssueAlertFiltersV2LatestAdoptedReleaseOutputReference;
    putLatestAdoptedRelease(value: IssueAlertFiltersV2LatestAdoptedRelease): void;
    resetLatestAdoptedRelease(): void;
    get latestAdoptedReleaseInput(): cdktf.IResolvable | IssueAlertFiltersV2LatestAdoptedRelease | undefined;
    private _latestRelease;
    get latestRelease(): IssueAlertFiltersV2LatestReleaseOutputReference;
    putLatestRelease(value: IssueAlertFiltersV2LatestRelease): void;
    resetLatestRelease(): void;
    get latestReleaseInput(): cdktf.IResolvable | IssueAlertFiltersV2LatestRelease | undefined;
    private _level;
    get level(): IssueAlertFiltersV2LevelOutputReference;
    putLevel(value: IssueAlertFiltersV2Level): void;
    resetLevel(): void;
    get levelInput(): cdktf.IResolvable | IssueAlertFiltersV2Level | undefined;
    private _taggedEvent;
    get taggedEvent(): IssueAlertFiltersV2TaggedEventOutputReference;
    putTaggedEvent(value: IssueAlertFiltersV2TaggedEvent): void;
    resetTaggedEvent(): void;
    get taggedEventInput(): cdktf.IResolvable | IssueAlertFiltersV2TaggedEvent | undefined;
}
export declare class IssueAlertFiltersV2List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: IssueAlertFiltersV2[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IssueAlertFiltersV2OutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert sentry_issue_alert}
*/
export declare class IssueAlert extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_issue_alert";
    /**
    * Generates CDKTF code for importing a IssueAlert resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IssueAlert to import
    * @param importFromId The id of the existing IssueAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IssueAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/issue_alert sentry_issue_alert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IssueAlertConfig
    */
    constructor(scope: Construct, id: string, config: IssueAlertConfig);
    private _actionMatch?;
    get actionMatch(): string;
    set actionMatch(value: string);
    get actionMatchInput(): string | undefined;
    private _actions?;
    get actions(): string;
    set actions(value: string);
    resetActions(): void;
    get actionsInput(): string | undefined;
    private _actionsV2;
    get actionsV2(): IssueAlertActionsV2List;
    putActionsV2(value: IssueAlertActionsV2[] | cdktf.IResolvable): void;
    resetActionsV2(): void;
    get actionsV2Input(): cdktf.IResolvable | IssueAlertActionsV2[] | undefined;
    private _conditions?;
    get conditions(): string;
    set conditions(value: string);
    resetConditions(): void;
    get conditionsInput(): string | undefined;
    private _conditionsV2;
    get conditionsV2(): IssueAlertConditionsV2List;
    putConditionsV2(value: IssueAlertConditionsV2[] | cdktf.IResolvable): void;
    resetConditionsV2(): void;
    get conditionsV2Input(): cdktf.IResolvable | IssueAlertConditionsV2[] | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _filterMatch?;
    get filterMatch(): string;
    set filterMatch(value: string);
    resetFilterMatch(): void;
    get filterMatchInput(): string | undefined;
    private _filters?;
    get filters(): string;
    set filters(value: string);
    resetFilters(): void;
    get filtersInput(): string | undefined;
    private _filtersV2;
    get filtersV2(): IssueAlertFiltersV2List;
    putFiltersV2(value: IssueAlertFiltersV2[] | cdktf.IResolvable): void;
    resetFiltersV2(): void;
    get filtersV2Input(): cdktf.IResolvable | IssueAlertFiltersV2[] | undefined;
    private _frequency?;
    get frequency(): number;
    set frequency(value: number);
    get frequencyInput(): number | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
