import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryProjectIssueStreamMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * Return the first monitor found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_issue_stream_monitor#first DataSentryProjectIssueStreamMonitor#first}
    */
    readonly first?: boolean | cdktf.IResolvable;
    /**
    * The organization slug or internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_issue_stream_monitor#organization DataSentryProjectIssueStreamMonitor#organization}
    */
    readonly organization: string;
    /**
    * The project slug or internal ID of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_issue_stream_monitor#project DataSentryProjectIssueStreamMonitor#project}
    */
    readonly project: string;
}
export interface DataSentryProjectIssueStreamMonitorOwner {
}
export declare function dataSentryProjectIssueStreamMonitorOwnerToTerraform(struct?: DataSentryProjectIssueStreamMonitorOwner): any;
export declare function dataSentryProjectIssueStreamMonitorOwnerToHclTerraform(struct?: DataSentryProjectIssueStreamMonitorOwner): any;
export declare class DataSentryProjectIssueStreamMonitorOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryProjectIssueStreamMonitorOwner | undefined;
    set internalValue(value: DataSentryProjectIssueStreamMonitorOwner | undefined);
    get teamId(): string;
    get userId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_issue_stream_monitor sentry_project_issue_stream_monitor}
*/
export declare class DataSentryProjectIssueStreamMonitor extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_project_issue_stream_monitor";
    /**
    * Generates CDKTF code for importing a DataSentryProjectIssueStreamMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryProjectIssueStreamMonitor to import
    * @param importFromId The id of the existing DataSentryProjectIssueStreamMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_issue_stream_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryProjectIssueStreamMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/project_issue_stream_monitor sentry_project_issue_stream_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryProjectIssueStreamMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryProjectIssueStreamMonitorConfig);
    get description(): string;
    get enabled(): cdktf.IResolvable;
    private _first?;
    get first(): boolean | cdktf.IResolvable;
    set first(value: boolean | cdktf.IResolvable);
    resetFirst(): void;
    get firstInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _owner;
    get owner(): DataSentryProjectIssueStreamMonitorOwnerOutputReference;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
