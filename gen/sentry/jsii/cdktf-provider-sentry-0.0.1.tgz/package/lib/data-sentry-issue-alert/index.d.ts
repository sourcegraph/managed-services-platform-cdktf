import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryIssueAlertConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/issue_alert#id DataSentryIssueAlert#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/issue_alert#organization DataSentryIssueAlert#organization}
    */
    readonly organization: string;
    /**
    * The project the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/issue_alert#project DataSentryIssueAlert#project}
    */
    readonly project: string;
}
export interface DataSentryIssueAlertActionsV2AzureDevopsCreateTicket {
}
export declare function dataSentryIssueAlertActionsV2AzureDevopsCreateTicketToTerraform(struct?: DataSentryIssueAlertActionsV2AzureDevopsCreateTicket): any;
export declare function dataSentryIssueAlertActionsV2AzureDevopsCreateTicketToHclTerraform(struct?: DataSentryIssueAlertActionsV2AzureDevopsCreateTicket): any;
export declare class DataSentryIssueAlertActionsV2AzureDevopsCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2AzureDevopsCreateTicket | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2AzureDevopsCreateTicket | undefined);
    get integration(): string;
    get name(): string;
    get workItemType(): string;
}
export interface DataSentryIssueAlertActionsV2DiscordNotifyService {
}
export declare function dataSentryIssueAlertActionsV2DiscordNotifyServiceToTerraform(struct?: DataSentryIssueAlertActionsV2DiscordNotifyService): any;
export declare function dataSentryIssueAlertActionsV2DiscordNotifyServiceToHclTerraform(struct?: DataSentryIssueAlertActionsV2DiscordNotifyService): any;
export declare class DataSentryIssueAlertActionsV2DiscordNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2DiscordNotifyService | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2DiscordNotifyService | undefined);
    get channelId(): string;
    get name(): string;
    get server(): string;
    get tags(): string[];
}
export interface DataSentryIssueAlertActionsV2GithubCreateTicket {
}
export declare function dataSentryIssueAlertActionsV2GithubCreateTicketToTerraform(struct?: DataSentryIssueAlertActionsV2GithubCreateTicket): any;
export declare function dataSentryIssueAlertActionsV2GithubCreateTicketToHclTerraform(struct?: DataSentryIssueAlertActionsV2GithubCreateTicket): any;
export declare class DataSentryIssueAlertActionsV2GithubCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2GithubCreateTicket | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2GithubCreateTicket | undefined);
    get assignee(): string;
    get integration(): string;
    get labels(): string[];
    get name(): string;
    get repo(): string;
}
export interface DataSentryIssueAlertActionsV2GithubEnterpriseCreateTicket {
}
export declare function dataSentryIssueAlertActionsV2GithubEnterpriseCreateTicketToTerraform(struct?: DataSentryIssueAlertActionsV2GithubEnterpriseCreateTicket): any;
export declare function dataSentryIssueAlertActionsV2GithubEnterpriseCreateTicketToHclTerraform(struct?: DataSentryIssueAlertActionsV2GithubEnterpriseCreateTicket): any;
export declare class DataSentryIssueAlertActionsV2GithubEnterpriseCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2GithubEnterpriseCreateTicket | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2GithubEnterpriseCreateTicket | undefined);
    get assignee(): string;
    get integration(): string;
    get labels(): string[];
    get name(): string;
    get repo(): string;
}
export interface DataSentryIssueAlertActionsV2JiraCreateTicket {
}
export declare function dataSentryIssueAlertActionsV2JiraCreateTicketToTerraform(struct?: DataSentryIssueAlertActionsV2JiraCreateTicket): any;
export declare function dataSentryIssueAlertActionsV2JiraCreateTicketToHclTerraform(struct?: DataSentryIssueAlertActionsV2JiraCreateTicket): any;
export declare class DataSentryIssueAlertActionsV2JiraCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2JiraCreateTicket | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2JiraCreateTicket | undefined);
    get integration(): string;
    get issueType(): string;
    get name(): string;
    get project(): string;
}
export interface DataSentryIssueAlertActionsV2JiraServerCreateTicket {
}
export declare function dataSentryIssueAlertActionsV2JiraServerCreateTicketToTerraform(struct?: DataSentryIssueAlertActionsV2JiraServerCreateTicket): any;
export declare function dataSentryIssueAlertActionsV2JiraServerCreateTicketToHclTerraform(struct?: DataSentryIssueAlertActionsV2JiraServerCreateTicket): any;
export declare class DataSentryIssueAlertActionsV2JiraServerCreateTicketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2JiraServerCreateTicket | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2JiraServerCreateTicket | undefined);
    get integration(): string;
    get issueType(): string;
    get name(): string;
    get project(): string;
}
export interface DataSentryIssueAlertActionsV2MsteamsNotifyService {
}
export declare function dataSentryIssueAlertActionsV2MsteamsNotifyServiceToTerraform(struct?: DataSentryIssueAlertActionsV2MsteamsNotifyService): any;
export declare function dataSentryIssueAlertActionsV2MsteamsNotifyServiceToHclTerraform(struct?: DataSentryIssueAlertActionsV2MsteamsNotifyService): any;
export declare class DataSentryIssueAlertActionsV2MsteamsNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2MsteamsNotifyService | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2MsteamsNotifyService | undefined);
    get channel(): string;
    get channelId(): string;
    get name(): string;
    get team(): string;
}
export interface DataSentryIssueAlertActionsV2NotifyEmail {
}
export declare function dataSentryIssueAlertActionsV2NotifyEmailToTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEmail): any;
export declare function dataSentryIssueAlertActionsV2NotifyEmailToHclTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEmail): any;
export declare class DataSentryIssueAlertActionsV2NotifyEmailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2NotifyEmail | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2NotifyEmail | undefined);
    get fallthroughType(): string;
    get name(): string;
    get targetIdentifier(): string;
    get targetType(): string;
}
export interface DataSentryIssueAlertActionsV2NotifyEvent {
}
export declare function dataSentryIssueAlertActionsV2NotifyEventToTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEvent): any;
export declare function dataSentryIssueAlertActionsV2NotifyEventToHclTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEvent): any;
export declare class DataSentryIssueAlertActionsV2NotifyEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2NotifyEvent | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2NotifyEvent | undefined);
    get name(): string;
}
export interface DataSentryIssueAlertActionsV2NotifyEventSentryApp {
}
export declare function dataSentryIssueAlertActionsV2NotifyEventSentryAppToTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEventSentryApp): any;
export declare function dataSentryIssueAlertActionsV2NotifyEventSentryAppToHclTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEventSentryApp): any;
export declare class DataSentryIssueAlertActionsV2NotifyEventSentryAppOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2NotifyEventSentryApp | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2NotifyEventSentryApp | undefined);
    get name(): string;
    get sentryAppInstallationUuid(): string;
    private _settings;
    get settings(): cdktf.StringMap;
    private _settingsLabels;
    get settingsLabels(): cdktf.StringMap;
}
export interface DataSentryIssueAlertActionsV2NotifyEventService {
}
export declare function dataSentryIssueAlertActionsV2NotifyEventServiceToTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEventService): any;
export declare function dataSentryIssueAlertActionsV2NotifyEventServiceToHclTerraform(struct?: DataSentryIssueAlertActionsV2NotifyEventService): any;
export declare class DataSentryIssueAlertActionsV2NotifyEventServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2NotifyEventService | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2NotifyEventService | undefined);
    get name(): string;
    get service(): string;
}
export interface DataSentryIssueAlertActionsV2OpsgenieNotifyTeam {
}
export declare function dataSentryIssueAlertActionsV2OpsgenieNotifyTeamToTerraform(struct?: DataSentryIssueAlertActionsV2OpsgenieNotifyTeam): any;
export declare function dataSentryIssueAlertActionsV2OpsgenieNotifyTeamToHclTerraform(struct?: DataSentryIssueAlertActionsV2OpsgenieNotifyTeam): any;
export declare class DataSentryIssueAlertActionsV2OpsgenieNotifyTeamOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2OpsgenieNotifyTeam | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2OpsgenieNotifyTeam | undefined);
    get account(): string;
    get name(): string;
    get priority(): string;
    get team(): string;
}
export interface DataSentryIssueAlertActionsV2PagerdutyNotifyService {
}
export declare function dataSentryIssueAlertActionsV2PagerdutyNotifyServiceToTerraform(struct?: DataSentryIssueAlertActionsV2PagerdutyNotifyService): any;
export declare function dataSentryIssueAlertActionsV2PagerdutyNotifyServiceToHclTerraform(struct?: DataSentryIssueAlertActionsV2PagerdutyNotifyService): any;
export declare class DataSentryIssueAlertActionsV2PagerdutyNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2PagerdutyNotifyService | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2PagerdutyNotifyService | undefined);
    get account(): string;
    get name(): string;
    get service(): string;
    get severity(): string;
}
export interface DataSentryIssueAlertActionsV2SlackNotifyService {
}
export declare function dataSentryIssueAlertActionsV2SlackNotifyServiceToTerraform(struct?: DataSentryIssueAlertActionsV2SlackNotifyService): any;
export declare function dataSentryIssueAlertActionsV2SlackNotifyServiceToHclTerraform(struct?: DataSentryIssueAlertActionsV2SlackNotifyService): any;
export declare class DataSentryIssueAlertActionsV2SlackNotifyServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertActionsV2SlackNotifyService | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2SlackNotifyService | undefined);
    get channel(): string;
    get channelId(): string;
    get name(): string;
    get notes(): string;
    get tags(): string[];
    get workspace(): string;
}
export interface DataSentryIssueAlertActionsV2 {
}
export declare function dataSentryIssueAlertActionsV2ToTerraform(struct?: DataSentryIssueAlertActionsV2): any;
export declare function dataSentryIssueAlertActionsV2ToHclTerraform(struct?: DataSentryIssueAlertActionsV2): any;
export declare class DataSentryIssueAlertActionsV2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryIssueAlertActionsV2 | undefined;
    set internalValue(value: DataSentryIssueAlertActionsV2 | undefined);
    private _azureDevopsCreateTicket;
    get azureDevopsCreateTicket(): DataSentryIssueAlertActionsV2AzureDevopsCreateTicketOutputReference;
    private _discordNotifyService;
    get discordNotifyService(): DataSentryIssueAlertActionsV2DiscordNotifyServiceOutputReference;
    private _githubCreateTicket;
    get githubCreateTicket(): DataSentryIssueAlertActionsV2GithubCreateTicketOutputReference;
    private _githubEnterpriseCreateTicket;
    get githubEnterpriseCreateTicket(): DataSentryIssueAlertActionsV2GithubEnterpriseCreateTicketOutputReference;
    private _jiraCreateTicket;
    get jiraCreateTicket(): DataSentryIssueAlertActionsV2JiraCreateTicketOutputReference;
    private _jiraServerCreateTicket;
    get jiraServerCreateTicket(): DataSentryIssueAlertActionsV2JiraServerCreateTicketOutputReference;
    private _msteamsNotifyService;
    get msteamsNotifyService(): DataSentryIssueAlertActionsV2MsteamsNotifyServiceOutputReference;
    private _notifyEmail;
    get notifyEmail(): DataSentryIssueAlertActionsV2NotifyEmailOutputReference;
    private _notifyEvent;
    get notifyEvent(): DataSentryIssueAlertActionsV2NotifyEventOutputReference;
    private _notifyEventSentryApp;
    get notifyEventSentryApp(): DataSentryIssueAlertActionsV2NotifyEventSentryAppOutputReference;
    private _notifyEventService;
    get notifyEventService(): DataSentryIssueAlertActionsV2NotifyEventServiceOutputReference;
    private _opsgenieNotifyTeam;
    get opsgenieNotifyTeam(): DataSentryIssueAlertActionsV2OpsgenieNotifyTeamOutputReference;
    private _pagerdutyNotifyService;
    get pagerdutyNotifyService(): DataSentryIssueAlertActionsV2PagerdutyNotifyServiceOutputReference;
    private _slackNotifyService;
    get slackNotifyService(): DataSentryIssueAlertActionsV2SlackNotifyServiceOutputReference;
}
export declare class DataSentryIssueAlertActionsV2List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryIssueAlertActionsV2OutputReference;
}
export interface DataSentryIssueAlertConditionsV2EventFrequency {
}
export declare function dataSentryIssueAlertConditionsV2EventFrequencyToTerraform(struct?: DataSentryIssueAlertConditionsV2EventFrequency): any;
export declare function dataSentryIssueAlertConditionsV2EventFrequencyToHclTerraform(struct?: DataSentryIssueAlertConditionsV2EventFrequency): any;
export declare class DataSentryIssueAlertConditionsV2EventFrequencyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2EventFrequency | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2EventFrequency | undefined);
    get comparisonInterval(): string;
    get comparisonType(): string;
    get interval(): string;
    get name(): string;
    get value(): number;
}
export interface DataSentryIssueAlertConditionsV2EventFrequencyPercent {
}
export declare function dataSentryIssueAlertConditionsV2EventFrequencyPercentToTerraform(struct?: DataSentryIssueAlertConditionsV2EventFrequencyPercent): any;
export declare function dataSentryIssueAlertConditionsV2EventFrequencyPercentToHclTerraform(struct?: DataSentryIssueAlertConditionsV2EventFrequencyPercent): any;
export declare class DataSentryIssueAlertConditionsV2EventFrequencyPercentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2EventFrequencyPercent | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2EventFrequencyPercent | undefined);
    get comparisonInterval(): string;
    get comparisonType(): string;
    get interval(): string;
    get name(): string;
    get value(): number;
}
export interface DataSentryIssueAlertConditionsV2EventUniqueUserFrequency {
}
export declare function dataSentryIssueAlertConditionsV2EventUniqueUserFrequencyToTerraform(struct?: DataSentryIssueAlertConditionsV2EventUniqueUserFrequency): any;
export declare function dataSentryIssueAlertConditionsV2EventUniqueUserFrequencyToHclTerraform(struct?: DataSentryIssueAlertConditionsV2EventUniqueUserFrequency): any;
export declare class DataSentryIssueAlertConditionsV2EventUniqueUserFrequencyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2EventUniqueUserFrequency | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2EventUniqueUserFrequency | undefined);
    get comparisonInterval(): string;
    get comparisonType(): string;
    get interval(): string;
    get name(): string;
    get value(): number;
}
export interface DataSentryIssueAlertConditionsV2ExistingHighPriorityIssue {
}
export declare function dataSentryIssueAlertConditionsV2ExistingHighPriorityIssueToTerraform(struct?: DataSentryIssueAlertConditionsV2ExistingHighPriorityIssue): any;
export declare function dataSentryIssueAlertConditionsV2ExistingHighPriorityIssueToHclTerraform(struct?: DataSentryIssueAlertConditionsV2ExistingHighPriorityIssue): any;
export declare class DataSentryIssueAlertConditionsV2ExistingHighPriorityIssueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2ExistingHighPriorityIssue | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2ExistingHighPriorityIssue | undefined);
    get name(): string;
}
export interface DataSentryIssueAlertConditionsV2FirstSeenEvent {
}
export declare function dataSentryIssueAlertConditionsV2FirstSeenEventToTerraform(struct?: DataSentryIssueAlertConditionsV2FirstSeenEvent): any;
export declare function dataSentryIssueAlertConditionsV2FirstSeenEventToHclTerraform(struct?: DataSentryIssueAlertConditionsV2FirstSeenEvent): any;
export declare class DataSentryIssueAlertConditionsV2FirstSeenEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2FirstSeenEvent | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2FirstSeenEvent | undefined);
    get name(): string;
}
export interface DataSentryIssueAlertConditionsV2NewHighPriorityIssue {
}
export declare function dataSentryIssueAlertConditionsV2NewHighPriorityIssueToTerraform(struct?: DataSentryIssueAlertConditionsV2NewHighPriorityIssue): any;
export declare function dataSentryIssueAlertConditionsV2NewHighPriorityIssueToHclTerraform(struct?: DataSentryIssueAlertConditionsV2NewHighPriorityIssue): any;
export declare class DataSentryIssueAlertConditionsV2NewHighPriorityIssueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2NewHighPriorityIssue | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2NewHighPriorityIssue | undefined);
    get name(): string;
}
export interface DataSentryIssueAlertConditionsV2ReappearedEvent {
}
export declare function dataSentryIssueAlertConditionsV2ReappearedEventToTerraform(struct?: DataSentryIssueAlertConditionsV2ReappearedEvent): any;
export declare function dataSentryIssueAlertConditionsV2ReappearedEventToHclTerraform(struct?: DataSentryIssueAlertConditionsV2ReappearedEvent): any;
export declare class DataSentryIssueAlertConditionsV2ReappearedEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2ReappearedEvent | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2ReappearedEvent | undefined);
    get name(): string;
}
export interface DataSentryIssueAlertConditionsV2RegressionEvent {
}
export declare function dataSentryIssueAlertConditionsV2RegressionEventToTerraform(struct?: DataSentryIssueAlertConditionsV2RegressionEvent): any;
export declare function dataSentryIssueAlertConditionsV2RegressionEventToHclTerraform(struct?: DataSentryIssueAlertConditionsV2RegressionEvent): any;
export declare class DataSentryIssueAlertConditionsV2RegressionEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertConditionsV2RegressionEvent | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2RegressionEvent | undefined);
    get name(): string;
}
export interface DataSentryIssueAlertConditionsV2 {
}
export declare function dataSentryIssueAlertConditionsV2ToTerraform(struct?: DataSentryIssueAlertConditionsV2): any;
export declare function dataSentryIssueAlertConditionsV2ToHclTerraform(struct?: DataSentryIssueAlertConditionsV2): any;
export declare class DataSentryIssueAlertConditionsV2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryIssueAlertConditionsV2 | undefined;
    set internalValue(value: DataSentryIssueAlertConditionsV2 | undefined);
    private _eventFrequency;
    get eventFrequency(): DataSentryIssueAlertConditionsV2EventFrequencyOutputReference;
    private _eventFrequencyPercent;
    get eventFrequencyPercent(): DataSentryIssueAlertConditionsV2EventFrequencyPercentOutputReference;
    private _eventUniqueUserFrequency;
    get eventUniqueUserFrequency(): DataSentryIssueAlertConditionsV2EventUniqueUserFrequencyOutputReference;
    private _existingHighPriorityIssue;
    get existingHighPriorityIssue(): DataSentryIssueAlertConditionsV2ExistingHighPriorityIssueOutputReference;
    private _firstSeenEvent;
    get firstSeenEvent(): DataSentryIssueAlertConditionsV2FirstSeenEventOutputReference;
    private _newHighPriorityIssue;
    get newHighPriorityIssue(): DataSentryIssueAlertConditionsV2NewHighPriorityIssueOutputReference;
    private _reappearedEvent;
    get reappearedEvent(): DataSentryIssueAlertConditionsV2ReappearedEventOutputReference;
    private _regressionEvent;
    get regressionEvent(): DataSentryIssueAlertConditionsV2RegressionEventOutputReference;
}
export declare class DataSentryIssueAlertConditionsV2List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryIssueAlertConditionsV2OutputReference;
}
export interface DataSentryIssueAlertFiltersV2AgeComparison {
}
export declare function dataSentryIssueAlertFiltersV2AgeComparisonToTerraform(struct?: DataSentryIssueAlertFiltersV2AgeComparison): any;
export declare function dataSentryIssueAlertFiltersV2AgeComparisonToHclTerraform(struct?: DataSentryIssueAlertFiltersV2AgeComparison): any;
export declare class DataSentryIssueAlertFiltersV2AgeComparisonOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2AgeComparison | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2AgeComparison | undefined);
    get comparisonType(): string;
    get name(): string;
    get time(): string;
    get value(): number;
}
export interface DataSentryIssueAlertFiltersV2AssignedTo {
}
export declare function dataSentryIssueAlertFiltersV2AssignedToToTerraform(struct?: DataSentryIssueAlertFiltersV2AssignedTo): any;
export declare function dataSentryIssueAlertFiltersV2AssignedToToHclTerraform(struct?: DataSentryIssueAlertFiltersV2AssignedTo): any;
export declare class DataSentryIssueAlertFiltersV2AssignedToOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2AssignedTo | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2AssignedTo | undefined);
    get name(): string;
    get targetIdentifier(): number;
    get targetType(): number;
}
export interface DataSentryIssueAlertFiltersV2EventAttribute {
}
export declare function dataSentryIssueAlertFiltersV2EventAttributeToTerraform(struct?: DataSentryIssueAlertFiltersV2EventAttribute): any;
export declare function dataSentryIssueAlertFiltersV2EventAttributeToHclTerraform(struct?: DataSentryIssueAlertFiltersV2EventAttribute): any;
export declare class DataSentryIssueAlertFiltersV2EventAttributeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2EventAttribute | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2EventAttribute | undefined);
    get attribute(): string;
    get match(): string;
    get name(): string;
    get value(): string;
}
export interface DataSentryIssueAlertFiltersV2IssueCategory {
}
export declare function dataSentryIssueAlertFiltersV2IssueCategoryToTerraform(struct?: DataSentryIssueAlertFiltersV2IssueCategory): any;
export declare function dataSentryIssueAlertFiltersV2IssueCategoryToHclTerraform(struct?: DataSentryIssueAlertFiltersV2IssueCategory): any;
export declare class DataSentryIssueAlertFiltersV2IssueCategoryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2IssueCategory | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2IssueCategory | undefined);
    get name(): string;
    get value(): string;
}
export interface DataSentryIssueAlertFiltersV2IssueOccurrences {
}
export declare function dataSentryIssueAlertFiltersV2IssueOccurrencesToTerraform(struct?: DataSentryIssueAlertFiltersV2IssueOccurrences): any;
export declare function dataSentryIssueAlertFiltersV2IssueOccurrencesToHclTerraform(struct?: DataSentryIssueAlertFiltersV2IssueOccurrences): any;
export declare class DataSentryIssueAlertFiltersV2IssueOccurrencesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2IssueOccurrences | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2IssueOccurrences | undefined);
    get name(): string;
    get value(): number;
}
export interface DataSentryIssueAlertFiltersV2LatestAdoptedRelease {
}
export declare function dataSentryIssueAlertFiltersV2LatestAdoptedReleaseToTerraform(struct?: DataSentryIssueAlertFiltersV2LatestAdoptedRelease): any;
export declare function dataSentryIssueAlertFiltersV2LatestAdoptedReleaseToHclTerraform(struct?: DataSentryIssueAlertFiltersV2LatestAdoptedRelease): any;
export declare class DataSentryIssueAlertFiltersV2LatestAdoptedReleaseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2LatestAdoptedRelease | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2LatestAdoptedRelease | undefined);
    get environment(): number;
    get name(): string;
    get olderOrNewer(): number;
    get oldestOrNewest(): number;
}
export interface DataSentryIssueAlertFiltersV2LatestRelease {
}
export declare function dataSentryIssueAlertFiltersV2LatestReleaseToTerraform(struct?: DataSentryIssueAlertFiltersV2LatestRelease): any;
export declare function dataSentryIssueAlertFiltersV2LatestReleaseToHclTerraform(struct?: DataSentryIssueAlertFiltersV2LatestRelease): any;
export declare class DataSentryIssueAlertFiltersV2LatestReleaseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2LatestRelease | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2LatestRelease | undefined);
    get name(): string;
}
export interface DataSentryIssueAlertFiltersV2Level {
}
export declare function dataSentryIssueAlertFiltersV2LevelToTerraform(struct?: DataSentryIssueAlertFiltersV2Level): any;
export declare function dataSentryIssueAlertFiltersV2LevelToHclTerraform(struct?: DataSentryIssueAlertFiltersV2Level): any;
export declare class DataSentryIssueAlertFiltersV2LevelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2Level | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2Level | undefined);
    get level(): string;
    get match(): string;
    get name(): string;
}
export interface DataSentryIssueAlertFiltersV2TaggedEvent {
}
export declare function dataSentryIssueAlertFiltersV2TaggedEventToTerraform(struct?: DataSentryIssueAlertFiltersV2TaggedEvent): any;
export declare function dataSentryIssueAlertFiltersV2TaggedEventToHclTerraform(struct?: DataSentryIssueAlertFiltersV2TaggedEvent): any;
export declare class DataSentryIssueAlertFiltersV2TaggedEventOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSentryIssueAlertFiltersV2TaggedEvent | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2TaggedEvent | undefined);
    get key(): string;
    get match(): string;
    get name(): string;
    get value(): string;
}
export interface DataSentryIssueAlertFiltersV2 {
}
export declare function dataSentryIssueAlertFiltersV2ToTerraform(struct?: DataSentryIssueAlertFiltersV2): any;
export declare function dataSentryIssueAlertFiltersV2ToHclTerraform(struct?: DataSentryIssueAlertFiltersV2): any;
export declare class DataSentryIssueAlertFiltersV2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSentryIssueAlertFiltersV2 | undefined;
    set internalValue(value: DataSentryIssueAlertFiltersV2 | undefined);
    private _ageComparison;
    get ageComparison(): DataSentryIssueAlertFiltersV2AgeComparisonOutputReference;
    private _assignedTo;
    get assignedTo(): DataSentryIssueAlertFiltersV2AssignedToOutputReference;
    private _eventAttribute;
    get eventAttribute(): DataSentryIssueAlertFiltersV2EventAttributeOutputReference;
    private _issueCategory;
    get issueCategory(): DataSentryIssueAlertFiltersV2IssueCategoryOutputReference;
    private _issueOccurrences;
    get issueOccurrences(): DataSentryIssueAlertFiltersV2IssueOccurrencesOutputReference;
    private _latestAdoptedRelease;
    get latestAdoptedRelease(): DataSentryIssueAlertFiltersV2LatestAdoptedReleaseOutputReference;
    private _latestRelease;
    get latestRelease(): DataSentryIssueAlertFiltersV2LatestReleaseOutputReference;
    private _level;
    get level(): DataSentryIssueAlertFiltersV2LevelOutputReference;
    private _taggedEvent;
    get taggedEvent(): DataSentryIssueAlertFiltersV2TaggedEventOutputReference;
}
export declare class DataSentryIssueAlertFiltersV2List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSentryIssueAlertFiltersV2OutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/issue_alert sentry_issue_alert}
*/
export declare class DataSentryIssueAlert extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_issue_alert";
    /**
    * Generates CDKTF code for importing a DataSentryIssueAlert resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryIssueAlert to import
    * @param importFromId The id of the existing DataSentryIssueAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/issue_alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryIssueAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/issue_alert sentry_issue_alert} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryIssueAlertConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryIssueAlertConfig);
    get actionMatch(): string;
    get actions(): string;
    private _actionsV2;
    get actionsV2(): DataSentryIssueAlertActionsV2List;
    get conditions(): string;
    private _conditionsV2;
    get conditionsV2(): DataSentryIssueAlertConditionsV2List;
    get environment(): string;
    get filterMatch(): string;
    get filters(): string;
    private _filtersV2;
    get filtersV2(): DataSentryIssueAlertFiltersV2List;
    get frequency(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get owner(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
