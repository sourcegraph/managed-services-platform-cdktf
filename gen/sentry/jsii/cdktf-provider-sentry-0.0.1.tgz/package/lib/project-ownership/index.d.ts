import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectOwnershipConfig extends cdktf.TerraformMetaArguments {
    /**
    * The auto-assignment mode. The options are: `Auto Assign to Issue Owner`, `Auto Assign to Suspect Commits`, and `Turn off Auto-Assignment`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership#auto_assignment ProjectOwnership#auto_assignment}
    */
    readonly autoAssignment: string;
    /**
    * Whether to automatically sync codeowners.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership#codeowners_auto_sync ProjectOwnership#codeowners_auto_sync}
    */
    readonly codeownersAutoSync: boolean | cdktf.IResolvable;
    /**
    * Whether to fall through to the default ownership rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership#fallthrough ProjectOwnership#fallthrough}
    */
    readonly fallthrough: boolean | cdktf.IResolvable;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership#organization ProjectOwnership#organization}
    */
    readonly organization: string;
    /**
    * The project of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership#project ProjectOwnership#project}
    */
    readonly project: string;
    /**
    * Raw input for ownership configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership#raw ProjectOwnership#raw}
    */
    readonly raw: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership sentry_project_ownership}
*/
export declare class ProjectOwnership extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_project_ownership";
    /**
    * Generates CDKTF code for importing a ProjectOwnership resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectOwnership to import
    * @param importFromId The id of the existing ProjectOwnership that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectOwnership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/project_ownership sentry_project_ownership} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectOwnershipConfig
    */
    constructor(scope: Construct, id: string, config: ProjectOwnershipConfig);
    private _autoAssignment?;
    get autoAssignment(): string;
    set autoAssignment(value: string);
    get autoAssignmentInput(): string | undefined;
    private _codeownersAutoSync?;
    get codeownersAutoSync(): boolean | cdktf.IResolvable;
    set codeownersAutoSync(value: boolean | cdktf.IResolvable);
    get codeownersAutoSyncInput(): boolean | cdktf.IResolvable | undefined;
    private _fallthrough?;
    get fallthrough(): boolean | cdktf.IResolvable;
    set fallthrough(value: boolean | cdktf.IResolvable);
    get fallthroughInput(): boolean | cdktf.IResolvable | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _raw?;
    get raw(): string;
    set raw(value: string);
    get rawInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
