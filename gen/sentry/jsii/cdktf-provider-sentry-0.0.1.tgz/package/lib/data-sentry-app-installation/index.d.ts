import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataSentryAppInstallationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The organization the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/app_installation#organization DataSentryAppInstallation#organization}
    */
    readonly organization: string;
    /**
    * The slug of the Sentry App to look up.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/app_installation#slug DataSentryAppInstallation#slug}
    */
    readonly slug: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/app_installation sentry_app_installation}
*/
export declare class DataSentryAppInstallation extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "sentry_app_installation";
    /**
    * Generates CDKTF code for importing a DataSentryAppInstallation resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSentryAppInstallation to import
    * @param importFromId The id of the existing DataSentryAppInstallation that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/app_installation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSentryAppInstallation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/data-sources/app_installation sentry_app_installation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSentryAppInstallationConfig
    */
    constructor(scope: Construct, id: string, config: DataSentryAppInstallationConfig);
    get appUuid(): string;
    get id(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    get sentryAppId(): number;
    private _slug?;
    get slug(): string;
    set slug(value: string);
    get slugInput(): string | undefined;
    get status(): string;
    get uuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
