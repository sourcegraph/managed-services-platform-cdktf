import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntegrationOpsgenieConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Opsgenie integration. Source from the URL `https://<organization>.sentry.io/settings/integrations/opsgenie/<integration-id>/` or use the `sentry_organization_integration` data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_opsgenie#integration_id IntegrationOpsgenie#integration_id}
    */
    readonly integrationId: string;
    /**
    * The integration key of the Opsgenie service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_opsgenie#integration_key IntegrationOpsgenie#integration_key}
    */
    readonly integrationKey: string;
    /**
    * The organization of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_opsgenie#organization IntegrationOpsgenie#organization}
    */
    readonly organization: string;
    /**
    * The name of the Opsgenie team. In Sentry, this is called Label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_opsgenie#team IntegrationOpsgenie#team}
    */
    readonly team: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_opsgenie sentry_integration_opsgenie}
*/
export declare class IntegrationOpsgenie extends cdktf.TerraformResource {
    static readonly tfResourceType = "sentry_integration_opsgenie";
    /**
    * Generates CDKTF code for importing a IntegrationOpsgenie resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationOpsgenie to import
    * @param importFromId The id of the existing IntegrationOpsgenie that should be imported. Refer to the {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_opsgenie#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationOpsgenie to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/jianyuan/sentry/0.15.7/docs/resources/integration_opsgenie sentry_integration_opsgenie} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationOpsgenieConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationOpsgenieConfig);
    get id(): string;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    get integrationIdInput(): string | undefined;
    private _integrationKey?;
    get integrationKey(): string;
    set integrationKey(value: string);
    get integrationKeyInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _team?;
    get team(): string;
    set team(value: string);
    get teamInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
