# `data_google_artifact_registry_locations`

Refer to the Terraform Registry for docs: [`data_google_artifact_registry_locations`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/data-sources/artifact_registry_locations).
