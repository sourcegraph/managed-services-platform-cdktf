# `google_compute_target_tcp_proxy`

Refer to the Terraform Registry for docs: [`google_compute_target_tcp_proxy`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_target_tcp_proxy).
