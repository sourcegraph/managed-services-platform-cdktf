# `google_bigtable_authorized_view`

Refer to the Terraform Registry for docs: [`google_bigtable_authorized_view`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigtable_authorized_view).
