# `google_bigtable_table`

Refer to the Terraform Registry for docs: [`google_bigtable_table`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigtable_table).
