# `google_compute_project_metadata`

Refer to the Terraform Registry for docs: [`google_compute_project_metadata`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_project_metadata).
