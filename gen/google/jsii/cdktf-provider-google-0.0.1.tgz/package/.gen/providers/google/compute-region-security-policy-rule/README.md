# `google_compute_region_security_policy_rule`

Refer to the Terraform Registry for docs: [`google_compute_region_security_policy_rule`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_region_security_policy_rule).
