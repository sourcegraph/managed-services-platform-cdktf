# `google_beyondcorp_security_gateway_application`

Refer to the Terraform Registry for docs: [`google_beyondcorp_security_gateway_application`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/beyondcorp_security_gateway_application).
