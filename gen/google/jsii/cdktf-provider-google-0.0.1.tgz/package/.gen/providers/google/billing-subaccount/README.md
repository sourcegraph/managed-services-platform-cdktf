# `google_billing_subaccount`

Refer to the Terraform Registry for docs: [`google_billing_subaccount`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/billing_subaccount).
