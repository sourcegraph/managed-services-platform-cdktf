# `google_billing_project_info`

Refer to the Terraform Registry for docs: [`google_billing_project_info`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/billing_project_info).
