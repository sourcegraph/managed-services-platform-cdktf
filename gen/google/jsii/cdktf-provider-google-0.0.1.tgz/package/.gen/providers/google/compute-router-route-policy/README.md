# `google_compute_router_route_policy`

Refer to the Terraform Registry for docs: [`google_compute_router_route_policy`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_router_route_policy).
