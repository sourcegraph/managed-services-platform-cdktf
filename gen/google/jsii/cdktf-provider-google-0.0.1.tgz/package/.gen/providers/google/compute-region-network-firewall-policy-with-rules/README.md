# `google_compute_region_network_firewall_policy_with_rules`

Refer to the Terraform Registry for docs: [`google_compute_region_network_firewall_policy_with_rules`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_region_network_firewall_policy_with_rules).
