# `google_compute_ssl_certificate`

Refer to the Terraform Registry for docs: [`google_compute_ssl_certificate`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_ssl_certificate).
