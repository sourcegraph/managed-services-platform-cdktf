# `google_contact_center_insights_qa_scorecard_revision`

Refer to the Terraform Registry for docs: [`google_contact_center_insights_qa_scorecard_revision`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/contact_center_insights_qa_scorecard_revision).
