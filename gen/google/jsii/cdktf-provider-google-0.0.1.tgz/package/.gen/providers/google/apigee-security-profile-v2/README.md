# `google_apigee_security_profile_v2`

Refer to the Terraform Registry for docs: [`google_apigee_security_profile_v2`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/apigee_security_profile_v2).
