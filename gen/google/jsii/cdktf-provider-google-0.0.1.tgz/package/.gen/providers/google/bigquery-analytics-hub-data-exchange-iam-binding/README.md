# `google_bigquery_analytics_hub_data_exchange_iam_binding`

Refer to the Terraform Registry for docs: [`google_bigquery_analytics_hub_data_exchange_iam_binding`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigquery_analytics_hub_data_exchange_iam_binding).
