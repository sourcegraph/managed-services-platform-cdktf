# `google_compute_storage_pool_iam_policy`

Refer to the Terraform Registry for docs: [`google_compute_storage_pool_iam_policy`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_storage_pool_iam_policy).
