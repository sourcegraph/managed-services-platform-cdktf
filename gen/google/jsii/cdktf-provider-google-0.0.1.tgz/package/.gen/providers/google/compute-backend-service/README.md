# `google_compute_backend_service`

Refer to the Terraform Registry for docs: [`google_compute_backend_service`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_backend_service).
