# `data_google_alloydb_supported_database_flags`

Refer to the Terraform Registry for docs: [`data_google_alloydb_supported_database_flags`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/data-sources/alloydb_supported_database_flags).
