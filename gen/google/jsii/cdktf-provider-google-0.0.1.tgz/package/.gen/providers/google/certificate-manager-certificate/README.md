# `google_certificate_manager_certificate`

Refer to the Terraform Registry for docs: [`google_certificate_manager_certificate`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/certificate_manager_certificate).
