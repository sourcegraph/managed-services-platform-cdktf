# `google_backup_dr_service_config`

Refer to the Terraform Registry for docs: [`google_backup_dr_service_config`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/backup_dr_service_config).
