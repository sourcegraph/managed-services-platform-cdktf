# `google_compute_resize_request`

Refer to the Terraform Registry for docs: [`google_compute_resize_request`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_resize_request).
