# `google_chronicle_data_access_scope`

Refer to the Terraform Registry for docs: [`google_chronicle_data_access_scope`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/chronicle_data_access_scope).
