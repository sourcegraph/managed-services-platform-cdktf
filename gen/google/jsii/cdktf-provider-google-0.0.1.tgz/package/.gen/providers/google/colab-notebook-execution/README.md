# `google_colab_notebook_execution`

Refer to the Terraform Registry for docs: [`google_colab_notebook_execution`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/colab_notebook_execution).
