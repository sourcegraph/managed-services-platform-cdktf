# `google_chronicle_rule`

Refer to the Terraform Registry for docs: [`google_chronicle_rule`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/chronicle_rule).
