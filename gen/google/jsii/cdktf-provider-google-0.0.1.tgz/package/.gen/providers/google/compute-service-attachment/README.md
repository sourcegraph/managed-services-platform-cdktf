# `google_compute_service_attachment`

Refer to the Terraform Registry for docs: [`google_compute_service_attachment`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_service_attachment).
