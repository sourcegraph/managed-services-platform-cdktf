# `google_compute_region_commitment`

Refer to the Terraform Registry for docs: [`google_compute_region_commitment`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_region_commitment).
