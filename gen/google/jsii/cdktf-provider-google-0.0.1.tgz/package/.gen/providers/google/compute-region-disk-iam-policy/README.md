# `google_compute_region_disk_iam_policy`

Refer to the Terraform Registry for docs: [`google_compute_region_disk_iam_policy`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_region_disk_iam_policy).
