# `google_bigquery_datapolicyv2_data_policy_iam_policy`

Refer to the Terraform Registry for docs: [`google_bigquery_datapolicyv2_data_policy_iam_policy`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigquery_datapolicyv2_data_policy_iam_policy).
