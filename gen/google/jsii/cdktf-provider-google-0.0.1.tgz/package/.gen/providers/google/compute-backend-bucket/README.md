# `google_compute_backend_bucket`

Refer to the Terraform Registry for docs: [`google_compute_backend_bucket`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_backend_bucket).
