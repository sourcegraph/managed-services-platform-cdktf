# `google_compute_project_default_network_tier`

Refer to the Terraform Registry for docs: [`google_compute_project_default_network_tier`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_project_default_network_tier).
