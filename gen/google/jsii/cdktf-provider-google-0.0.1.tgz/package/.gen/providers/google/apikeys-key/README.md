# `google_apikeys_key`

Refer to the Terraform Registry for docs: [`google_apikeys_key`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/apikeys_key).
