# `google_bigtable_instance`

Refer to the Terraform Registry for docs: [`google_bigtable_instance`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigtable_instance).
