# `google_bigtable_app_profile`

Refer to the Terraform Registry for docs: [`google_bigtable_app_profile`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigtable_app_profile).
