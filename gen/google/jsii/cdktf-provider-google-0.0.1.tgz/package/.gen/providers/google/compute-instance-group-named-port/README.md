# `google_compute_instance_group_named_port`

Refer to the Terraform Registry for docs: [`google_compute_instance_group_named_port`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_instance_group_named_port).
