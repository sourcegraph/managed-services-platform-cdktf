# `google_compute_interconnect_attachment_group`

Refer to the Terraform Registry for docs: [`google_compute_interconnect_attachment_group`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_interconnect_attachment_group).
