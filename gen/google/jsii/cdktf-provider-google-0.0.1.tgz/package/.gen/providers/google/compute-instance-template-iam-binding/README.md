# `google_compute_instance_template_iam_binding`

Refer to the Terraform Registry for docs: [`google_compute_instance_template_iam_binding`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_instance_template_iam_binding).
