# `google_compute_network_peering_routes_config`

Refer to the Terraform Registry for docs: [`google_compute_network_peering_routes_config`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_network_peering_routes_config).
