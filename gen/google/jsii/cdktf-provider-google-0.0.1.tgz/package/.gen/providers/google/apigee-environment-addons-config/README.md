# `google_apigee_environment_addons_config`

Refer to the Terraform Registry for docs: [`google_apigee_environment_addons_config`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/apigee_environment_addons_config).
