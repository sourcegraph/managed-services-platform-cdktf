# `google_bigquery_data_transfer_config`

Refer to the Terraform Registry for docs: [`google_bigquery_data_transfer_config`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigquery_data_transfer_config).
