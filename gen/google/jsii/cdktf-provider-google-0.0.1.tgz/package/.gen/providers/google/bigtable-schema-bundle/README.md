# `google_bigtable_schema_bundle`

Refer to the Terraform Registry for docs: [`google_bigtable_schema_bundle`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigtable_schema_bundle).
