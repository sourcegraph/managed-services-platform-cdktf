# `data_google_app_engine_default_service_account`

Refer to the Terraform Registry for docs: [`data_google_app_engine_default_service_account`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/data-sources/app_engine_default_service_account).
