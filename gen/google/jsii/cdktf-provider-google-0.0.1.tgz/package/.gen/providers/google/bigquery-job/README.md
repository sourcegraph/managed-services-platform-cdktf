# `google_bigquery_job`

Refer to the Terraform Registry for docs: [`google_bigquery_job`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/bigquery_job).
