# `google_binary_authorization_attestor_iam_policy`

Refer to the Terraform Registry for docs: [`google_binary_authorization_attestor_iam_policy`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/binary_authorization_attestor_iam_policy).
