# `google_apihub_plugin_instance`

Refer to the Terraform Registry for docs: [`google_apihub_plugin_instance`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/apihub_plugin_instance).
