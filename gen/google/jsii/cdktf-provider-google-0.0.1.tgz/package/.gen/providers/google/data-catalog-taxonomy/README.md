# `google_data_catalog_taxonomy`

Refer to the Terraform Registry for docs: [`google_data_catalog_taxonomy`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/data_catalog_taxonomy).
