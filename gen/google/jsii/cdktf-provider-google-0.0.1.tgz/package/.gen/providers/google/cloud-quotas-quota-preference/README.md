# `google_cloud_quotas_quota_preference`

Refer to the Terraform Registry for docs: [`google_cloud_quotas_quota_preference`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/cloud_quotas_quota_preference).
