# `google_active_directory_domain_trust`

Refer to the Terraform Registry for docs: [`google_active_directory_domain_trust`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/active_directory_domain_trust).
