# `data_google_apphub_application`

Refer to the Terraform Registry for docs: [`data_google_apphub_application`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/data-sources/apphub_application).
