# `google_data_fusion_instance`

Refer to the Terraform Registry for docs: [`google_data_fusion_instance`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/data_fusion_instance).
