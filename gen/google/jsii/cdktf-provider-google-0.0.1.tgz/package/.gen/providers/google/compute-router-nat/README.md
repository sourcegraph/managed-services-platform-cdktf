# `google_compute_router_nat`

Refer to the Terraform Registry for docs: [`google_compute_router_nat`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_router_nat).
