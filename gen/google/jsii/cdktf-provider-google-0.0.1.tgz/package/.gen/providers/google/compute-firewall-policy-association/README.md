# `google_compute_firewall_policy_association`

Refer to the Terraform Registry for docs: [`google_compute_firewall_policy_association`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_firewall_policy_association).
