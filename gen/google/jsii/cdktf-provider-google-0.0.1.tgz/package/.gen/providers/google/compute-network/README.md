# `google_compute_network`

Refer to the Terraform Registry for docs: [`google_compute_network`](https://registry.terraform.io/providers/hashicorp/google/7.31.0/docs/resources/compute_network).
